package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * SPI 경고 알림 기능 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob012Configuration {

    public static final String JOB_NAME = "ksmsBatchJob012";
    public static final String STEP_NAME = "ksmsBatchStep012";
}
