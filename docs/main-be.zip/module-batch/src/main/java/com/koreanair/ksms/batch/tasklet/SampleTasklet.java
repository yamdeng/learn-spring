package com.koreanair.ksms.batch.tasklet;

import com.koreanair.ksms.batch.base.tasklet.BaseTasklet;
import com.koreanair.ksms.batch.dto.SampleDTO;
import com.koreanair.ksms.batch.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@StepScope
public class SampleTasklet extends BaseTasklet {
    private final SampleService sampleService;

    public SampleTasklet(SampleService sampleService) {
        this.sampleService = sampleService;
    }

    @Override
    public RepeatStatus run(StepContribution stepContribution, ChunkContext chunkContext) {
        List<SampleDTO> sampleDTOList = sampleService.retrieveSample();
        log.debug(" \n ***** Tasklet 조회 결과 : {} ****** ", sampleDTOList);

        sampleService.deleteSample();

        int insertCount = sampleService.insertSample(sampleDTOList);
        log.debug(" \n ***** Tasklet 삽입 결과 : {} ****** ", insertCount);

        return RepeatStatus.FINISHED;
    }

}
