package com.koreanair.ksms.batch.job;

import com.koreanair.ksms.batch.base.listener.BaseChunkLogger;
import com.koreanair.ksms.batch.base.listener.BaseJobLogger;
import com.koreanair.ksms.batch.base.listener.BaseStepLogger;
import com.koreanair.ksms.batch.dto.SampleDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.mybatis.spring.batch.builder.MyBatisBatchItemWriterBuilder;
import org.mybatis.spring.batch.builder.MyBatisPagingItemReaderBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

/**
 * 인사정보 I/F Batch Job
 */
@Slf4j
@Configuration
public class KsmsBatchJob001Configuration {

    public static final String JOB_NAME = "ksmsBatchJob001";
    public static final String STEP_NAME = "ksmsBatchStep001";

    private final int chunkSize = 1000;

    private final SqlSessionFactory sqlSessionFactory;

    public KsmsBatchJob001Configuration(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @Bean(JOB_NAME)
    public Job ksmsBatchJob001(JobRepository jobRepository, Step ksmsBatchStep001 ) {
        log.info(" >>> 인사정보 I/F ChunkJob() ");

        return new JobBuilder(JOB_NAME, jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(ksmsBatchStep001)
                .listener(new BaseJobLogger())
                .build();
    }

    @Bean(STEP_NAME)
    public Step sampleReaderStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        log.info(" >>> 인사정보 I/F ChunkReaderStep() ");

        return new StepBuilder("ksmsBatchStep001", jobRepository)
                .<List<SampleDTO>, List<SampleDTO>>chunk(chunkSize, transactionManager)
                .reader(ksmsBatchStep001ChunkReader())
                .writer(ksmsBatchStep001ChunkWriter())
                .listener(new BaseStepLogger())
                .listener(new BaseChunkLogger())
                .build();
    }

    @Bean
    public MyBatisPagingItemReader<List<SampleDTO>> ksmsBatchStep001ChunkReader() {
        log.info(" >>> 인사정보 I/F ChunkReader() ");

        return new MyBatisPagingItemReaderBuilder<List<SampleDTO>>()
                .sqlSessionFactory(sqlSessionFactory)
                .queryId("com.koreanair.ksms.batch.mapper.SampleMapper.selectEmployeeTable")
                .pageSize(chunkSize)
                .build();
    }

    @Bean
    public MyBatisBatchItemWriter<List<SampleDTO>> ksmsBatchStep001ChunkWriter() {
        log.info(" >>> 인사정보 I/F ChunkWriter() ");

        return new MyBatisBatchItemWriterBuilder<List<SampleDTO>>()
                .sqlSessionFactory(sqlSessionFactory)
                .statementId("com.koreanair.ksms.batch.mapper.SampleMapper.insertEmployeeTable")
                .build();
    }
}
