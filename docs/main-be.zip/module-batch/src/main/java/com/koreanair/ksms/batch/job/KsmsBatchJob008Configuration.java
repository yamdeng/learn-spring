package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * 교육정보 I/F Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob008Configuration {

    public static final String JOB_NAME = "ksmsBatchJob008";
    public static final String STEP_NAME = "ksmsBatchStep008";
}
