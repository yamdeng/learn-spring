package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class CustomUserInfoDto {

    private String userId;
    private String empNo;
    private String email;
    private String role;
}
