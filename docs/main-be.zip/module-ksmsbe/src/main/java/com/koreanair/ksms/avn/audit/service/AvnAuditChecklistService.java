package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.TBAuditChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditQuestionDto;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;

import java.util.List;
import java.util.Map;

public interface AvnAuditChecklistService {

    List<TBAuditChecklistChapterDto> selectAuditChecklist(TBAuditChecklistDto searchDto);

    List<ChecklistRevisionsVo> selectAuditChecklistRevision(int checklistOriginId);

    List<TBAuditQuestionDto> selectAuditQuestionList(TBAuditChapterDto searchDto);

}
