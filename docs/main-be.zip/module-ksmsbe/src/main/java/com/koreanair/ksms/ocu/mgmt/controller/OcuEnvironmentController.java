package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuEnvironmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전관리 - 작업환경측정
 */
@Tag(name = "OcuEnvironment", description = "안전관리 - 작업환경측정 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuEnvironmentController {

    @Autowired
    OcuEnvironmentService service;

    /**
     * 화학물질사용량조사 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "화학물질사용량조사 목록 조회", description = "화학물질사용량조사 목록 조회 API")
    @GetMapping(value = "/management/environment/chemicals")
    public ResponseEntity<?> getChemicalList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "화학물질사용량조사 상세정보 조회", description = "화학물질사용량조사 상세정보 조회 API")
    @GetMapping(value = "/management/environment/chemicals/{chemicalId}")
    public ResponseEntity<?> getChemicalInfo(@PathVariable(value="chemicalId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 화학물질사용량조사 등록", description = "신규 화학물질사용량조사 등록 API")
    @PostMapping(value = "/management/environment/chemicals")
    public ResponseEntity<?> insertChemical(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "화학물질사용량조사 정보 수정", description = "화학물질사용량조사 정보 수정 API")
    @PutMapping(value = "/management/environment/chemicals/{chemicalId}")
    public ResponseEntity<?> updateChemical(
            @PathVariable(value="chemicalId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "화학물질사용량조사 삭제", description = "화학물질사용량조사 삭제 API")
    @DeleteMapping(value = "/management/environment/chemicals/{chemicalId}")
    public ResponseEntity<?> deleteChemical(@PathVariable(value="chemicalId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 작업환경측정 결과보고서 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "작업환경측정 결과보고서 목록 조회", description = "작업환경측정 결과보고서 목록 조회 API")
    @GetMapping(value = "/management/environment/results")
    public ResponseEntity<?> getEnvResultList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "작업환경측정 결과보고서 상세정보 조회", description = "작업환경측정 결과보고서 상세정보 조회 API")
    @GetMapping(value = "/management/environment/results/{resultId}")
    public ResponseEntity<?> getEnvResultInfo(@PathVariable(value="resultId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 작업환경측정 결과보고서 등록", description = "신규 작업환경측정 결과보고서 등록 API")
    @PostMapping(value = "/management/environment/results")
    public ResponseEntity<?> insertEnvResult(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업환경측정 결과보고서 정보 수정", description = "작업환경측정 결과보고서 정보 수정 API")
    @PutMapping(value = "/management/environment/results/{resultId}")
    public ResponseEntity<?> updateEnvResult(
            @PathVariable(value="resultId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업환경측정 결과보고서 삭제", description = "작업환경측정 결과보고서 삭제 API")
    @DeleteMapping(value = "/management/environment/results/{resultId}")
    public ResponseEntity<?> deleteEnvResult(@PathVariable(value="resultId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 작업환경측정 결과 상세자료 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "작업환경측정 결과 상세자료 목록 조회", description = "작업환경측정 결과 상세자료 목록 조회 API")
    @GetMapping(value = "/management/environment/detailed-results")
    public ResponseEntity<?> getDetailResultList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "작업환경측정 결과 상세자료 상세정보 조회", description = "작업환경측정 결과 상세자료 상세정보 조회 API")
    @GetMapping(value = "/management/environment/detailed-results/{detailResultId}")
    public ResponseEntity<?> getDetailResultInfo(@PathVariable(value="detailResultId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 작업환경측정 결과 상세자료 등록", description = "신규 작업환경측정 결과 상세자료 등록 API")
    @PostMapping(value = "/management/environment/detailed-results")
    public ResponseEntity<?> insertDetailResult(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업환경측정 결과 상세자료 정보 수정", description = "작업환경측정 결과 상세자료 정보 수정 API")
    @PutMapping(value = "/management/environment/detailed-results/{detailResultId}")
    public ResponseEntity<?> updateDetailResult(
            @PathVariable(value="detailResultId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업환경측정 결과 상세자료 삭제", description = "작업환경측정 결과 상세자료 삭제 API")
    @DeleteMapping(value = "/management/environment/detailed-results/{detailResultId}")
    public ResponseEntity<?> deleteDetailResult(@PathVariable(value="detailResultId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
