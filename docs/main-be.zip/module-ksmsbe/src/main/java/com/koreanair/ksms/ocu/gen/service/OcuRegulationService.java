package com.koreanair.ksms.ocu.gen.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;

import jakarta.validation.Valid;

/**
 * 규정/지침/매뉴얼/양식 목록 Service
 */
public interface OcuRegulationService {

	
	/**
	 * 규정/지침/매뉴얼/양식 목록 조회
	 * @param dto
	 * @return
	 */
	public PageInfo<OcuRegulationDto> selectRegulationsList(OcuRegulationDto dto);

	/**
	 * 규정/지침/매뉴얼/양식 상세 정보 조회
	 * @param rulesFormId
	 * @return
	 */
	public OcuRegulationDto getRegulationInfo(int rulesFormId);

	/**
	 * 규정/지침/매뉴얼/양식 등록
	 * @param dto
	 */
	public void insertRegulation(@Valid OcuRegulationDto dto);

	/**
	 * 규정/지침/매뉴얼/양식 수정
	 * @param dto
	 */
	public void updateRegulation(@Valid OcuRegulationDto dto);

	/**
	 * 규정/지침/매뉴얼/양식 삭제
	 * @param rulesFormId
	 */
	public void deleteRegulation(int rulesFormId);

	/**
	 * 규정/지침/매뉴얼/양식 개정번호 조회
	 * @param sectCode
	 * @param ruleFormType
	 * @return
	 */
	public OcuRegulationDto selectRevisionNo(String sectCode, String ruleFormType);

	/**
	 * 규정/지침/매뉴얼/양식 개정번호 리스트 조회
	 * @param sectCode
	 * @param ruleFormType
	 * @return
	 */
	public List<OcuRegulationDto> selectRevisionNoList(String sectCode, String ruleFormType);
}
