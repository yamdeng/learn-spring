package com.koreanair.ksms.ocu.gen.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.controller.OcuNoticeController;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 공지사항 ServiceImpl
 */
@Slf4j
@Service
public class OcuNoticeServiceImpl extends AbstractBaseService implements OcuNoticeService {

	/**
	 * 공지사항 목록 조회
	 */
	@Override
    public PageInfo<OcuNoticeDto> selectGetNoticeList(OcuNoticeDto dto) {
        List<OcuNoticeDto> resultList = commonSql.selectList("OcuNotice.selectGetNoticeList", dto);
        return PageInfo.of(resultList);
    }

	/**
	 * 공지사항 상세 조회
	 */
	@Override
	public OcuNoticeDto getNoticeInfo(int noticeId) {
		return commonSql.selectOne("OcuNotice.getNoticeInfo", noticeId);
	}

	/**
	 * 공지사항 입력
	 */
	@Override
	public void insertNotice(OcuNoticeDto dto) {
		
//		// 공지사항 ID 조회
//		int noticeId = commonSql.selectOne("OcuNotice.selectNoticeId");
//		dto.setNoticeId(noticeId);
		
		commonSql.insert("OcuNotice.insertNotice", dto);
		
	}

	/**
	 * 공지사항 수정
	 */
	@Override
	public void updateNotice(@Valid OcuNoticeDto dto) {
		log.debug("수정@@@@@@@@@@@@@@@@@@@");;
		commonSql.update("OcuNotice.updateNotice", dto);
		
	}

	/**
	 * 공지사항 삭제
	 */
	@Override
	public void deleteNotice(int noticeId) {
		commonSql.delete("OcuNotice.deleteNotice", noticeId);
		
	}

}
