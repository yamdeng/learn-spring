package com.koreanair.ksms.ocu.gen.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 안전보건협의체 DTO
 */
@Getter
@Setter
@ToString
public class OcuHsCommitteeDto {
	
	/**
	 * 순번
	 */
	private int num;
	
	/**
	 * 협의체 ID
	 */
	private int advCmitId;
	
	/**
	 * 부문 코드 
	 */
	private String advCmitSectCd;
	
	/**
	 * 부문 명 
	 */
	private String advCmitSectNm;
	
	
    /**
     * 부서 코드
     */
    private String advCmitDeptCd;
    
    /**
     * 실시 연월
     */
    private String advCmitImplmYm;
    
    /**
     * 실시연도
     */
    private String advCmitImplmYY;
    
    /**
     * 제목
     */
    private String advCmitTitle;
    
    /**
     * 비고
     */
    private String advCmitRemark;
    
    /**
     * 회의록 ID
     */
    private int prcdnFileId;
    
    /**
     * 회의자료 ID
     */
    private int meetDocFileId;
    
    /**
     * 첨부 링크 ID (보고 문서)
     */
    private int reportDocLinkId;
    
    /**
     * 검색 연도
     */
    private String year;
    
    
    /**
     * 검색 구분 값(A:현황, B:목록) 
     */
    private String activeTab;
     
    /**
     * 1월
     */
    private String month1;
    
    /**
     * 2월
     */
    private String month2;
    
    /**
     * 3월
     */
    private String month3;
    
    /**
     * 4월
     */
    private String month4;
    
    /**
     * 5월
     */
    private String month5;
    
    /**
     * 6월
     */
    private String month6;
    
    /**
     * 7월
     */
    private String month7;
    
    /**
     * 8월
     */
    private String month8;
    
    /**
     * 9월
     */
    private String month9;
    
    /**
     * 10월
     */
    private String month10;
    
    /**
     * 11월
     */
    private String month11;
    
    /**
     * 12월
     */
    private String month12;
    
    /**
     * 등록자 사번
     */
    private String regUserId;
    
    /**
     * 등록 일시 
     */
    private String regDttm;
    
    /**
     * 수정자 사번
     */
    private String updUserId;
    
    /**
     * 수정 일시
     */
    private String updDttm;
}


