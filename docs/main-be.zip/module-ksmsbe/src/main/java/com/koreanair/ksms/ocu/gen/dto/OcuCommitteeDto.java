package com.koreanair.ksms.ocu.gen.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 산업안전보건위원회 DTO
 */
@Getter
@Setter
@ToString
public class OcuCommitteeDto {
	
	/**
	 * 순번
	 */
	private int num;
	
	/**
	 * 산업안전보건위원회_ID
	 */
	private int ocuCommitId;
	
	/**
	 * 공지사항 제목 
	 */
	private String title;
	
    /**
     * 공지사항 내용
     */
    private String content;
    
    /**
     * 부문 코드
     */
    private String sectCd;
    
    /**
     * 부문명
     */
    private String sectNm;
    
    /**
     * 첨부 파일 ID
     */
    private int fileId;
    
    /**
     * 첨부 링크 ID
     */
    private int linkId;
    
    /**
     * FROM 등록일자
     */
    private String fromRegDttm;
    
    /**
     * TO 등록일자
     */
    private String toRegDttm;
    
  
    
    /**
     * 등록자 사번
     */
    private String regUserId;
    
    /**
     * 등록 일시 
     */
    private String regDttm;
    
    /**
     * 수정자 사번
     */
    private String updUserId;
    
    /**
     * 수정 일시
     */
    private String updDttm;
}


