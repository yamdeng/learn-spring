package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.service.AvnMyAuditService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * AUDIT - 나의 품질심사(My Audit)
 */
@Tag(name = "AvnMyAudit", description = "AUDIT - 나의 품질심사(My Audit) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnMyAuditController {

    @Autowired
    AvnMyAuditService service;

    /**
     * My Audit 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 목록 조회", description = "My Audit 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/audits")
    public ResponseEntity<?> getAuditMyAuditList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 부문별 Audit 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "부문별 Audit 통계 조회", description = "부문별 Audit 통계 조회 API")
    @GetMapping(value = "/audit/my-audit/branch-statistics")
    public ResponseEntity<?> getAuditBranchStatList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * My Audit 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 통계 조회", description = "My Audit 통계 조회 API")
    @GetMapping(value = "/audit/my-audit/my-statistics")
    public ResponseEntity<?> getAuditMyAuditStatList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * My Processing 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Processing 통계 조회", description = "My Processing 통계 조회 API")
    @GetMapping(value = "/audit/my-audit/my-processings")
    public ResponseEntity<?> getAuditProcessingList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Audit 일괄등록
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 일괄등록", description = "Audit 일괄등록 API")
    @PostMapping(value = "/audit/my-audit/audits")
    public ResponseEntity<?> insertMyAudit(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Audit 상세조회
     *
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 상세조회", description = "Audit 상세조회 API")
    @GetMapping(value = "/audit/my-audit/audits/{auditId}")
    public ResponseEntity<?> getMyAuditInfo(@PathVariable(value="auditId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * Plan 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Plan 목록 조회", description = "Plan 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/plans")
    public ResponseEntity<?> getMyAuditPlanList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Plan 상세정보 조회", description = "Plan 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/plans/{planId}")
    public ResponseEntity<?> getMyAuditPlanInfo(@PathVariable(value="planId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Plan 등록", description = "신규 Plan 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/plans")
    public ResponseEntity<?> insertMyAuditPlan(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 정보 수정", description = "Plan 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/plans/{planId}")
    public ResponseEntity<?> updateMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 정보 제출", description = "Plan 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/creation/plans/submit/{planId}")
    public ResponseEntity<?> submitMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 삭제", description = "Plan 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/plans/{planId}")
    public ResponseEntity<?> deleteMyAuditPlan(@PathVariable(value="planId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Conduct 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Conduct 목록 조회", description = "Conduct 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/conducts")
    public ResponseEntity<?> getMyAuditConductList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Conduct 상세정보 조회", description = "Conduct 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/conducts/{conductId}")
    public ResponseEntity<?> getMyAuditConductInfo(@PathVariable(value="conductId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Conduct 등록", description = "신규 Conduct 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/conducts")
    public ResponseEntity<?> insertMyAuditConduct(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 정보 수정", description = "Conduct 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/conducts/{conductId}")
    public ResponseEntity<?> updateMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 정보 제출", description = "Conduct 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/creation/conducts/submit/{conductId}")
    public ResponseEntity<?> submitMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 삭제", description = "Conduct 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/conducts/{conductId}")
    public ResponseEntity<?> deleteMyAuditConduct(@PathVariable(value="conductId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 목록 조회", description = "CAR 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/cars")
    public ResponseEntity<?> getMyAuditCARList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "CAR 상세정보 조회", description = "CAR 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/cars/{carId}")
    public ResponseEntity<?> getMyAuditCARInfo(@PathVariable(value="carId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 CAR 등록", description = "신규 CAR 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/cars")
    public ResponseEntity<?> insertMyAuditCAR(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 정보 수정", description = "CAR 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/cars/{carId}")
    public ResponseEntity<?> updateMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 정보 제출", description = "CAR 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/creation/cars/submit/{carId}")
    public ResponseEntity<?> submitMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 삭제", description = "CAR 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/cars/{carId}")
    public ResponseEntity<?> deleteMyAuditCAR(@PathVariable(value="carId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Finding 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Finding 목록 조회", description = "Finding 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/findings")
    public ResponseEntity<?> getMyAuditFindingsList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Observation 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Observation 목록 조회", description = "Observation 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/observations")
    public ResponseEntity<?> getMyAuditObservationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Corrective Action 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Corrective Action 목록 조회", description = "Corrective Action 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/cas")
    public ResponseEntity<?> getMyAuditCAList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Action Taken 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Action Taken 목록 조회", description = "Action Taken 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/action-taken")
    public ResponseEntity<?> getMyAuditActionTakenList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 수행 담당 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "수행 담당 목록 조회", description = "수행 담당 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/performances")
    public ResponseEntity<?> getMyAuditPerformanceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 위험 요인 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "위험 요인 목록 조회", description = "위험 요인 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/hazards")
    public ResponseEntity<?> getMyAuditHazardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * CAR 개별 승인 요청
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 개별 승인 요청", description = "CAR 개별 승인 요청 API")
    @PutMapping(value = "/audit/my-audit/creation/car/request/{carId}")
    public ResponseEntity<?> updateCarRequest(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR 개별 승인
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 개별 승인", description = "CAR 개별 승인 API")
    @PutMapping(value = "/audit/my-audit/creation/car/approval/{carId}")
    public ResponseEntity<?> updateCarApproval(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR 개별 거절
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 개별 거절", description = "CAR 개별 거절 API")
    @PutMapping(value = "/audit/my-audit/creation/car/reject/{carId}")
    public ResponseEntity<?> updateCarReject(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR 개별 롤백
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 개별 롤백", description = "CAR 개별 롤백 API")
    @PutMapping(value = "/audit/my-audit/creation/car/rollback/{carId}")
    public ResponseEntity<?> updateCarRollback(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Finding Category 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Finding Category 목록 조회", description = "Finding Category 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/finding-category")
    public ResponseEntity<?> getMyAuditFindingCategoryList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Root Cause 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Root Cause 목록 조회", description = "Root Cause 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/root-cause")
    public ResponseEntity<?> getMyAuditRootCauseList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Close 정보 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Close 정보 조회", description = "Close 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/close")
    public ResponseEntity<?> getMyAuditCloseList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Close 공유 등록
     *
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 등록", description = "Close 공유 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/close")
    public ResponseEntity<?> insertMyAuditClose(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Close 공유 현황 조회
     *
     * @param key the key
     * @return the deadline manage info
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 현황 조회", description = "Close 공유 현황 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/close/{closeId}")
    public ResponseEntity<?> getMyAuditCloseInfo(@PathVariable(value="closeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
