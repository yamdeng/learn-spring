package com.koreanair.ksms.avn.audit.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.audit.service.AvnAuditChecklistService;
import com.koreanair.ksms.common.dto.CommonDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditQuestionDto;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;

/**
 * AUDIT - 점검표(Checklist)
 */
@Tag(name = "AvnAuditChecklist", description = "AUDIT - 점검표(Checklist) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditChecklistController {

    @Autowired
    AvnAuditChecklistService service;

    /**
     * Checklist 목록 조회 (with Chapter)
     * @param division the page num
     * @param origId the page num
     * @param revision the page size
     * @return the list
     * @throws Exception the exception
     */
    @Parameters({
            @Parameter(name = "division", description = "부문 아이디"),
            @Parameter(name = "origId", description = "체크리스트 원본아이디"),
            @Parameter(name = "revision", description = "리비전")
    })
    @Operation(summary = "Checklist 목록 조회 (with Chapter)", description = "Checklist 목록 조회 (with Chapter) API")
    @GetMapping(value = "/audit/checklist/getAuditChecklist")
    public ResponseEntity<?> getAuditChecklist(
            @RequestParam(value="division", required=true) String division,
            @RequestParam(value="origId", required=false, defaultValue = "0") int origId,
            @RequestParam(value="revision", required=false, defaultValue = "0") int revision) {

        // 조회조건 parameter
        TBAuditChecklistDto tbAuditChecklistDto = new TBAuditChecklistDto();
        tbAuditChecklistDto.setDivision(division);
        tbAuditChecklistDto.setOrigId(origId);
        tbAuditChecklistDto.setRevision(revision);

        List<TBAuditChecklistChapterDto> resultList = service.selectAuditChecklist(tbAuditChecklistDto);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /**
     * Checklist Revision 목록
     * @param checklistOriginId the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Checklist 버전 목록 조회", description = "Checklist 버전 목록 조회 API")
    @GetMapping(value = "/audit/checklist/getAuditChecklistRevision")
    public ResponseEntity<?> getAuditChecklistRevision(@RequestParam(value="checklistOriginId", required=true) int checklistOriginId) {

        List<ChecklistRevisionsVo> resultList = service.selectAuditChecklistRevision(checklistOriginId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /**
     * question 목록 조회
     * @param chapterId the page num
     * @param revision the page size
     * @return the list
     * @throws Exception the exception
     */
    @Parameters({
            @Parameter(name = "chapterId", description = "챕터 아이디"),
            @Parameter(name = "revision", description = "리비전")
    })
    @Operation(summary = "Question 목록 조회 (with Chapter)", description = "Question 목록 조회 API")
    @GetMapping(value = "/audit/checklist/getAuditQuestionList")
    public ResponseEntity<?> getAuditQuestionList(
            @RequestParam(value="chapterId", required=true) int chapterId,
            @RequestParam(value="revision", required=true) int revision) {
        // 조회조건 parameter
        TBAuditChapterDto tbAuditChapterDto = new TBAuditChapterDto();
        tbAuditChapterDto.setChapterId(chapterId);
        tbAuditChapterDto.setRevision(revision);

        List<TBAuditQuestionDto> resultList = service.selectAuditQuestionList(tbAuditChapterDto);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "신규 Checklist 등록", description = "신규 Checklist 등록 API")
    @PostMapping(value = "/audit/checklist/insertAuditChecklist")
    public ResponseEntity<?> insertAuditChecklist(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }


    /*
    @Operation(summary = "Checklist 정보 수정", description = "Checklist 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/checklists/{checklistId}")
    public ResponseEntity<?> updateAuditChecklist(
            @PathVariable(value="checklistId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Checklist 버전 수정", description = "Checklist 버전 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/checklists/version/{checklistId}")
    public ResponseEntity<?> updateAuditCheckVersion(
            @PathVariable(value="checklistId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Checklist 삭제", description = "Checklist 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/checklists/{checklistId}")
    public ResponseEntity<?> deleteAuditChecklist(@PathVariable(value="checklistId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    *
     * Chapter 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception

    @Operation(summary = "Chapter 목록 조회", description = "Chapter 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/chapters")
    public ResponseEntity<?> getAuditChapterList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Chapter 상세정보 조회", description = "Chapter 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> getAuditChapterInfo(@PathVariable(value="chapterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Chapter 등록", description = "신규 Chapter 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/chapters")
    public ResponseEntity<?> insertAuditChapter(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Chapter 정보 수정", description = "Chapter 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> updateAuditChapter(
            @PathVariable(value="chapterId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Chapter 삭제", description = "Chapter 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> deleteAuditChapter(@PathVariable(value="chapterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    *
     * Question 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception

    @Operation(summary = "Question 목록 조회", description = "Question 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/questions")
    public ResponseEntity<?> getAuditQuestionList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Question 상세정보 조회", description = "Question 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> getAuditQuestionInfo(@PathVariable(value="questionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Question 등록", description = "신규 Question 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/questions")
    public ResponseEntity<?> insertAuditQuestion(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Question 정보 수정", description = "Question 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> updateAuditQuestion(
            @PathVariable(value="questionId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Question 삭제", description = "Question 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> deleteAuditQuestion(@PathVariable(value="questionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }*/
}
