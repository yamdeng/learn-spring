package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS 강사교육 이수")
public class TbAvnInstructorEducationDto extends CommonDto {
    
    @Schema(description = "교육이수ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "사번")
    @NotBlank
    private String empNo;
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "종료일자")
    private String endDt;
    
    @Schema(description = "교육명")
    private String educationName;
}
