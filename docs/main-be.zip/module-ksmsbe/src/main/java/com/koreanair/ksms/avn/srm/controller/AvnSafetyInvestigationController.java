package com.koreanair.ksms.avn.srm.controller;

import com.koreanair.ksms.avn.srm.service.AvnSafetyInvestigationService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전위험관리 - 안전조사
 */
@Tag(name = "AvnSafetyInvestigation", description = "안전위험관리 - 안전조사 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyInvestigationController {

    @Autowired
    AvnSafetyInvestigationService service;

    /**
     * 조사보고서 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "조사보고서 목록 조회", description = "조사보고서 목록 조회 API")
    @GetMapping(value = "/srm/investigations")
    public ResponseEntity<?> getInvestigationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "조사보고서 상세정보 조회", description = "조사보고서 상세정보 조회 API")
    @GetMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> getInvestigationInfo(@PathVariable(value="investigationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 조사보고서 등록", description = "신규 조사보고서 등록 API")
    @PostMapping(value = "/srm/investigations")
    public ResponseEntity<?> insertInvestigation(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "조사보고서 정보 수정", description = "조사보고서 정보 수정 API")
    @PutMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> updateInvestigation(
            @PathVariable(value="investigationId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "조사보고서 삭제", description = "조사보고서 삭제 API")
    @DeleteMapping(value = "/srm/investigations/{investigationId}")
    public ResponseEntity<?> deleteInvestigation(@PathVariable(value="investigationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전조사 리포트 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전조사 리포트 목록 조회", description = "안전조사 리포트 목록 조회 API")
    @GetMapping(value = "/srm/investigation/reports")
    public ResponseEntity<?> getInveReportList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전조사 리포트 상세정보 조회", description = "안전조사 리포트 상세정보 조회 API")
    @GetMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> getInveReportInfo(@PathVariable(value="reportId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전조사 리포트 등록", description = "신규 안전조사 리포트 등록 API")
    @PostMapping(value = "/srm/investigation/reports")
    public ResponseEntity<?> insertInveReport(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전조사 리포트 정보 수정", description = "안전조사 리포트 정보 수정 API")
    @PutMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> updateInveReport(
            @PathVariable(value="reportId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전조사 리포트 삭제", description = "안전조사 리포트 삭제 API")
    @DeleteMapping(value = "/srm/investigation/reports/{reportId}")
    public ResponseEntity<?> deleteInveReport(@PathVariable(value="reportId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 대시보드 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "대시보드 목록 조회", description = "대시보드 목록 조회 API")
    @GetMapping(value = "/srm/investigation/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }
}
