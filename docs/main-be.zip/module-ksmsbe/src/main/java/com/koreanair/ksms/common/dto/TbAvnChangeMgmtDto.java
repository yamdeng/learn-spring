package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "변화관리 항목")
public class TbAvnChangeMgmtDto extends CommonDto {
    
    @Schema(description = "변화관리키")
    @NotBlank
    private String changeMgmtId;
    
    @Schema(description = "연도")
    @NotBlank
    private String year;
    
    @Schema(description = "소관부문")
    @NotBlank
    private String division;
    
    @Schema(description = "수행담당자-수정 필요")
    private String empNo;
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "종료일자")
    private String toDt;
    
    @Schema(description = "변화내용")
    private String content;
    
    @Schema(description = "첨부파일키")
    private String linkGroupSeq;
    
    @Schema(description = "링크키")
    private String fileGroupSeq;
}
