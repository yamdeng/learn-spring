package com.koreanair.ksms.ocu.edu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.edu.service.OcuManualEduService;
import com.koreanair.ksms.ocu.edu.dto.OcuManualEduDto;

import java.util.List;

@Tag(name = "매뉴얼교육", description = "매뉴얼교육 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocn")
public class OcuManualEduController {

    @Autowired
    private OcuManualEduService ocuManualEduService;

    @Operation(summary = "매뉴얼교육 상세 조회", description = "매뉴얼교육 상세 조회 API")
    @GetMapping("/education/manual/{id}")
    public ResponseEntity<?> selectOcuManualEdu(@PathVariable(value="id", required=true) int id) {
        
        OcuManualEduDto result = ocuManualEduService.selectOcuManualEdu(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "매뉴얼교육 목록 조회", description = "매뉴얼교육 목록 조회 API")
    @GetMapping("/education/manual")
    public ResponseEntity<?> getDeptList(
        @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
        ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){
  
        OcuManualEduDto paramDto = new OcuManualEduDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuManualEduDto> pageList = ocuManualEduService.selectOcuManualEduList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "매뉴얼교육 일괄 저장", description = "매뉴얼교육 일괄 저장 API")
    @PostMapping("/education/manual/bulk")
    public ResponseEntity<?> saveOcuManualEdu(@RequestBody List<OcuManualEduDto> reqDtoList) {

        ocuManualEduService.saveOcuManualEdu(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "매뉴얼교육 등록", description = "매뉴얼교육 등록 API")
    @PostMapping(value = "/education/manual")
    public ResponseEntity<?> insertOcuManualEdu(@Valid @RequestBody(required=true) OcuManualEduDto reqDto){

        ocuManualEduService.insertOcuManualEdu(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "매뉴얼교육 수정", description = "매뉴얼교육 수정 API")
    @PutMapping(value = "/education/manual")
    public ResponseEntity<?> updateOcuManualEdu(@Valid @RequestBody(required=true) OcuManualEduDto reqDto){
        
        ocuManualEduService.updateOcuManualEdu(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "매뉴얼교육 삭제", description = "매뉴얼교육 삭제 API")
    @DeleteMapping(value = "/education/manual/{id}")
    public ResponseEntity<?> deleteOcuManualEdu(@PathVariable(value="id", required=true) int id){
        ocuManualEduService.deleteOcuManualEdu(id);
        return ResponseUtil.createSuccessResponse();
    }

}


