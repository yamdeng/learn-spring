package com.koreanair.ksms.ocu.edu.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "매뉴얼교육")
public class OcuManualEduDto extends CommonDto {
    
    @Schema(description = "교육_ID")
    @NotBlank
    private String eduId;
    
    @Schema(description = "부문_코드")
    @NotBlank
    private String sectCd;
    
    @Schema(description = "부서_코드")
    @NotBlank
    private String deptCd;
    
    @Schema(description = "교육_유형_코드")
    @NotBlank
    private String eduTypeCd;
    
    @Schema(description = "교육_일자")
    @NotBlank
    private String eduDt;
    
    @Schema(description = "교육_시작_일시")
    @NotBlank
    private String eduStartDttm;
    
    @Schema(description = "교육_종료_일시")
    @NotBlank
    private String eduEndDttm;
    
    @Schema(description = "교육_장소")
    @NotBlank
    private String eduLocation;
    
    @Schema(description = "교육_인원")
    @NotBlank
    private String eduPrsnCnt;
    
    @Schema(description = "작업_코드")
    private String wrkCd;
    
    @Schema(description = "교육_내용")
    private String eduContent;
    
    @Schema(description = "결재_ID")
    private String aprvId;
}
