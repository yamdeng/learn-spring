package com.koreanair.ksms.ocu.edu.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "매뉴얼교육_서명")
public class OcuManualEduSignDto extends CommonDto {
    
    @Schema(description = "교육대상_ID")
    @NotBlank
    private String eduTargetId;
    
    @Schema(description = "교육_ID")
    @NotBlank
    private String eduId;
    
    @Schema(description = "대상자_구분")
    @NotBlank
    private String targetCls;
    
    @Schema(description = "대상자_사번")
    private String targetEmpno;
    
    @Schema(description = "서명_일시")
    private String signDttm;
}
