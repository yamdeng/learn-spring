package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "매뉴얼")
public class TbManual extends CommonDto {
    
    @Schema(description = "매뉴얼 ID")
//    @NotBlank
    private int manualId;
    
    @Schema(description = "업무구분")
    private String jobType;
    
    @Schema(description = "개정일자")
    private String revisionDt;
    
    @Schema(description = "매뉴얼명")
    private String manualName;
    
    @Schema(description = "언어구분")
    private String languageType;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "비고")
    private String notes;
    
    @Schema(description = "원문 첨부파일")
    private int originalFileGroupSeq;
    
    @Schema(description = "신구대조표 첨부파일")
    private int newOldFileGroupSeq;

    @Schema(description = "순번")
    private int num;
}
