package com.koreanair.ksms.avn.audit.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / Checklist")
public class TBAuditChecklistDto {

    @Schema(description = "checklistId")
    @NotBlank
    private int checklistId;

    @Schema(description = "원본아이디")
    private int origId;

    @Schema(description = "리비전")
    private int revision;

    @Schema(description = "체크리스트명")
    private String listName;

    @Schema(description = "Audit 부문")
    private String division;

    @Schema(description = "언어코드")
    private String langCode;

    @Schema(description = "Special Checklist Group 여부")
    private String isSpecial;

    @Schema(description = "표시 순서")
    private String viewOrder;

    @Schema(description = "메모")
    private String notes;

    @Schema(description = "활성/비활성 상태")
    private String state;

    @Schema(description = "등록자")
    private String regUserId;

    @Schema(description = "등록일시")
    private Timestamp regDttm;

    @Schema(description = "수정자")
    private String updUserId;

    @Schema(description = "수정일시")
    private Timestamp updDttm;

    @Schema(description = "삭제일시")
    private Timestamp deletedAt;
}
