package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnConsequenceDto;
import com.koreanair.ksms.avn.admin.service.AvnCriteriaManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnHazardLv3Dto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 필수 항목 관리
 */
@Tag(name = "AvnCriteriaManage", description = "관리자 - 필수 항목 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnCriteriaManageController {

    @Autowired
    AvnCriteriaManageService service;

    /**
     * 위해요인 등록부 관리 목록 조회
     *
     * @param pageNum the pageNum
     * @param pageSize the pageSize
     * @param hazardLv1Id the hazardLv1Id
     * @param hazardLv2Id the hazardLv2Id
     * @param hazardLv3Id the hazardLv3Id
     * @param lvText1 the lvText1
     * @param lvText2 the lvText2
     * @param lvText3 the lvText3
     * @param hazardDetail the hazardDetail
     * @param sources the pageNum
     * @param potentialConsequence the potentialConsequence
     * @param useYn the useYn
     * @param notes the notes
     * @param viewOrder the viewOrder
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "위해요인 등록부 관리 목록 조회", description = "위해요인 등록부 관리 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "hazardLv1Id", description = "hazardLv1Id"),
            @Parameter(name = "hazardLv2Id", description = "hazardLv2Id"),
            @Parameter(name = "hazardLv3Id", description = "hazardLv3Id"),
            @Parameter(name = "lvText1", description = "Level 1"),
            @Parameter(name = "lvText2", description = "Level 2"),
            @Parameter(name = "lvText3", description = "Level 3"),
            @Parameter(name = "hazardDetail", description = "위해요인 내용"),
            @Parameter(name = "sources", description = "출처"),
            @Parameter(name = "potentialConsequence", description = "잠재결과"),
            @Parameter(name = "useYn", description = "사용여부"),
            @Parameter(name = "notes", description = "비고"),
            @Parameter(name = "viewOrder", description = "정렬순서")
    })
    @GetMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> getHazardTaxonomyList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="hazardLv1Id") String hazardLv1Id
            ,@RequestParam(value="hazardLv2Id") String hazardLv2Id
            ,@RequestParam(value="hazardLv3Id") String hazardLv3Id
            ,@RequestParam(value="lvText1") String lvText1
            ,@RequestParam(value="lvText2") String lvText2
            ,@RequestParam(value="lvText3") String lvText3
            ,@RequestParam(value="hazardDetail") String hazardDetail
            ,@RequestParam(value="sources") String sources
            ,@RequestParam(value="potentialConsequence") String potentialConsequence
            ,@RequestParam(value="useYn") String useYn
            ,@RequestParam(value="notes") String notes
            ,@RequestParam(value="viewOrder") String viewOrder) {

        // 조회조건 parameter
        TbAvnHazardLv3Dto tbAvnHazardLv3Dto = new TbAvnHazardLv3Dto();

        tbAvnHazardLv3Dto.setLvText(lvText3);
        tbAvnHazardLv3Dto.setHazardLv2Id(hazardLv2Id);                     // hazardLv2Id
        tbAvnHazardLv3Dto.setHazardLv3Id(hazardLv3Id);                     // hazardLv3Id
        tbAvnHazardLv3Dto.setHazardDetail(hazardDetail);                   // 위해요인 내용
        tbAvnHazardLv3Dto.setSources(sources);                             // 출처
        tbAvnHazardLv3Dto.setPotentialConsequence(potentialConsequence);   // 잠재결과
        tbAvnHazardLv3Dto.setUseYn(useYn);                                 // 사용여부
        tbAvnHazardLv3Dto.setNotes(notes);                                 // 비고
        tbAvnHazardLv3Dto.setViewOrder(String.valueOf(viewOrder));         // 정렬순서

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnHazardLv3Dto> pageList = service.selectTaxonomyList(tbAvnHazardLv3Dto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "위해요인 등록부 관리 상세정보 조회", description = "위해요인 등록부 관리 상세정보 조회 API")
    @Parameter(name = "hazardLv3Id", description = "")
    @GetMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> getHazardTaxonomyInfo(@PathVariable(value="hazardLv3Id", required=true) String hazardLv3Id) {

        TbAvnHazardLv3Dto result = service.selectTaxonomyDetail(hazardLv3Id);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 위해요인 등록부 관리 등록", description = "신규 위해요인 등록부 관리 등록 API")
    @PostMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> insertHazardTaxonomy(@Valid @RequestBody(required=true) TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {

        service.insertTaxonomy(tbAvnHazardLv3Dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 정보 수정", description = "위해요인 등록부 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> updateHazardTaxonomy(
            @PathVariable(value="hazardLv3Id", required=true) String hazardLv3Id,
            @Valid @RequestBody(required=true) TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {

        tbAvnHazardLv3Dto.setHazardLv3Id(hazardLv3Id);
        service.updateTaxonomy(tbAvnHazardLv3Dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 삭제", description = "위해요인 등록부 관리 삭제 API")
    @Parameter(name = "hazardLv3Id", description = "")
    @DeleteMapping(value = "/admin/criteria/taxonomies/{hazardLv3Id}")
    public ResponseEntity<?> deleteHazardRegister(@PathVariable(value="hazardLv3Id", required=true) String hazardLv3Id) {

        service.deleteTaxonomy(hazardLv3Id);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Potential Consequence 목록 조회
     *
     * @param pageNum the page num
     * @param pageSize the page size
     * @param reportType the report type
     * @param nameKo the title name korean
     * @param nameEn the title name english
     * @param useYn the use yn
     * @param notes the notes
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Potential Consequence 목록 조회", description = "Potential Consequence 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "ConsequenceId", description = "잠재결과ID"),
            @Parameter(name = "reportType", description = "리포트타입"),
            @Parameter(name = "nameKo", description = "잠재적결과 국문명"),
            @Parameter(name = "nameEn", description = "잠재적결과 영문명"),
            @Parameter(name = "useYn", description = "사용여부"),
            @Parameter(name = "notes", description = "비고")
    })
    @GetMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> getPotentialConsequenceList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="reportType") String reportType
            ,@RequestParam(value="nameKo") String nameKo
            ,@RequestParam(value="nameEn") String nameEn
            ,@RequestParam(value="useYn") String useYn
            ,@RequestParam(value="notes") String notes)  {

        // 조회조건 parameter
        TbAvnConsequenceDto tbAvnConsequenceDto = new TbAvnConsequenceDto();

        tbAvnConsequenceDto.setReportType(reportType);   // 리포트 타입
        tbAvnConsequenceDto.setNameKo(nameKo);           // 잠재적결과 국문명
        tbAvnConsequenceDto.setNameEn(nameEn);           // 잠재적결과 영문명
        tbAvnConsequenceDto.setUseYn(useYn);             // 사용여부
        tbAvnConsequenceDto.setNotes(notes);             // 비고

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnConsequenceDto> pageList = service.selectConsequenceList(tbAvnConsequenceDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "Potential Consequence 상세정보 조회", description = "Potential Consequence 상세정보 조회 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @GetMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> getPotentialConsequenceInfo(@PathVariable(value="consequenceId", required=true) String consequenceId) {

        TbAvnConsequenceDto result = service.selectConsequenceDetail(consequenceId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 Potential Consequence 등록", description = "신규 Potential Consequence 등록 API")
    @PostMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> insertPotentialConsequence(@Valid @RequestBody(required=true) TbAvnConsequenceDto tbAvnConsequenceDto) {

        service.insertPotentialConsequence(tbAvnConsequenceDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 정보 수정", description = "Potential Consequence 정보 수정 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @PutMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> updatePotentialConsequence(
            @PathVariable(value="consequenceId", required=true) Long consequenceId,
            @Valid @RequestBody(required=true) TbAvnConsequenceDto tbAvnConsequenceDto) {

        tbAvnConsequenceDto.setConsequenceId(consequenceId);
        service.updatePotentialConsequence(tbAvnConsequenceDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 삭제", description = "Potential Consequence 삭제 API")
    @Parameter(name = "consequenceId", description = "잠재결과 ID")
    @DeleteMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> deletePotentialConsequence(@PathVariable(value="consequenceId", required=true) String consequenceId) {

        service.deletePotentialConsequence(consequenceId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 이벤트 타입 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "이벤트 타입 관리 목록 조회", description = "이벤트 타입 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> getEventTypeList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "이벤트 타입 관리 상세정보 조회", description = "이벤트 타입 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> getEventTypeInfo(@PathVariable(value="eventTypeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 이벤트 타입 관리 등록", description = "신규 이벤트 타입 관리 등록 API")
    @PostMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> insertEventType(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 정보 수정", description = "이벤트 타입 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> updateEventType(
            @PathVariable(value="eventTypeId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 삭제", description = "이벤트 타입 관리 삭제 API")
    @DeleteMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> deleteEventType(@PathVariable(value="eventTypeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * RISK MATRIX 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "RISK MATRIX 관리 목록 조회", description = "RISK MATRIX 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix")
    public ResponseEntity<?> getRiskMatrixList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "RISK MATRIX 관리 상세정보 조회", description = "RISK MATRIX 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> getRiskMatrixInfo(@PathVariable(value="riskMatrixId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "RISK MATRIX 관리 정보 수정", description = "RISK MATRIX 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> updateRiskMatrix(
            @PathVariable(value="riskMatrixId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }
}
