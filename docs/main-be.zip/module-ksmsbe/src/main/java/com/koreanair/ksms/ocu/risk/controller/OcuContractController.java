package com.koreanair.ksms.ocu.risk.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.risk.service.OcuContractService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 위험성평가 - 협력사 위험성평가
 */
@Tag(name = "OcuContract", description = "위험성평가 - 협력사 위험성평가 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuContractController {

    @Autowired
    OcuContractService service;

    /**
     * 협력사 위험성평가 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "협력사 위험성평가 목록 조회", description = "협력사 위험성평가 목록 조회 API")
    @GetMapping(value = "/risk/contracts")
    public ResponseEntity<?> getContractList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "협력사 위험성평가 상세정보 조회", description = "협력사 위험성평가 상세정보 조회 API")
    @GetMapping(value = "/risk/contracts/{contractId}")
    public ResponseEntity<?> getContractInfo(@PathVariable(value="contractId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 협력사 위험성평가 등록", description = "신규 협력사 위험성평가 등록 API")
    @PostMapping(value = "/risk/contracts")
    public ResponseEntity<?> insertContract(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력사 위험성평가 정보 수정", description = "협력사 위험성평가 정보 수정 API")
    @PutMapping(value = "/risk/contracts/{contractId}")
    public ResponseEntity<?> updateContract(
            @PathVariable(value="contractId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력사 위험성평가 삭제", description = "협력사 위험성평가 삭제 API")
    @DeleteMapping(value = "/risk/contracts/{contractId}")
    public ResponseEntity<?> deleteContract(@PathVariable(value="contractId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
