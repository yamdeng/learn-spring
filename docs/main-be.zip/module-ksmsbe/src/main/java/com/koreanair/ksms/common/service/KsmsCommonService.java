package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.*;
import io.vertx.core.json.JsonObject;

import java.util.List;
import java.util.Map;

public interface KsmsCommonService {

    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    List<TbSysUserDto> selectUserList(String searchWord, String deptCd);

    JsonObject selectMessagesAll();

    TbSysUserDto selectUserProfile(String userId);

    List<TbSysVirtualGroupDto> selectUserGroups(String userId);
}
