package com.koreanair.ksms.avn.sftp.service;

import com.koreanair.ksms.avn.sftp.dto.TbAvnSafetyPolicyDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnSafetyPolicyServiceImpl extends AbstractBaseService implements AvnSafetyPolicyService {
    @Override
    public TbAvnSafetyPolicyDto selectSafetyPolicyImg(){
        return commonSql.selectOne("AvnSafetyPolicy.selectSafetyPolicyImg");
    }
}
