package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "중대재해대응훈련")
public class OcuTrainingDto extends CommonDto {
	
	@Schema(description = "번호")
    @NotBlank
    private int num;
	
    @Schema(description = "훈련_ID")
    @NotBlank
    private int trainId;
    
    @Schema(description = "재난_유형_코드")
    @NotBlank
    private String dssTypeCd;
    
    @Schema(description = "기타_유형")
    private String etcType;
    
    @Schema(description = "훈련_일자")
    @NotBlank
    private String trainDt;
    
    @Schema(description = "훈련_장소")
    @NotBlank
    private String trainLocation;
    
    @Schema(description = "참석자")
    @NotBlank
    private String prtc;
    
    @Schema(description = "훈련_명")
    @NotBlank
    private String trainNm;
    
    @Schema(description = "평가_내용")
    @NotBlank
    private String evalContent;
    
    @Schema(description = "첨부_파일_ID")
    private String fileId;
    
    @Schema(description = "첨부_링크_ID")
    private String linkId;
}
