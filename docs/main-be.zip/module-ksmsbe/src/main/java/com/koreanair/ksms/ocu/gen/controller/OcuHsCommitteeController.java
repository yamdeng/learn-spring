package com.koreanair.ksms.ocu.gen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.dto.OcuHsCommitteeDto;
import com.koreanair.ksms.ocu.gen.service.OcuHsCommitteeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전경영 - 안전보건협의체
 */
@Tag(name = "OcuHsCommittee", description = "안전경영 - 안전보건협의체 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuHsCommitteeController {

    @Autowired
    OcuHsCommitteeService service;

    /**
     * 안전보건협의체 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전보건협의체 목록 조회", description = "안전보건협의체 목록 조회 API")
    @GetMapping(value = "/general/hsCommittee")
    public ResponseEntity<?> getPageList(		
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
           ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           ,@RequestParam(value="advCmitImplmYm", required=false) String advCmitImplmYm 
           ,@RequestParam(value="advCmitImplmYY", required=false) String advCmitImplmYY 
           ,@RequestParam(value="advCmitSectCd", required=false) String advCmitSectCd
    	   ,@RequestParam(value="advCmitDeptCd", required=false) String advCmitDeptCd
    	   ,@RequestParam(value="activeTab", required=false) String activeTab
    	   ) {

	  PageHelper.startPage(pageNum, pageSize);
	  
	  OcuHsCommitteeDto dto = new OcuHsCommitteeDto();
	  
	  dto.setAdvCmitImplmYY(advCmitImplmYY);
	  dto.setAdvCmitImplmYm(advCmitImplmYm);
	  dto.setAdvCmitSectCd(advCmitSectCd);
	  dto.setAdvCmitDeptCd(advCmitDeptCd);
	  dto.setActiveTab(activeTab);

	  PageInfo<OcuHsCommitteeDto> pageList = service.selectHsCommitteeList(dto);
      return ResponseUtil.createSuccessResponse(pageList);
    }

    /**
     * 안전보건협의체 상세정보 조회
     * @param advCmitId
     * @return
     */
    @Operation(summary = "안전보건협의체 상세정보 조회", description = "안전보건협의체 상세정보 조회 API")
    @GetMapping(value = "/general/hsCommittee/{advCmitId}")
    public ResponseEntity<?> getHsCommitteeInfo(@PathVariable(value="advCmitId") int advCmitId) {

    	OcuHsCommitteeDto result = service.getHsCommitteeInfo(advCmitId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * 신규 안전보건협의체 등록
     * @param dto
     * @return
     */
    @Operation(summary = "신규 안전보건협의체 등록", description = "신규 안전보건협의체 등록 API")
    @PostMapping(value = "/general/hsCommittee")
    public ResponseEntity<?> insertHsCommittee(@Valid @RequestBody() OcuHsCommitteeDto dto) {
    	service.insertHsCommittee(dto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전보건협의체 정보 수정
     * @param advCmitId
     * @param dto
     * @return
     */
    @Operation(summary = "안전보건협의체 정보 수정", description = "안전보건협의체 정보 수정 API")
    @PutMapping(value = "/general/hsCommittee/{advCmitId}")
    public ResponseEntity<?> updateHsCommittee(
            @PathVariable(value="advCmitId") int advCmitId,
            @Valid @RequestBody() OcuHsCommitteeDto dto) {

    	dto.setAdvCmitId(advCmitId);
        service.updateHsCommittee(dto);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전보건협의체 삭제
     * @param advCmitId
     * @return
     */
    @Operation(summary = "안전보건협의체 삭제", description = "안전보건협의체 삭제 API")
    @DeleteMapping(value = "/general/hsCommittee/{advCmitId}")
    public ResponseEntity<?> deleteHsCommittee(@PathVariable(value="advCmitId") int advCmitId) {
    	service.deleteHsCommittee(advCmitId);
        return ResponseUtil.createSuccessResponse();
    }
}
