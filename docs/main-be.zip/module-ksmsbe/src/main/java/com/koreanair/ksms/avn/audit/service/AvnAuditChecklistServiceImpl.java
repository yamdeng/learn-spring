package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.TBAuditChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistChapterDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditChecklistDto;
import com.koreanair.ksms.avn.audit.dto.TBAuditQuestionDto;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AvnAuditChecklistServiceImpl extends AbstractBaseService implements AvnAuditChecklistService {

    @Override
    public List<TBAuditChecklistChapterDto> selectAuditChecklist(TBAuditChecklistDto searchDto) {
        return commonSql.selectList("AvnAuditChecklist.selectAuditChecklist", searchDto);
    }

    @Override
    public List<ChecklistRevisionsVo> selectAuditChecklistRevision(int checklistOriginId) {
        return commonSql.selectList("AvnAuditChecklist.selectAuditChecklistRevision", checklistOriginId);
    }

    @Override
    public List<TBAuditQuestionDto> selectAuditQuestionList(TBAuditChapterDto searchDto) {
        return commonSql.selectList("AvnAuditChecklist.selectAuditQuestionList", searchDto);
    }

}
