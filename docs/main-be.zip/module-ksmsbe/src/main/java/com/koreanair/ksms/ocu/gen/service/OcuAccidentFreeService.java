package com.koreanair.ksms.ocu.gen.service;

public interface OcuAccidentFreeService {
}
