package com.koreanair.ksms.avn.main.controller;

import com.koreanair.ksms.avn.main.service.AvnMainService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 항공안전 메인 Controller
 */
@Tag(name = "AvnMain", description = "항공안전 메인 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnMainController {

    @Autowired
    AvnMainService service;

    /**
     * 메인화면 정보 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "메인화면 정보 조회", description = "메인화면 정보 조회 API")
    @GetMapping(value = "/main-infos")
    public ResponseEntity<?> getMainInfo(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
