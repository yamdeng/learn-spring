package com.koreanair.ksms.ocu.gen.controller;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.dto.OcuZeroHzdGoalDto;
import com.koreanair.ksms.ocu.gen.service.OcuZeroHzdGoalService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 *  무재해운동 목표 관리 Controller
 */
@Tag(name = "무재해운동 목표 관리", description = "무재해운동 목표 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuZeroHzdGoalController {

    @Autowired
    private OcuZeroHzdGoalService ocuzerohzdgoalService;

    /**
     * 무재해운동 목표 관리 목록 조회
     * @param pageNum
     * @param pageSize
     * @param advCmitImplmYm
     * @param advCmitImplmYY
     * @param advCmitSectCd
     * @param advCmitDeptCd
     * @param activeTab
     * @return
     */
    @Operation(summary = "무재해운동 목표 관리 목록 조회", description = "무재해운동 목표 관리 목록 조회 API")
    @GetMapping(value = "/general/zeroHzdGoal")
    public ResponseEntity<?> getPageList(		
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
           ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           ,@RequestParam(value="zeroHzdDeptCd", required=false) String zeroHzdDeptCd 
           ,@RequestParam(value="completGoalMltp", required=false) String completGoalMltp 
    	   ) {
    	
		PageHelper.startPage(pageNum, pageSize);
		
		log.debug("조회@@@@@@@@@@@@@@@");
		
		OcuZeroHzdGoalDto dto = new OcuZeroHzdGoalDto();
		  
		dto.setZeroHzdDeptCd(zeroHzdDeptCd);
		if(!StringUtils.isEmpty(completGoalMltp)) {
			dto.setCompletGoalMltp(Integer.parseInt(completGoalMltp));
		}
	
		PageInfo<OcuZeroHzdGoalDto> pageList = ocuzerohzdgoalService.selectList(dto);
	    return ResponseUtil.createSuccessResponse(pageList);
	}

    /**
     * 무재해운동 목표 관리 상세 조회
     * @param zeroHzdId
     * @return
     */
    @Operation(summary = "무재해운동 목표 관리 상세 조회", description = "무재해운동 목표 관리 상세 조회 API")
    @GetMapping(value = "/general/zeroHzdGoal/{zeroHzdId}")
    public ResponseEntity<?> selectList(@PathVariable(value="zeroHzdId") int zeroHzdId) {

        OcuZeroHzdGoalDto result = ocuzerohzdgoalService.select(zeroHzdId);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * 무재해운동 목표 관리 등록
     * @param reqDto
     * @return
     */
    @Operation(summary = "무재해운동 목표 관리 등록", description = "무재해운동 목표 관리 등록 API")
    @PostMapping(value = "/general/zeroHzdGoal")
    public ResponseEntity<?> insert(@Valid @RequestBody() OcuZeroHzdGoalDto reqDto){
        ocuzerohzdgoalService.insert(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 무재해운동 목표 관리 수정
     * @param zeroHzdId
     * @param reqDto
     * @return
     */
    @Operation(summary = "무재해운동 목표 관리 수정", description = "무재해운동 목표 관리 수정 API")
    @PostMapping(value = "/general/zeroHzdGoal/{zeroHzdId}/update")
    public ResponseEntity<?> update(
            @PathVariable(value="zeroHzdId") int zeroHzdId,
            @Valid @RequestBody() OcuZeroHzdGoalDto.Post reqDto) {
    	
    	OcuZeroHzdGoalDto.Create form = reqDto.getForm();
        ocuzerohzdgoalService.update(reqDto);
        
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 무재해운동 목표 관리 삭제
     * @param zeroHzdId
     * @return
     */
    @Operation(summary = "무재해운동 목표 관리 삭제", description = "무재해운동 목표 관리 삭제 API")
    @DeleteMapping(value = "/general/zeroHzdGoal/{zeroHzdId}")
    public ResponseEntity<?> delete(@PathVariable(value="zeroHzdId") int zeroHzdId) {
        ocuzerohzdgoalService.delete(zeroHzdId);
        return ResponseUtil.createSuccessResponse();
    }
    
 
    
    /**
     * 무재해운동 이력 조회
     * @param codeGroupId
     * @return
     */
    @Operation(summary = "무재해운동 이력 조회", description = "무재해운동 이력 조회 API")
    @GetMapping(value = "/general/selectZeroHzdList/{zeroHzdId}")
    public ResponseEntity<?> selectZeroHzdList(@PathVariable(value="zeroHzdId") int zeroHzdId) {

        List<OcuZeroHzdGoalDto> resultList = ocuzerohzdgoalService.selectZeroHzdList(zeroHzdId);
        return ResponseUtil.createSuccessResponse(resultList);
    }
    
    
    /**
     * 무재해운동 목표 및 이력 등록
     * @param reqDto
     * @return
     */
    @Operation(summary = "무재해운동 목표 및 이력 등록", description = "무재해운동 목표 및 이력 등록 API")
    @PostMapping(value = "/general/zeroHzdGoal/saveZeroHzdGoalStatus")
    public ResponseEntity<?> saveZeroHzdGoalStatus(@Valid @RequestBody() OcuZeroHzdGoalDto reqDto){
    	
    	log.debug("등록@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@::" +reqDto);
    	
        ocuzerohzdgoalService.saveZeroHzdGoalStatus(reqDto);
        return ResponseUtil.createSuccessResponse();
    }
    
  
    /**
     * 무재해운동 중복 체크
     * @param zeroHzdId
     * @return
     */
    @Operation(summary = "무재해운동 중복 체크", description = "무재해운동 중복 체크 API")
    @GetMapping(value = "/general/selectZeroHzdGoalDupChk")
    public ResponseEntity<?> selectZeroHzdGoalDupChk( @RequestParam(value="zeroHzdDeptCd", required=false) String zeroHzdDeptCd) {

    	log.debug("중복체크@@@@@@@@@@@@@@@@@@@@@@");
        int result = ocuzerohzdgoalService.selectZeroHzdGoalDupChk(zeroHzdDeptCd);
        
        return ResponseUtil.createSuccessResponse(result);
    }
 

}


