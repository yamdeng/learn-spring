package com.koreanair.ksms.common.utils;

import com.amazonaws.encryptionsdk.AwsCrypto;
import com.amazonaws.encryptionsdk.CryptoResult;
import lombok.experimental.UtilityClass;
import software.amazon.cryptography.materialproviders.IKeyring;
import software.amazon.cryptography.materialproviders.MaterialProviders;
import software.amazon.cryptography.materialproviders.model.CreateAwsKmsMultiKeyringInput;
import software.amazon.cryptography.materialproviders.model.MaterialProvidersConfig;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;

@UtilityClass
public class DataCryptUtil {

    // TODO [sixone] 이 유틸리티는 AWS KMS가 구성 된 이후 사용 가능하다.

    private static final AwsCrypto crypto = AwsCrypto.standard();
    private static final MaterialProviders materialProviders = MaterialProviders.builder()
            .MaterialProvidersConfig(MaterialProvidersConfig.builder().build())
            .build();
    static Map<String, String> encryptionContext = Collections.singletonMap("Purpose", "DataEncDecUtil Encryption");

    public static String encrypt(String plaintext, String keyArn) {
        IKeyring kmsKeyring = createKmsKeyring(keyArn);

        CryptoResult<byte[], ?> encryptResult = crypto.encryptData(kmsKeyring,
                plaintext.getBytes(StandardCharsets.UTF_8),
                encryptionContext);

        final byte[] ciphertext = encryptResult.getResult();

        // Convert ciphertext to Base64 encoded string
        return Base64.getEncoder().encodeToString(ciphertext);
    }

    public static String decrypt(String encodedCiphertext, String keyArn) {
        // Decode the Base64 string back to a byte array
        byte[] ciphertext = Base64.getDecoder().decode(encodedCiphertext);

        IKeyring kmsKeyring = createKmsKeyring(keyArn);

        CryptoResult<byte[], ?> decryptResult = crypto.decryptData(kmsKeyring,
                ciphertext, encryptionContext);

        return new String(decryptResult.getResult(), StandardCharsets.UTF_8);
    }

    private static IKeyring createKmsKeyring(String keyArn) {
        CreateAwsKmsMultiKeyringInput keyringInput = CreateAwsKmsMultiKeyringInput.builder()
                .generator(keyArn)
                .build();
        return materialProviders.CreateAwsKmsMultiKeyring(keyringInput);
    }
}