package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.koreanair.ksms.avn.sfta.dto.OpStatusDto;
import com.koreanair.ksms.avn.sfta.dto.SpiStatusDto;
import com.koreanair.ksms.common.dto.TbAvnSpiDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSpiSptServiceImpl extends AbstractBaseService implements AvnSpiSptService {

    @Override
    public List<SpiStatusDto> selectSPICodeList(SpiStatusDto tbSsSpiDto) {
        List<SpiStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectSPICodeList", tbSsSpiDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList1(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList1", opStatusDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList2(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList2", opStatusDto);
        return resultList;
    }

    @Override
    public List<OpStatusDto> selectOpStatusList3(OpStatusDto opStatusDto) {
        List<OpStatusDto> resultList = commonSql.selectList("AvnSpiSpt.selectOpStatusList3", opStatusDto);
        return resultList;
    }

    @Override
    public List<TbAvnSpiDto> selectSpiIndicatorList(TbAvnSpiDto tbAvnSpiDto) {
        List<TbAvnSpiDto> resultList = commonSql.selectList("AvnSpiSpt.selectSpiIndicatorList", tbAvnSpiDto);
        return resultList;
    }

}
