package com.koreanair.ksms.ocu.gen.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuCommitteeDto;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전보건협의체 ServiceImpl
 */
@Slf4j
@Service
public class OcuCommitteeServiceImpl extends AbstractBaseService implements OcuCommitteeService {

	/**
	 * 산업안전보건위원회 목록 조회
	 */
	@Override
	public PageInfo<OcuCommitteeDto> selectCommitteeList(OcuCommitteeDto dto) {
		List<OcuCommitteeDto> resultList = commonSql.selectList("OcuCommittee.selectCommitteeList", dto);
	    return PageInfo.of(resultList);
	}

	/**
	 * 산업안전보건위원회 상세 조회
	 */
	@Override
	public OcuCommitteeDto getCommitteeInfo(int ocuCommitId) {
		return commonSql.selectOne("OcuCommittee.getCommitteeInfo", ocuCommitId);
	}

	/**
	 * 산업안전보건위원회 입력
	 */
	@Override
	@Transactional
	public void insertCommittee(@Valid OcuCommitteeDto dto) {		
		commonSql.insert("OcuCommittee.insertCommittee", dto);	
	}

	/**
	 * 산업안전보건위원회 수정
	 */
	@Override
	@Transactional
	public void updateCommittee(@Valid OcuCommitteeDto dto) {
		commonSql.update("OcuCommittee.updateCommittee", dto);
		
	}

	/**
	 * 산업안전보건위원회 삭제
	 */
	@Override
	@Transactional
	public void deleteCommittee(int ocuCommitId) {
		commonSql.delete("OcuCommittee.deleteCommittee", ocuCommitId);
		
	}
	

}
	
