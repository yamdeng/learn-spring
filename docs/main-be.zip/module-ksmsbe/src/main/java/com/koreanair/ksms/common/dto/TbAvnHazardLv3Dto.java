package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "위해요인 Lv3 정보")
public class TbAvnHazardLv3Dto extends CommonDto {
    
    @Schema(description = "해저드 레벨3 ID")
    @NotBlank
    private String hazardLv3Id;
    
    @Schema(description = "해저드 레벨2 ID")
    @NotBlank
    private String hazardLv2Id;
    
    @Schema(description = "위해요인 Lv3 명")
    @NotBlank
    private String lvText;
    
    @Schema(description = "메모")
    private String notes;
    
    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    @NotBlank
    private String viewOrder;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "hazard detail")
    private String hazardDetail;
    
    @Schema(description = "sources")
    private String sources;
    
    @Schema(description = "potential consequence")
    private String potentialConsequence;
    
    @Schema(description = "삭제자 사번")
    private String delUserId;
    
    @Schema(description = "삭제일시")
    private String delDttm;
}
