package com.koreanair.ksms.ocu.mgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.dto.OcuTrainingDto;
import com.koreanair.ksms.ocu.mgmt.service.OcuTrainingService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Tag(name = "중대재해대응훈련", description = "중대재해대응훈련 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuTrainingController {

    @Autowired
    private OcuTrainingService ocuTrainingService;

    @Operation(summary = "중대재해대응훈련 상세 조회", description = "중대재해대응훈련 상세 조회 API")
    @GetMapping("/management/training/{id}")
    public ResponseEntity<?> selectOcuTraining(@PathVariable(value="id", required=true) int id) {
        
        OcuTrainingDto result = ocuTrainingService.selectOcuTraining(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "중대재해대응훈련 목록 조회", description = "중대재해대응훈련 목록 조회 API")
    @GetMapping("/management/training")
    public ResponseEntity<?> selectOcuTrainingList(@ModelAttribute OcuTrainingDto reqDto) {

        PageInfo<OcuTrainingDto> resultList = ocuTrainingService.selectOcuTrainingList(reqDto);
        return ResponseUtil.createSuccessResponse(resultList);
    }
    
    @Operation(summary = "중대재해대응훈련 일괄 저장", description = "중대재해대응훈련 일괄 저장 API")
    @PostMapping("/management/training/bulk")
    public ResponseEntity<?> saveOcuTraining(@RequestBody List<OcuTrainingDto> reqDtoList) {

        ocuTrainingService.saveOcuTraining(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "중대재해대응훈련 등록", description = "중대재해대응훈련 등록 API")
    @PostMapping(value = "/management/training")
    public ResponseEntity<?> insertOcuTraining(@Valid @RequestBody OcuTrainingDto reqDto){
        ocuTrainingService.insertOcuTraining(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "중대재해대응훈련 수정", description = "중대재해대응훈련 수정 API")
    @PutMapping(value = "/management/training")
    public ResponseEntity<?> updateOcuTraining(@Valid @RequestBody(required=true) OcuTrainingDto reqDto){
        
        ocuTrainingService.updateOcuTraining(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "중대재해대응훈련 삭제", description = "중대재해대응훈련 삭제 API")
    @DeleteMapping(value = "/management/training/{id}")
    public ResponseEntity<?> deleteOcuTraining(@PathVariable(value="id", required=true) int id){
        ocuTrainingService.deleteOcuTraining(id);
        return ResponseUtil.createSuccessResponse();
    }
}


