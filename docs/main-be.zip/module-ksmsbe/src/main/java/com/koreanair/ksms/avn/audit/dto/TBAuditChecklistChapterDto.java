package com.koreanair.ksms.avn.audit.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / Checklist 목록")
public class TBAuditChecklistChapterDto {

    @Schema(description = "checklistId")
    @NotBlank
    private int checklistId;

    @Schema(description = "원본아이디")
    private int checklistOriginId;

    @Schema(description = "체크리스트명")
    private String checklistName;

    @Schema(description = "Audit 부문")
    private String division;

    List<Map> chapters;
}
