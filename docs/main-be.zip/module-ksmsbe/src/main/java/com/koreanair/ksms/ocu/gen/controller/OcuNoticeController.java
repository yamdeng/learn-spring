package com.koreanair.ksms.ocu.gen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;
import com.koreanair.ksms.ocu.gen.service.OcuNoticeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 안전경영 - 공지사항 Controller
 */
@Tag(name = "OcuNotice", description = "안전경영 - 공지사항 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuNoticeController {
	
    
    // 정석
//    @PutMapping(value = "/무재해운동/{무재해운동_ID}/현황정보/{무재해운동_현황_ID}")
//    @PutMapping(value = "/무재해운동현황/{무재해운동_현황_ID}")
    // DB구조

    @Autowired
    OcuNoticeService service;

    /**
     * 공지사항 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "공지사항 목록 조회", description = "공지사항 목록 조회 API")
    @GetMapping(value = "/general/notice")
    public ResponseEntity<?> getPageList(		
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
           ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           ,@RequestParam(value="sectCd", required=false) String sectCd 
    	   ,@RequestParam(value="fromRegDttm", required=false) String fromRegDttm
    	   ,@RequestParam(value="toRegDttm", required=false) String toRegDttm
    	   ,@RequestParam(value="selectType", required=false) String selectType
    	   ,@RequestParam(value="noticeTitle", required=false) String noticeTitle) {

	  PageHelper.startPage(pageNum, pageSize);
	  
	  OcuNoticeDto dto = new OcuNoticeDto();
	  
	  dto.setSectCd(sectCd);
	  dto.setFromRegDttm(fromRegDttm);
	  dto.setToRegDttm(toRegDttm);
	  dto.setSelectType(selectType);
	  dto.setNoticeTitle(noticeTitle);
	  
	  PageInfo<OcuNoticeDto> pageList = service.selectGetNoticeList(dto);
      return ResponseUtil.createSuccessResponse(pageList);
	
 
    }

    @Operation(summary = "공지사항 상세정보 조회", description = "공지사항 상세정보 조회 API")
    @GetMapping(value = "/general/notice/{noticeId}")
    public ResponseEntity<?> getNoticeInfo(@PathVariable(value="noticeId") int noticeId) {
    	OcuNoticeDto result = service.getNoticeInfo(noticeId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 공지사항 등록", description = "신규 공지사항 등록 API")
    @PostMapping(value = "/general/notice")
    public ResponseEntity<?> insertNotice(@Valid @RequestBody() OcuNoticeDto dto) {
    	service.insertNotice(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "공지사항 정보 수정", description = "공지사항 정보 수정 API")
    @PutMapping(value = "/general/notice/{noticeId}")    
    public ResponseEntity<?> updateNotice(
            @PathVariable(value="noticeId") int noticeId,
            @Valid @RequestBody() OcuNoticeDto dto) {

        dto.setNoticeId(noticeId);
        service.updateNotice(dto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "공지사항 삭제", description = "공지사항 삭제 API")
    @DeleteMapping(value = "/general/notice/{noticeId}")
    public ResponseEntity<?> deleteNotice(@PathVariable(value="noticeId") int noticeId) {
    	service.deleteNotice(noticeId);
        return ResponseUtil.createSuccessResponse();
    }
}

