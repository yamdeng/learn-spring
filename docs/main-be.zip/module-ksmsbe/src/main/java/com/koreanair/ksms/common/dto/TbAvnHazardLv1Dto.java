package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "위해요인 레벨 1 정보")
public class TbAvnHazardLv1Dto extends CommonDto {
    
    @Schema(description = "해저드 레벨1 ID")
    @NotBlank
    private String hazardLv1Id;
    
    @Schema(description = "위해요인 Lv1 명")
    @NotBlank
    private String lvText;
    
    @Schema(description = "메모")
    private String notes;
    
    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    @NotBlank
    private String viewOrder;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "삭제자 사번")
    private String delUserId;
    
    @Schema(description = "삭제일시")
    private String delDttm;
}
