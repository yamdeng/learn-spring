package com.koreanair.ksms.avn.admin.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnManualDto;
import com.koreanair.ksms.avn.admin.service.AvnBulletinManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 게시판관리
 */
@Tag(name = "AvnBulletinManage", description = "관리자 - 게시판관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnBulletinManageController {

    @Autowired
    AvnBulletinManageService service;

    /**
     * Newsletter 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Newsletter 목록 조회", description = "Newsletter 목록 조회 API")
    @GetMapping(value = "/admin/board/newsletters")
    public ResponseEntity<?> getNewsletterList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Newsletter 상세정보 조회", description = "Newsletter 상세정보 조회 API")
    @GetMapping(value = "/admin/board/newsletters/{newsletterId}")
    public ResponseEntity<?> getNewsletterInfo(@PathVariable(value="newsletterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Newsletter 등록", description = "신규 Newsletter 등록 API")
    @PostMapping(value = "/admin/board/newsletters")
    public ResponseEntity<?> insertNewsletter(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Newsletter 정보 수정", description = "Newsletter 정보 수정 API")
    @PutMapping(value = "/admin/board/newsletters/{newsletterId}")
    public ResponseEntity<?> updateNewsletter(
            @PathVariable(value="newsletterId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Newsletter 삭제", description = "Newsletter 삭제 API")
    @DeleteMapping(value = "/admin/board/newsletters/{newsletterId}")
    public ResponseEntity<?> deleteNewsletter(@PathVariable(value="newsletterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * SkySafety21 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SkySafety21 목록 조회", description = "SkySafety21 목록 조회 API")
    @GetMapping(value = "/admin/board/sky-safety21")
    public ResponseEntity<?> getSkySafety21List(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "SkySafety21 상세정보 조회", description = "SkySafety21 상세정보 조회 API")
    @GetMapping(value = "/admin/board/sky-safety21/{skysafetyId}")
    public ResponseEntity<?> getSkySafety21Info(@PathVariable(value="skysafetyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 SkySafety21 등록", description = "신규 SkySafety21 등록 API")
    @PostMapping(value = "/admin/board/sky-safety21")
    public ResponseEntity<?> insertSkySafety21(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "SkySafety21 정보 수정", description = "SkySafety21 정보 수정 API")
    @PutMapping(value = "/admin/board/sky-safety21/{skysafetyId}")
    public ResponseEntity<?> updateSkySafety21(
            @PathVariable(value="skysafetyId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "SkySafety21 삭제", description = "SkySafety21 삭제 API")
    @DeleteMapping(value = "/admin/board/sky-safety21/{skysafetyId}")
    public ResponseEntity<?> deleteSkySafety21(@PathVariable(value="skysafetyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Excellence 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Excellence 목록 조회", description = "Excellence 목록 조회 API")
    @GetMapping(value = "/admin/board/excellences")
    public ResponseEntity<?> getExcellenceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Excellence 상세정보 조회", description = "Excellence 상세정보 조회 API")
    @GetMapping(value = "/admin/board/excellences/{excellenceId}")
    public ResponseEntity<?> getExcellenceInfo(@PathVariable(value="excellenceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Excellence 등록", description = "신규 Excellence 등록 API")
    @PostMapping(value = "/admin/board/excellences")
    public ResponseEntity<?> insertExcellence(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Excellence 정보 수정", description = "Excellence 정보 수정 API")
    @PutMapping(value = "/admin/board/excellences/{excellenceId}")
    public ResponseEntity<?> updateExcellence(
            @PathVariable(value="excellenceId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Excellence 삭제", description = "Excellence 삭제 API")
    @DeleteMapping(value = "/admin/board/excellences/{excellenceId}")
    public ResponseEntity<?> deleteExcellence(@PathVariable(value="excellenceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * WorkShop 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "WorkShop 목록 조회", description = "WorkShop 목록 조회 API")
    @GetMapping(value = "/admin/board/workshops")
    public ResponseEntity<?> getWorkShopList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "WorkShop 상세정보 조회", description = "WorkShop 상세정보 조회 API")
    @GetMapping(value = "/admin/board/workshops/{workshopId}")
    public ResponseEntity<?> getWorkShopInfo(@PathVariable(value="workshopId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 WorkShop 등록", description = "신규 WorkShop 등록 API")
    @PostMapping(value = "/admin/board/workshops")
    public ResponseEntity<?> insertWorkShop(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "WorkShop 정보 수정", description = "WorkShop 정보 수정 API")
    @PutMapping(value = "/admin/board/workshops/{workshopId}")
    public ResponseEntity<?> updateWorkShop(
            @PathVariable(value="workshopId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "WorkShop 삭제", description = "WorkShop 삭제 API")
    @DeleteMapping(value = "/admin/board/workshops/{workshopId}")
    public ResponseEntity<?> deleteWorkShop(@PathVariable(value="workshopId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Safety Day 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Safety Day 목록 조회", description = "Safety Day 목록 조회 API")
    @GetMapping(value = "/admin/board/safety-days")
    public ResponseEntity<?> getSafetyDayList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Safety Day 상세정보 조회", description = "Safety Day 상세정보 조회 API")
    @GetMapping(value = "/admin/board/safety-days/{safetyDayId}")
    public ResponseEntity<?> getSafetyDayInfo(@PathVariable(value="safetyDayId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Safety Day 등록", description = "신규 Safety Day 등록 API")
    @PostMapping(value = "/admin/board/safety-days")
    public ResponseEntity<?> insertSafetyDay(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Safety Day 정보 수정", description = "Safety Day 정보 수정 API")
    @PutMapping(value = "/admin/board/safety-days/{safetyDayId}")
    public ResponseEntity<?> updateSafetyDay(
            @PathVariable(value="safetyDayId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Safety Day 삭제", description = "Safety Day 삭제 API")
    @DeleteMapping(value = "/admin/board/safety-days/{safetyDayId}")
    public ResponseEntity<?> deleteSafetyDay(@PathVariable(value="safetyDayId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * SPIP(안전장려금제도 관리) 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SPIP(안전장려금제도 관리) 목록 조회", description = "SPIP(안전장려금제도 관리) 목록 조회 API")
    @GetMapping(value = "/admin/board/spips")
    public ResponseEntity<?> getSPIPList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "SPIP(안전장려금제도 관리) 상세정보 조회", description = "SPIP(안전장려금제도 관리) 상세정보 조회 API")
    @GetMapping(value = "/admin/board/spips/{spipId}")
    public ResponseEntity<?> getSPIPInfo(@PathVariable(value="spipId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 SPIP(안전장려금제도 관리) 등록", description = "신규 SPIP(안전장려금제도 관리) 등록 API")
    @PostMapping(value = "/admin/board/spips")
    public ResponseEntity<?> insertSPIP(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "SPIP(안전장려금제도 관리) 정보 수정", description = "SPIP(안전장려금제도 관리) 정보 수정 API")
    @PutMapping(value = "/admin/board/spips/{spipId}")
    public ResponseEntity<?> updateSPIP(
            @PathVariable(value="spipId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "SPIP(안전장려금제도 관리) 삭제", description = "SPIP(안전장려금제도 관리) 삭제 API")
    @DeleteMapping(value = "/admin/board/spips/{spipId}")
    public ResponseEntity<?> deleteSPIP(@PathVariable(value="spipId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전목표 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전목표 목록 조회", description = "안전목표 목록 조회 API")
    @GetMapping(value = "/admin/board/safety-goals")
    public ResponseEntity<?> getSafetyGoalList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전목표 상세정보 조회", description = "안전목표 상세정보 조회 API")
    @GetMapping(value = "/admin/board/safety-goals/{safetyGoalId}")
    public ResponseEntity<?> getSafetyGoalInfo(@PathVariable(value="safetyGoalId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전목표 등록", description = "신규 안전목표 등록 API")
    @PostMapping(value = "/admin/board/safety-goals")
    public ResponseEntity<?> insertSafetyGoal(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전목표 정보 수정", description = "안전목표 정보 수정 API")
    @PutMapping(value = "/admin/board/safety-goals/{safetyGoalId}")
    public ResponseEntity<?> updateSafetyGoal(
            @PathVariable(value="safetyGoalId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전목표 삭제", description = "안전목표 삭제 API")
    @DeleteMapping(value = "/admin/board/safety-goals/{safetyGoalId}")
    public ResponseEntity<?> deleteSafetyGoal(@PathVariable(value="safetyGoalId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 사진게시 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "사진게시 목록 조회", description = "사진게시 목록 조회 API")
    @GetMapping(value = "/admin/board/photos")
    public ResponseEntity<?> getPhotosList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "사진게시 상세정보 조회", description = "사진게시 상세정보 조회 API")
    @GetMapping(value = "/admin/board/photos/{photoId}")
    public ResponseEntity<?> getPhotosInfo(@PathVariable(value="photoId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 사진게시 등록", description = "신규 사진게시 등록 API")
    @PostMapping(value = "/admin/board/photos")
    public ResponseEntity<?> insertPhotos(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사진게시 정보 수정", description = "사진게시 정보 수정 API")
    @PutMapping(value = "/admin/board/photos/{photoId}")
    public ResponseEntity<?> updatePhotos(
            @PathVariable(value="photoId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사진게시 삭제", description = "사진게시 삭제 API")
    @DeleteMapping(value = "/admin/board/photos/{photoId}")
    public ResponseEntity<?> deletePhotos(@PathVariable(value="photoId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 공지사항 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "공지사항 목록 조회", description = "공지사항 목록 조회 API")
    @GetMapping(value = "/admin/board/notices")
    public ResponseEntity<?> getNoticeList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "공지사항 상세정보 조회", description = "공지사항 상세정보 조회 API")
    @GetMapping(value = "/admin/board/notices/{noticeId}")
    public ResponseEntity<?> getNoticeInfo(@PathVariable(value="noticeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 공지사항 등록", description = "신규 공지사항 등록 API")
    @PostMapping(value = "/admin/board/notices")
    public ResponseEntity<?> insertNotice(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "공지사항 정보 수정", description = "공지사항 정보 수정 API")
    @PutMapping(value = "/admin/board/notices/{noticeId}")
    public ResponseEntity<?> updateNotice(
            @PathVariable(value="noticeId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "공지사항 삭제", description = "공지사항 삭제 API")
    @DeleteMapping(value = "/admin/board/notices/{noticeId}")
    public ResponseEntity<?> deleteNotice(@PathVariable(value="noticeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 매뉴얼 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param jobType the job type
     * @param manualName the manual name
     * @param languageType the language type
     * @param useYn the use state
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "매뉴얼 목록 조회", description = "매뉴얼 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "jobType", description = "업무구분"),
            @Parameter(name = "manualName", description = "매뉴얼명"),
            @Parameter(name = "languageType", description = "언어구분"),
            @Parameter(name = "useYn", description = "사용여부")
    })
    @GetMapping(value = "/admin/board/manuals")
    public ResponseEntity<?> getManualList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="jobType", required=false) String jobType
            ,@RequestParam(value="manualName", required=false) String manualName
            ,@RequestParam(value="languageType", required=false) String languageType
            ,@RequestParam(value="useYn", required=false) String useYn) {

        //조회 조건 parameter
        TbAvnManualDto tbAvnManualDto = new TbAvnManualDto();
        tbAvnManualDto.setJobType(jobType);            //업무구분
        tbAvnManualDto.setManualName(manualName);      //매뉴얼명
        tbAvnManualDto.setLanguageType(languageType);  //언어구분
        tbAvnManualDto.setUseYn(useYn);                //사용여부

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnManualDto> pageList = service.selectManualList(tbAvnManualDto);

        // 전체 조회
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "매뉴얼 상세정보 조회", description = "매뉴얼 상세정보 조회 API")
    @GetMapping(value = "/admin/board/manuals/{manualId}")
    public ResponseEntity<?> getManualInfo(@PathVariable(value="manualId", required=true) int manualId) {

        TbAvnManualDto result = service.selectManualInfo(manualId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 매뉴얼 등록", description = "신규 매뉴얼 등록 API")
    @PostMapping(value = "/admin/board/manuals")
    public ResponseEntity<?> insertManual(@Valid @RequestBody(required=true) TbAvnManualDto tbAvnManualDto) {

        service.insertManual(tbAvnManualDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "매뉴얼 정보 수정", description = "매뉴얼 정보 수정 API")
    @PutMapping(value = "/admin/board/manuals/{manualId}")
    public ResponseEntity<?> updateManual(
            @PathVariable(value="manualId", required=true) int manualId,
            @Valid @RequestBody(required=true) TbAvnManualDto tbAvnManualDto) {

        tbAvnManualDto.setManualId(manualId);
        service.updateManual(tbAvnManualDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "매뉴얼 삭제", description = "매뉴얼 삭제 API")
    @DeleteMapping(value = "/admin/board/manuals/{manualId}")
    public ResponseEntity<?> deleteManual(@PathVariable(value="manualId", required=true) int manualId) {

        service.deleteManual(manualId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 자료실 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "자료실 목록 조회", description = "자료실 목록 조회 API")
    @GetMapping(value = "/admin/board/archives")
    public ResponseEntity<?> getArchivesList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "자료실 상세정보 조회", description = "자료실 상세정보 조회 API")
    @GetMapping(value = "/admin/board/archives/{archivesId}")
    public ResponseEntity<?> getArchivesInfo(@PathVariable(value="archivesId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 자료실 등록", description = "신규 자료실 등록 API")
    @PostMapping(value = "/admin/board/archives")
    public ResponseEntity<?> insertArchives(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "자료실 정보 수정", description = "자료실 정보 수정 API")
    @PutMapping(value = "/admin/board/archives/{archivesId}")
    public ResponseEntity<?> updateArchives(
            @PathVariable(value="archivesId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "자료실 삭제", description = "자료실 삭제 API")
    @DeleteMapping(value = "/admin/board/archives/{archivesId}")
    public ResponseEntity<?> deleteArchives(@PathVariable(value="archivesId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전정책 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param policyType the 정책구분
     * @param titleKo the 제목
     * @param useYn the 사용여부
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전정책 목록 조회", description = "안전정책 목록 조회 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이지 목록 개수"),
            @Parameter(name = "policyType", description = "정책구분"),
            @Parameter(name = "titleKo", description = "제목"),
            @Parameter(name = "useYn", description = "사용여부")
    })
    @GetMapping(value = "/admin/board/safety-policis")
    public ResponseEntity<?> getSafetyPolicyList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="policyType", required=false) String policyType
            ,@RequestParam(value="titleKo", required=false) String titleKo
            ,@RequestParam(value="useYn", required=false) String useYn) {

        //조회 조건 parameter
        TbAvnBoardDto tbAvnBoardDto = new TbAvnBoardDto();
        tbAvnBoardDto.setPolicyType(policyType); //정책구분
        tbAvnBoardDto.setTitleKo(titleKo);       //제목
        tbAvnBoardDto.setUseYn(useYn);           //사용여부

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnBoardDto> pageList = service.selectSafetyPolicisList(tbAvnBoardDto);

        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "안전정책 상세정보 조회", description = "안전정책 상세정보 조회 API")
    @Parameter(name = "boardId", description = "게시판 ID")
    @GetMapping(value = "/admin/board/safety-policis/{boardId}")
    public ResponseEntity<?> getSafetyPolicyInfo(@PathVariable(value="boardId", required=true) int boardId) {

        TbAvnBoardDto result = service.selectSafetyPolicy(boardId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 안전정책 등록", description = "신규 안전정책 등록 API")
    @PostMapping(value = "/admin/board/safety-policis")
    public ResponseEntity<?> insertSafetyPolicy(@Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        service.insertSafetyPolicy(tbAvnBoardDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전정책 정보 수정", description = "안전정책 정보 수정 API")
    @Parameter(name = "boardId", description = "게시판 ID")
    @PutMapping(value = "/admin/board/safety-policis/{boardId}")
    public ResponseEntity<?> updateSafetyPolicy(
            @PathVariable(value="boardId", required=true) int boardId,
            @Valid @RequestBody(required=true) TbAvnBoardDto tbAvnBoardDto) {

        tbAvnBoardDto.setBoardId(boardId);
        service.updateSafetyPolicy(tbAvnBoardDto);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전정책 삭제", description = "안전정책 삭제 API")
    @Parameter(name = "boardId", description = "게시판 ID")
    @DeleteMapping(value = "/admin/board/safety-policis/{boardId}")
    public ResponseEntity<?> deleteSafetyPolicy(@PathVariable(value="boardId", required=true) int boardId) {

        service.deleteSafetyPolicy(boardId);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 안전회의체 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전회의체 목록 조회", description = "안전회의체 목록 조회 API")
    @GetMapping(value = "/admin/board/safety-committee")
    public ResponseEntity<?> getSafetyCommitteeList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전회의체 상세정보 조회", description = "안전회의체 상세정보 조회 API")
    @GetMapping(value = "/admin/board/safety-committee/{committeeId}")
    public ResponseEntity<?> getSafetyCommitteeInfo(@PathVariable(value="committeeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전회의체 등록", description = "신규 안전회의체 등록 API")
    @PostMapping(value = "/admin/board/safety-committee")
    public ResponseEntity<?> saveSafetyCommittee(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전회의체 정보 수정", description = "안전회의체 정보 수정 API")
    @PutMapping(value = "/admin/board/safety-committee/{committeeId}")
    public ResponseEntity<?> updateSafetyCommittee(
            @PathVariable(value="committeeId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전회의체 삭제", description = "안전회의체 삭제 API")
    @DeleteMapping(value = "/admin/board/safety-committee/{committeeId}")
    public ResponseEntity<?> deleteSafetyCommittee(@PathVariable(value="messageId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
