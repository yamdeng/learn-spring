package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuPartnerService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전관리 - 협력업체
 */
@Tag(name = "OcuPartner", description = "안전관리 - 협력업체 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuPartnerController {

    @Autowired
    OcuPartnerService service;

    /**
     * 협력업체 정보 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "협력업체 정보 목록 조회", description = "협력업체 정보 목록 조회 API")
    @GetMapping(value = "/management/partner")
    public ResponseEntity<?> getPartnerList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "협력업체 정보 상세정보 조회", description = "협력업체 정보 상세정보 조회 API")
    @GetMapping(value = "/management/partner/{partnerId}")
    public ResponseEntity<?> getPartnerInfo(@PathVariable(value="partnerId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 협력업체 정보 등록", description = "신규 협력업체 정보 등록 API")
    @PostMapping(value = "/management/partner")
    public ResponseEntity<?> insertPartner(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 정보 정보 수정", description = "협력업체 정보 정보 수정 API")
    @PutMapping(value = "/management/partner/{partnerId}")
    public ResponseEntity<?> updatePartner(
            @PathVariable(value="partnerId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 정보 삭제", description = "협력업체 정보 삭제 API")
    @DeleteMapping(value = "/management/partner/{partnerId}")
    public ResponseEntity<?> deletePartner(@PathVariable(value="partnerId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 협력업체 리스트 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "협력업체 리스트 조회", description = "협력업체 리스트 조회")
    @GetMapping(value = "/management/partner/contracts")
    public ResponseEntity<?> getContractList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
