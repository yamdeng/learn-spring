package com.koreanair.ksms.ocu.gen.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OcuRegulationServiceImpl extends AbstractBaseService implements OcuRegulationService {

	/**
	 * 규정/지침/매뉴얼/양식 목록 조회
	 */
	@Override
	public PageInfo<OcuRegulationDto> selectRegulationsList(OcuRegulationDto dto) {
		
		List<OcuRegulationDto> resultList = commonSql.selectList("OcuRegulation.selectRegulationsList", dto);
		
	    return PageInfo.of(resultList);
	}

	/**
	 * 규정/지침/매뉴얼/양식 상세 정보 조회
	 */
	@Override
	public OcuRegulationDto getRegulationInfo(int rulesFormId) {
		return commonSql.selectOne("OcuRegulation.getRegulationInfo", rulesFormId);
	}
	
	/**
	 * 규정/지침/매뉴얼/양식 등록
	 */
	@Override
	public void insertRegulation(@Valid OcuRegulationDto dto) {
		commonSql.insert("OcuRegulation.insertRegulation", dto);
	}
	
	/**
	 * 규정/지침/매뉴얼/양식 수정
	 */
	@Override
	public void updateRegulation(@Valid OcuRegulationDto dto) {
		commonSql.update("OcuRegulation.updateRegulation", dto);
	}

	/**
	 * 규정/지침/매뉴얼/양식 삭제
	 */
	@Override
	public void deleteRegulation(int rulesFormId) {
		commonSql.delete("OcuRegulation.deleteRegulation", rulesFormId);
		
	}

	/**
	 * 규정/지침/매뉴얼/양식 개정번호 조회
	 */
	@Override
	public OcuRegulationDto selectRevisionNo(String sectCd, String formCls) {
			
		OcuRegulationDto or = new OcuRegulationDto();		
		or.setSectCd(sectCd);
		or.setFormCls(formCls);
		
		return commonSql.selectOne("OcuRegulation.selectRevisionNo", or);
	}

	/**
	 * 규정/지침/매뉴얼/양식 개정번호 리스트 조회
	 */
	@Override
	public List<OcuRegulationDto> selectRevisionNoList(String sectCd, String formCls) {
		OcuRegulationDto or = new OcuRegulationDto();		
		or.setSectCd(sectCd);
		or.setFormCls(formCls);
		
		List<OcuRegulationDto> resultList = commonSql.selectList("OcuRegulation.selectRevisionNoList", or);
		
		return resultList;
	}
}
