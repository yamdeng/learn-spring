package com.koreanair.ksms.ocu.gen.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuCommitteeDto;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;

import jakarta.validation.Valid;

public interface OcuCommitteeService {

	/**
	 * 산업안전보건위원회 목록 조회
	 * @param dto
	 * @return
	 */
	public PageInfo<OcuCommitteeDto> selectCommitteeList(OcuCommitteeDto dto);

	/**
	 * 산업안전보건위원회 상세 조회
	 * @param ocuComitteeId
	 * @return
	 */
	public OcuCommitteeDto getCommitteeInfo(int ocuComitteeId);

	/**
	 * 산업안전보건위원회 입력
	 * @param dto
	 */
	public void insertCommittee(@Valid OcuCommitteeDto dto);

	/**
	 * 산업안전보건위원회 수정
	 * @param dto
	 */
	public void updateCommittee(@Valid OcuCommitteeDto dto);

	/**
	 * 산업안전보건위원회 삭제
	 * @param ocuComitteeId
	 */
	public void deleteCommittee(int ocuComitteeId);
}
