package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS 성숙도 점검")
public class TbAvnSmsInspectDto extends CommonDto {
    
    @Schema(description = "연도")
    @NotBlank
    private String year;
    
    @Schema(description = "final score")
    private double finalScore;
    
    @Schema(description = "안전정책과 목표")
    private double totalScoreOne;
    
    @Schema(description = "항공안전 위험도의 관리")
    private double totalScoreTwo;
    
    @Schema(description = "항공안전보증")
    private double totalScoreThree;
    
    @Schema(description = "항공안전증진")
    private double totalScoreFor;
    
    @Schema(description = "운항점수")
    private double flyScore;
    
    @Schema(description = "정비점수")
    private double maintenanceScore;
    
    @Schema(description = "종합통제점수")
    private double operationsScore;
    
    @Schema(description = "객실점수")
    private double cabinScore;
    
    @Schema(description = "여객점수")
    private double passengerScore;
    
    @Schema(description = "화물점수")
    private double cargoScore;
    
    @Schema(description = "OY점수")
    private double oyScore;
}
