package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnManualDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnBulletinManageServiceImpl extends AbstractBaseService implements AvnBulletinManageService {

    @Override
    public List<GenericDto> selectList() {
        return List.of();
    }

    //관리자 > 게시판 관리 > 안전정책 목록 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectSafetyPolicisList(TbAvnBoardDto tbAvnBoardDto){
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectSafetyPolicisList", tbAvnBoardDto);
        return PageInfo.of(resultList);
    }

    //관리자 > 게시판 관리 > 안전정책 신규 등록
    @Override
    public void insertSafetyPolicy(TbAvnBoardDto tbAvnBoardDto){
        commonSql.insert("AvnBulletinManage.insertSafetyPolicy", tbAvnBoardDto);
    }

    //관리자 > 게시판 관리 > 안전정책 상세
    @Override
    public TbAvnBoardDto selectSafetyPolicy(int boardId){
        return commonSql.selectOne("AvnBulletinManage.selectSafetyPolicy", boardId);
    }

    //관리자 > 게시판 관리 > 안전정책 수정
    @Override
    public void updateSafetyPolicy(TbAvnBoardDto tbAvnBoardDto){
        commonSql.update("AvnBulletinManage.updateSafetyPolicy", tbAvnBoardDto);
    }

    //관리자 > 게시판 관리 > 안전정책 삭제
    @Override
    public void deleteSafetyPolicy(int boardId){
        commonSql.delete("AvnBulletinManage.deleteSafetyPolicy", boardId);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 목록 조회
    @Override
    public PageInfo<TbAvnManualDto> selectManualList(TbAvnManualDto tbAvnManualDto){
        List<TbAvnManualDto> resultList = commonSql.selectList("AvnBulletinManage.selectManualList", tbAvnManualDto);
        return PageInfo.of(resultList);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 신규 등록
    @Override
    public void insertManual(TbAvnManualDto tbAvnManualDto){
        
        //날짜 포맷 변경
        String DateFormatChange = tbAvnManualDto.getRevisionDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(2,8);
        tbAvnManualDto.setRevisionDt(DateFormatChange);

        commonSql.insert("AvnBulletinManage.insertManual", tbAvnManualDto);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 상세
    @Override
    public TbAvnManualDto selectManualInfo(int manualId){
        return commonSql.selectOne("AvnBulletinManage.selectManualInfo", manualId);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 수정
    @Override
    public void updateManual(TbAvnManualDto tbAvnManualDto){

        //날짜 포맷 변경
        String DateFormatChange = tbAvnManualDto.getRevisionDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(2,8);
        tbAvnManualDto.setRevisionDt(DateFormatChange);

        commonSql.update("AvnBulletinManage.updateManual", tbAvnManualDto);
    }

    //관리자 > 게시판 관리 > 안전매뉴얼 삭제
    @Override
    public void deleteManual(int manualId){
        commonSql.delete("AvnBulletinManage.deleteManual", manualId);
    }
}
