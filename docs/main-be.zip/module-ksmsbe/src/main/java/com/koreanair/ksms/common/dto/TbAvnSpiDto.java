package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SPI 지표 정보")
public class TbAvnSpiDto extends CommonDto {
    
    @Schema(description = "Row Index")
    private int num;

    @Schema(description = "연도")
    @NotBlank
    private String year;
    
    @Schema(description = "지표코드")
    @NotBlank
    private String spiCode;
    
    @Schema(description = "지표명")
    @NotBlank
    private String spiName;
    
    @Schema(description = "지표구분")
    private String spiType;
    private String spiTypeKor;
    private String spiTypeEng;
    
    @Schema(description = "지표분류")
    private String spiTaxonomy;
    private String spiTaxonomyKor;
    private String spiTaxonomyEng;
    
    @Schema(description = "산출기준")
    private String outputStnd;
    private String outputStndKor;
    private String outputStndEng;
    
    @Schema(description = "지표정의")
    private String spiDescr;
    
    @Schema(description = "소스")
    private String dataSource;
    
    @Schema(description = "주의 점수")
    private double cautionPoint;
    
    @Schema(description = "경계 점수")
    private double warnPoint;
    
    @Schema(description = "심각 점수")
    private double criticalPoint;
    
    @Schema(description = "목표치")
    private double sptPoint;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    @NotBlank
    private int viewOrder;
}
