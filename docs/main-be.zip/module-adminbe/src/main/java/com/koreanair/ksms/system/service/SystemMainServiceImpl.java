package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.*;
import io.vertx.core.json.JsonObject;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemMainServiceImpl extends AbstractBaseService implements SystemMainService {

    @Override
    public List<Map<String, Object>> selectLeftMenu(String workScope) {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("workScope", workScope);
        param.put("userId", userId);

        return commonSql.selectList("SystemMain.selectLeftMenu", param);
    }

    @Override
    public List<TbSysCodeGroupDto> selectCodeGroupList() {

        return commonSql.selectList("SystemMain.selectCodeGroupList");
    }

    @Override
    public List<TbSysCodeDto> selectCodeList(String codeGrpId) {

        return commonSql.selectList("SystemMain.selectCodeList", codeGrpId);
    }

    @Override
    public List<TbSysCodeDto> selectCodeListAll() {

        return commonSql.selectList("SystemMain.selectCodeListAll");
    }

    @Override
    public List<TbSysDeptDto> selectDeptList() {

        return commonSql.selectList("SystemMain.selectDeptList");
    }

    @Override
    public List<TbSysUserDto> selectUserList(String searchWord, String deptCd) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("searchWord", searchWord);
        param.put("deptCd", deptCd);

        return commonSql.selectList("SystemMain.selectUserList", param);
    }

    @Override
    public JsonObject selectMessagesAll() {

        JsonObject korMessages = new JsonObject();
        JsonObject engMessages = new JsonObject();
        String msgKey = "";

        List<TbSysMessageDto> listKor = commonSql.selectList("SystemMain.selectMessagesKor");
        List<TbSysMessageDto> listEng = commonSql.selectList("SystemMain.selectMessagesEng");

        for(TbSysMessageDto dto: listKor) {
            msgKey = dto.getMsgKey();
            korMessages.put(msgKey, dto.getMsgKor());
        }

        for(TbSysMessageDto dto: listEng) {
            msgKey = dto.getMsgKey();
            engMessages.put(msgKey, dto.getMsgEng());
        }

        JsonObject messages = new JsonObject();
        messages.put("ko", korMessages);
        messages.put("en", engMessages);

        return messages;
    }

    @Override
    public TbSysUserDto selectUserProfile(String userId) {

        return commonSql.selectOne("SystemMain.selectUserProfile", userId);
    }

    @Override
    public List<TbSysVirtualGroupDto> selectUserGroups(String userId) {

        return commonSql.selectList("SystemMain.selectUserGroups", userId);
    }
}
