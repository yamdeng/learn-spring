package com.koreanair.ksms.constants;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum ResponseHeaderCode {

    SUCCESS("0", "정상 처리 되었습니다."),
    NOT_PROCESSED("0", "처리되지 않았습니다."),
    EMPTY_RESULT("0", "데이터가 존재하지 않습니다."),
    NOT_SEARCHED("0", "조회 실패하였습니다."),
    INVALID_PARAMETER("1", "파라미터 설정을 확인하십시오"),
    UNAVAILABLE_SERVICE("2", "서비스가 원활하지 않습니다."),
    UNAUTHORIZED_KEY("7", "Key 인증실패: SERVICE KEY IS NOT REGISTERED ERROR.");

    private final String headerCode;
    private final String headerMessage;
}
