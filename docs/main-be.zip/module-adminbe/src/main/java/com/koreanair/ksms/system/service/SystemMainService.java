package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.*;
import io.vertx.core.json.JsonObject;

import java.util.List;
import java.util.Map;

public interface SystemMainService {
    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    List<TbSysUserDto> selectUserList(String searchWord, String deptCd);

    JsonObject selectMessagesAll();

    TbSysUserDto selectUserProfile(String userId);

    List<TbSysVirtualGroupDto> selectUserGroups(String userId);
}
