package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.LoginRequestDto;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Map;

public interface SystemLoginService {

    public Map<String, Object> login(LoginRequestDto dto);

    UserDetails loadUserByUserId(String string);
}
