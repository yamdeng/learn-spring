package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysMenuDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.dto.TbSysVirtualGroupDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemGroupServiceImpl extends AbstractBaseService implements SystemGroupService {
    
    @Override
    public List<TbSysVirtualGroupDto> selectVirtualGroupList(String workScope, String groupUsage, String searchWord) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("workScope", workScope);
        param.put("groupUsage", groupUsage);
        param.put("searchWord", searchWord);

        return commonSql.selectList("SystemGroup.selectVirtualGroupList", param);
    }

    @Override
    public TbSysVirtualGroupDto selectVirtualGroup(String groupCd) {

        return commonSql.selectOne("SystemGroup.selectVirtualGroup", groupCd);
    }

    @Override
    public void insertVirtualGroup(TbSysVirtualGroupDto dto) {

        commonSql.insert("SystemGroup.insertVirtualGroup", dto);
    }

    @Override
    public void updateVirtualGroup(TbSysVirtualGroupDto dto) {

        commonSql.update("SystemGroup.updateVirtualGroup", dto);
    }

    @Override
    @Transactional
    public void deleteVirtualGroup(String groupCd) {

        commonSql.delete("SystemGroup.deleteVirtualGroup", groupCd);
    }

    /*****************************************************************************************************************/

    @Override
    public List<Map<String, Object>> selectVirtualGroupMenuList(String groupCd) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);

        return commonSql.selectList("SystemGroup.selectVirtualGroupMenuList", param);
    }

    @Override
    @Transactional
    public void addVirtualGroupMenuList(String groupCd, List<TbSysMenuDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupMenuList", groupCd);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupMenuList", param);
        }
    }

    @Override
    public void delVirtualGroupMenu(String groupCd, String menuId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("menuId", menuId);

        commonSql.delete("SystemGroup.delVirtualGroupMenu", param);
    }

    /*****************************************************************************************************************/

    @Override
    public List<TbSysUserDto> selectVirtualGroupUserList(String groupCd) {

        return commonSql.selectList("SystemGroup.selectVirtualGroupUserList", groupCd);
    }

    @Override
    @Transactional
    public void addVirtualGroupUserList(String groupCd, List<TbSysUserDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupUserList", groupCd);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupUserList", param);
        }
    }

    @Override
    public void delVirtualGroupUser(String groupCd, String userId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("userId", userId);

        commonSql.delete("SystemGroup.delVirtualGroupUser", param);
    }

    /*****************************************************************************************************************/

    @Override
    public List<TbSysDeptDto> selectVirtualGroupDeptList(String groupCd) {

        return commonSql.selectList("SystemGroup.selectVirtualGroupDeptList", groupCd);
    }

    @Override
    @Transactional
    public void addVirtualGroupDeptList(String groupCd, List<TbSysDeptDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupDeptList", groupCd);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupDeptList", param);
        }
    }

    @Override
    public void delVirtualGroupDept(String groupCd, String deptCd) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupCd", groupCd);
        param.put("deptCd", deptCd);

        commonSql.delete("SystemGroup.delVirtualGroupDept", param);
    }
}
