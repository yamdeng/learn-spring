package com.ke;

public class KsmsBatchApplication {
    public static void main(String[] args) {
        System.out.println("Hello BATCH!");
    }
}