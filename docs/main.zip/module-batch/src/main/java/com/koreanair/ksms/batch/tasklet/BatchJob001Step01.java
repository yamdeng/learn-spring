package com.koreanair.ksms.batch.tasklet;

import com.koreanair.ksms.batch.base.tasklet.BaseTasklet;
import com.koreanair.ksms.batch.dto.SampleDTO;
import com.koreanair.ksms.batch.service.KsmsBatchJob001Service;
import com.koreanair.ksms.batch.service.SampleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@StepScope
public class BatchJob001Step01 extends BaseTasklet {

    @Autowired
    KsmsBatchJob001Service service;

    @Value("${filepath.csv}")
    private String csvFileName;

    /**
     * sftp접속하여 csv파일 다운로드 및 임시테이블 데이터 삭제
     *
     * @param stepContribution
     * @param chunkContext
     * @return
     */
    @Override
    public RepeatStatus run(StepContribution stepContribution, ChunkContext chunkContext) {

        log.info("KsmsBatchJob001 - STEP 1 실행 ==================================");
        log.info("CSV파일 저장: " + csvFileName);

        service.deleteTempTable();
        log.info("임시 테이블 데이터 삭제: done");

        return RepeatStatus.FINISHED;
    }

}
