package com.koreanair.ksms.batch.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SampleDTO {
    private String employeeNumber;
    private String employeeName;
    private String employeeEmail;
    private String employeePhone;
    private String employeeDepartment;
}
