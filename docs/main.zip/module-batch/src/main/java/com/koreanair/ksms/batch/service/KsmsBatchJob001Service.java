package com.koreanair.ksms.batch.service;

public interface KsmsBatchJob001Service {

    void deleteTempTable();
}
