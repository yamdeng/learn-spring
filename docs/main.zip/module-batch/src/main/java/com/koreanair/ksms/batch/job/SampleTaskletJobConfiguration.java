package com.koreanair.ksms.batch.job;

import com.koreanair.ksms.batch.base.listener.BaseJobLogger;
import com.koreanair.ksms.batch.base.listener.BaseStepLogger;
import com.koreanair.ksms.batch.tasklet.SampleTasklet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Slf4j
@Configuration
public class SampleTaskletJobConfiguration {
    public static final String JOB_NAME = "sampleTaskletJob";
    public static final String STEP_NAME = "sampleTaskletStep";

    private final SampleTasklet sampleTasklet;

    public SampleTaskletJobConfiguration(SampleTasklet sampleTasklet) {
        this.sampleTasklet = sampleTasklet;
    }

    @Bean(JOB_NAME)
    public Job sampleTaskletJob(JobRepository jobRepository, Step sampleTaskletStep ) {
        log.info(" >>> sample TaskletJob() ");
        return new JobBuilder(JOB_NAME, jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(sampleTaskletStep)
                .listener(new BaseJobLogger())
                .build();
    }

    @Bean(STEP_NAME)
    public Step sampleTaskletStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        log.info(" >>> sample TaskletStep() ");
        return new StepBuilder("sampleReaderStep", jobRepository)
                .tasklet((Tasklet) sampleTasklet, transactionManager)
                .listener(new BaseStepLogger())
                .build();
    }
}
