package com.koreanair.ksms.batch.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SampleEntity {
    private String employeeNumber;
    private String employeeName;
    private String employeeEmail;
    private String employeePhone;
    private String employeeDepartment;
}
