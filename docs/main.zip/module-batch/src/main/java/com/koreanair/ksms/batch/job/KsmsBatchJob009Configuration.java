package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * ERP예산정보 I/F Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob009Configuration {

    public static final String JOB_NAME = "ksmsBatchJob009";
    public static final String STEP_NAME = "ksmsBatchStep009";
}
