package com.koreanair.ksms.batch.service;

import com.koreanair.ksms.batch.dto.SampleDTO;
import com.koreanair.ksms.batch.entity.SampleEntity;
import com.koreanair.ksms.batch.mapper.SampleMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service("sampleService")
public class SampleServiceImpl implements SampleService {

    private final SampleMapper sampleMapper;

    public SampleServiceImpl(SampleMapper sampleMapper) {
        this.sampleMapper = sampleMapper;
    }

    @Override
    public List<SampleDTO> retrieveSample() {
        List<SampleEntity> sampleEntityList = sampleMapper.selectEmployeeTable();
        return convertEntityListToDTOList(sampleEntityList);

    }

    @Override
    public int insertSample(List<SampleDTO> sampleDTO) {
        List<SampleEntity> sampleEntityList = convertDTOListToEntityList(sampleDTO);
        log.debug(" @@@@@@@@@@@@@@@@@@@@@");
        log.debug(" \n ***** 삽입 결과 : {} ****** ", sampleEntityList);
        return sampleMapper.insertEmployeeTableTasklet(sampleEntityList);
    }

    @Override
    public void deleteSample() {
        sampleMapper.deleteSample();
    }


    private List<SampleDTO> convertEntityListToDTOList(List<SampleEntity> sampleEntityList) {
        return sampleEntityList.stream()
                .map(this::convertEntityToDTO)
                .collect(Collectors.toList());
    }

    private SampleDTO convertEntityToDTO(SampleEntity sampleEntity) {
        SampleDTO sampleDTO = new SampleDTO();

        sampleDTO.setEmployeeNumber(sampleEntity.getEmployeeNumber());
        sampleDTO.setEmployeeName(sampleEntity.getEmployeeName());
        sampleDTO.setEmployeeEmail(sampleEntity.getEmployeeEmail());
        sampleDTO.setEmployeePhone(sampleEntity.getEmployeePhone());
        sampleDTO.setEmployeeDepartment(sampleEntity.getEmployeeDepartment());

        return sampleDTO;
    }
    private List<SampleEntity> convertDTOListToEntityList(List<SampleDTO> sampleDTO) {
        return sampleDTO.stream()
                .map(this::convertDTOToEntity)
                .collect(Collectors.toList());
    }

    private SampleEntity convertDTOToEntity(SampleDTO sampleDTO) {
        SampleEntity sampleEntity = new SampleEntity();

        sampleEntity.setEmployeeNumber(sampleDTO.getEmployeeNumber());
        sampleEntity.setEmployeeName(sampleDTO.getEmployeeName());
        sampleEntity.setEmployeeEmail(sampleDTO.getEmployeeEmail());
        sampleEntity.setEmployeePhone(sampleDTO.getEmployeePhone());
        sampleEntity.setEmployeeDepartment(sampleDTO.getEmployeeDepartment());

        return sampleEntity;
    }
}
