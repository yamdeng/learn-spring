package com.koreanair.ksms.batch.service;

import com.koreanair.ksms.batch.mapper.KsmsBatchJob001Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class KsmsBatchJob001ServiceImpl implements KsmsBatchJob001Service {

    @Autowired
    KsmsBatchJob001Mapper mapper;

    @Override
    public void deleteTempTable() {

        mapper.deleteTempTable();
    }
}
