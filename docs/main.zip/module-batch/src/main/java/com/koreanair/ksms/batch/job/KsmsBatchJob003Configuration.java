package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * 경감조치 기한 안내 메일 발송 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob003Configuration {

    public static final String JOB_NAME = "ksmsBatchJob003";
    public static final String STEP_NAME = "ksmsBatchStep003";
}
