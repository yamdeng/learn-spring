package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * Audit 조치사항 기한 안내 메일 발송 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob005Configuration {

    public static final String JOB_NAME = "ksmsBatchJob005";
    public static final String STEP_NAME = "ksmsBatchStep005";
}
