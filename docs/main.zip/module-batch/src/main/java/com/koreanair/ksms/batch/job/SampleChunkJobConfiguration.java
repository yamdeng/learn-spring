package com.koreanair.ksms.batch.job;

import com.koreanair.ksms.batch.base.listener.BaseChunkLogger;
import com.koreanair.ksms.batch.base.listener.BaseJobLogger;
import com.koreanair.ksms.batch.base.listener.BaseStepLogger;
import com.koreanair.ksms.batch.dto.SampleDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.batch.MyBatisBatchItemWriter;
import org.mybatis.spring.batch.MyBatisPagingItemReader;
import org.mybatis.spring.batch.builder.MyBatisBatchItemWriterBuilder;
import org.mybatis.spring.batch.builder.MyBatisPagingItemReaderBuilder;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import java.util.List;

@Slf4j
@Configuration
public class SampleChunkJobConfiguration {
    public static final String JOB_NAME = "sampleChunkJob";
    public static final String STEP_NAME = "sampleChunkStep";
    private final SqlSessionFactory sqlSessionFactory;

    private final int chunkSize = 1000;

    public SampleChunkJobConfiguration(SqlSessionFactory sqlSessionFactory) {
        this.sqlSessionFactory = sqlSessionFactory;
    }

    @Bean(JOB_NAME)
    public Job sampleChunkJob(JobRepository jobRepository, Step sampleChunkStep ) {
        log.info(" >>> sample ChunkJob() ");
        return new JobBuilder(JOB_NAME, jobRepository)
                .incrementer(new RunIdIncrementer())
                .start(sampleChunkStep)
                .listener(new BaseJobLogger())
                .build();
    }

    @Bean(STEP_NAME)
    public Step sampleReaderStep(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
        log.info(" >>> sample ChunkReaderStep() ");
        return new StepBuilder("sampleReaderStep", jobRepository)
                .<List<SampleDTO>, List<SampleDTO>>chunk(chunkSize, transactionManager)
                .reader(postgresSampleChunkReader())
                .writer(postgresSampleChunkWriter())
                .listener(new BaseStepLogger())
                .listener(new BaseChunkLogger())
                .build();
    }

    @Bean
    public MyBatisPagingItemReader<List<SampleDTO>> postgresSampleChunkReader() {
        log.info(" >>> postgres SampleChunkReader() ");
        return new MyBatisPagingItemReaderBuilder<List<SampleDTO>>()
                .sqlSessionFactory(sqlSessionFactory)
                .queryId("com.koreanair.ksms.batch.mapper.SampleMapper.selectEmployeeTable")
                .pageSize(chunkSize)
                .build();
    }

    @Bean
    public MyBatisBatchItemWriter<List<SampleDTO>> postgresSampleChunkWriter() {
        log.info(" >>> postgres SampleChunkWriter() ");
        return new MyBatisBatchItemWriterBuilder<List<SampleDTO>>()
                .sqlSessionFactory(sqlSessionFactory)
                .statementId("com.koreanair.ksms.batch.mapper.SampleMapper.insertEmployeeTable")
                .build();
    }

}
