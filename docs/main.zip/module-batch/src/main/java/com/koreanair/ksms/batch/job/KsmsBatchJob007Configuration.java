package com.koreanair.ksms.batch.job;

import lombok.extern.slf4j.Slf4j;

/**
 * 보고서 제출 기한 메일 발송 Batch Job
 */
@Slf4j
//@Configuration
public class KsmsBatchJob007Configuration {

    public static final String JOB_NAME = "ksmsBatchJob007";
    public static final String STEP_NAME = "ksmsBatchStep007";
}
