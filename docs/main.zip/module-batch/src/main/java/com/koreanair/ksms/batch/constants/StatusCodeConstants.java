package com.koreanair.ksms.batch.constants;

public class StatusCodeConstants {

    public static final String OK = "OK";

    public static final String MANDATORY_PARAM_ERR = "MANDATORY_PARAM_ERR";
    public static final String PARAM_LENGTH_ERR = "PARAM_LENGTH_ERR";
    public static final String PARAM_PATTERN_ERR = "PARAM_PATTERN_ERR";
    public static final String END_STATUS_ERR = "END_STATUS_ERR";

    public static final String CONFLICT = "CONFLICT";
    public static final String EXPECTATION_FAILED = "EXPECTATION_FAILED";
    public static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";
    public static final String BAD_REQUEST = "BAD_REQUEST";

    public static final String SESSION_EXPIRE = "SESSION_EXPIRE";
    public static final String HALT = "HALT";
    public static final String LOCK = "LOCK";

    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";
    public static final String FILE_NAME_ERROR = "FILE_NAME_ERROR";
    public static final String FILE_FORMAT_ERROR = "FILE_FORMAT_ERROR";
    public static final String UPLOAD_FILE_SIZE_ERROR = "UPLOAD_FILE_SIZE_ERROR";

    public static final String INVALID_FORMAT = "INVALID_FORMAT";
    public static final String INVALID_DATE_FROM_TO = "INVALID_DATE_FROM_TO";
    public static final String INVALID_FUTURE_DATE = "INVALID_FUTURE_DATE";

    public static final String VERIFY_IDENTITY_TOKEN_FAIL = "VERIFY_IDENTITY_TOKEN_FAIL";
    public static final String INVALID_PARAMETER = "INVALID_PARAMETER";
    public static final String EXIST_DUPLICATION_DATA = "EXIST_DUPLICATION_DATA";

}
