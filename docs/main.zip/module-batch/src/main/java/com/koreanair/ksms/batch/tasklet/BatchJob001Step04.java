package com.koreanair.ksms.batch.tasklet;

import com.koreanair.ksms.batch.base.tasklet.BaseTasklet;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.scope.context.StepContext;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@StepScope
public class BatchJob001Step04 extends BaseTasklet {

    @Value("${filepath.csv}")
    private String csvFileName;

    /**
     * 다운로드 받은 csv파일 삭제
     *
     * @param stepContribution
     * @param chunkContext
     * @return
     */
    @Override
    public RepeatStatus run(StepContribution stepContribution, ChunkContext chunkContext) {

        log.info("KsmsBatchJob001 - STEP 4 실행 ==================================");
        log.info("CSV파일 삭제: " + csvFileName);

        return RepeatStatus.FINISHED;
    }

}
