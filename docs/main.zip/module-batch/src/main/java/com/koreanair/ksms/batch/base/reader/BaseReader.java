package com.koreanair.ksms.batch.base.reader;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

@Setter
public abstract class BaseReader<T> implements ItemReader<T>, StepExecutionListener {
    private static final Logger log = LoggerFactory.getLogger(BaseReader.class);
    private JobParameters jobParameters;
    @Getter
    private ExecutionContext jobContext;
    @Getter
    private StepExecution stepExecution;

    public JobParameters getJobParameters() {
        return this.getStepExecution().getJobParameters();
    }

    public void setJobContextData(String key, Object value) {
        this.jobContext.put(key, value);
    }

    public Object getJobContextData(String key) {
        return this.jobContext.get(key);
    }

    public void beforeStep(StepExecution stepExecution) {
        this.jobParameters = stepExecution.getJobParameters();
        this.setJobContext(stepExecution.getJobExecution().getExecutionContext());
        this.setStepExecution(stepExecution);
    }

    public ExitStatus afterStep(StepExecution paramStepExecution) {
        return paramStepExecution.getExitStatus();
    }

    public T read()
            throws Exception, UnexpectedInputException, ParseException,
            NonTransientResourceException {
        return this.run();
    }

    public abstract T run()
            throws Exception, UnexpectedInputException, ParseException,
            NonTransientResourceException;
}
