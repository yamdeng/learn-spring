package com.koreanair.ksms.ocu.gen.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegInfoDto;
import com.koreanair.ksms.ocu.gen.service.OcuLawRegInfoService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;


/**
 *  법규등록대장정보 Controller
 */
@Tag(name = "법규등록대장정보", description = "법규등록대장정보 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuLawRegInfoController {

    @Autowired
    private OcuLawRegInfoService service;
    
    /**
     * 법규등록대장 정보 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "법규등록대장 정보 목록 조회", description = "법규등록대장 정보 목록 조회 API")
    @GetMapping(value = "/general/lawRegInfo")
    public ResponseEntity<?> getPageList(		
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageneralum
           ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           ,@RequestParam(value="lawNm", required=false) String lawNm 
           ,@RequestParam(value="type", required=false) String type 
           ,@RequestParam(value="fromDt", required=false) String fromDt 
           ,@RequestParam(value="toDt", required=false) String toDt 
           ,@RequestParam(value="lgsltKind", required=false) String lgsltKind 
           ,@RequestParam(value="respMinistryNm", required=false) String respMinistryNm 
           ,@RequestParam(value="subjectDeptCd", required=false) String subjectDeptCd 
           ,@RequestParam(value="rlvtDeptCd", required=false) String rlvtDeptCd 
           ,@RequestParam(value="approvalStatus", required=false) String approvalStatus 
           ,@RequestParam(value="keyWordContent", required=false) String keyWordContent) {

	  PageHelper.startPage(pageneralum, pageSize);
	  
	  OcuLawRegInfoDto dto = new OcuLawRegInfoDto();
	  
	  log.debug("와야함@@@@@@@@@@@@@@@@@@@@@@@@@@@");
	  
	  dto.setLawNm(lawNm);
	  dto.setType(type);
	  dto.setFromDt(fromDt);
	  dto.setToDt(toDt);
	  dto.setLgsltKind(lgsltKind);
	  dto.setRespMinistryNm(respMinistryNm);
	  dto.setSubjectDeptCd(subjectDeptCd);
	  dto.setRlvtDeptCd(rlvtDeptCd);
	  dto.setApprovalStatus(approvalStatus);
	  dto.setKeyWordContent(keyWordContent);

	  PageInfo<OcuLawRegInfoDto> pageList = service.selectOcuLawRegInfoList(dto);
      return ResponseUtil.createSuccessResponse(pageList);
    }
    
    /**
     * 법규등록대장 정보 상세 조회
     * @param lawSeq
     * @return
     */
    @Operation(summary = "법규등록대장 정보 상세 조회", description = "법규등록대장 정보 상세 조회 API")
    @GetMapping(value ="/general/lawRegInfo/{lawSeq}")
    public ResponseEntity<?> selectOcuLawRegInfo(@PathVariable(value="lawSeq") String lawSeq) {
    	
    	OcuLawRegInfoDto result = service.selectOcuLawRegInfo(lawSeq);
    	return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * 법규등록대장 정보 등록
     * @param dto
     * @return
     */
    @Operation(summary = "법규등록대장 정보 등록", description = "법규등록대장 정보 등록 API")
    @PostMapping(value = "/general/lawRegInfo")
    public ResponseEntity<?> insertOcuLawRegInfo(@Valid @RequestBody() OcuLawRegInfoDto dto) {

        service.insertOcuLawRegInfo(dto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 법규등록대장 정보 수정
     * @param lawSeq
     * @param dto
     * @return
     */
    @Operation(summary = "법규등록대장 정보 수정", description = "법규등록대장 정보 수정 API")
    @PutMapping(value = "/general/lawRegInfo/{lawSeq}")
    public ResponseEntity<?> updateOcuLawRegInfo( @PathVariable(value="lawSeq") String lawSeq,
            @Valid @RequestBody() OcuLawRegInfoDto dto) {
        
    	dto.setLawSeq(lawSeq);
        service.updateOcuLawRegInfo(dto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 법규등록대장 정보 삭제
     * @param lawSeq
     * @return
     */
    @Operation(summary = "법규등록대장 정보 삭제", description = "법규등록대장 정보 삭제 API")
    @DeleteMapping(value = "/general/lawRegInfo/{lawSeq}")
    public ResponseEntity<?> deleteOcuLawRegInfo(@PathVariable(value="lawSeq") String lawSeq) {
        service.deleteOcuLawRegInfo(lawSeq);
        return ResponseUtil.createSuccessResponse();
    }
    
    /**
     * 법규등록대장 승인
     * @param lawSeq
     * @return
     */
    @Operation(summary = "법규등록대장 승인", description = "법규등록대장승인 API")
    @PutMapping(value = "/general/ApprovalLawRegInfo/{lawSeq}")
    public ResponseEntity<?> ApprovalLawRegInfo(@PathVariable(value="lawSeq") String lawSeq) {
        service.approvalLawRegInfo(lawSeq);
        return ResponseUtil.createSuccessResponse();
    }
    
    
}


