package com.koreanair.ksms.avn.srm.dto;

import com.koreanair.ksms.common.utils.DateUtil;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.Accessors;

import java.sql.Timestamp;
import java.util.Objects;

@Setter
@Getter
@Accessors(chain = true)
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "보고서 내용")
public class SmReport {

    @NotNull
    private int id;

    private String docNo;

    @NotBlank
    private String reportType;

    @NotBlank
    private String empNo;

    private String subject;

    @NotBlank
    private String timeZone;

    @NotBlank
    private String phase;

    private String reportPhase;

    @NotBlank
    private String stateType;

    private String reportStateType;

    private String stepCode;

    //@NotNull
    //private Timestamp createdAt;

    //@NotNull
    //private Timestamp updatedAt;

    private Timestamp deletedAt;

    private String isSubmitted;

    private Timestamp submittedAt;

    private String assessmentNotes;

    private String isStatisticsOnly;

    private String createdBy;

    public SmReport(int id, String state, String phase, String stepCode, String reportType) {
        this.id = id;
        this.stateType = state;
        this.phase = phase;
        this.stepCode = stepCode;
        this.reportType = reportType;
    }

    public String parseSubmittedAt() {
        if (Objects.isNull(this.submittedAt)) {
            return null;
        }
        return DateUtil.toDateFormat(this.submittedAt.getTime(), "yyyyMMdd");
    }
}