package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.ocu.mgmt.service.OcuHazardService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 안전관리 - 안전신고
 */
@Tag(name = "OcuHazard", description = "안전관리 - 안전신고 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuHazardController {

    @Autowired
    OcuHazardService service;
}
