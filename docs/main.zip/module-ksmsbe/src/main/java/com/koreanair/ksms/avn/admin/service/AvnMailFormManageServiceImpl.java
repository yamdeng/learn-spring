package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnMailFormManageServiceImpl extends AbstractBaseService implements AvnMailFormManageService {

    //  관리자 > 메일양식관리 조회
    @Override
    public PageInfo<TbAvnMailDto> selectMailList(TbAvnMailDto tbAvnMailDto) {
        List<TbAvnMailDto> resultList = commonSql.selectList("AvnMailFormManage.selectMailList", tbAvnMailDto);
        return PageInfo.of(resultList);
    }

    //  관리자 > 메일양식관리 신규 등록
    @Override
    public void insertMail(TbAvnMailDto tbAvnMailDto) {
        commonSql.insert("AvnMailFormManage.insertMail", tbAvnMailDto);
    }

    //  관리자 > 메일양식관리 상세
    @Override
    public TbAvnMailDto selectMailDetail(String mailCode) {
        return commonSql.selectOne("AvnMailFormManage.selectMailDetail", mailCode);
    }

    //  관리자 > 메일양식관리 수정
    @Override
    public void updateMail(TbAvnMailDto tbAvnMailDto) {
        commonSql.update("AvnMailFormManage.updateMail", tbAvnMailDto);
    }

    //  관리자 > 메일양식관리 삭제
    @Override
    public void deleteMail(String mailCode) {
        commonSql.delete("AvnMailFormManage.deleteMail", mailCode);
    }
}
