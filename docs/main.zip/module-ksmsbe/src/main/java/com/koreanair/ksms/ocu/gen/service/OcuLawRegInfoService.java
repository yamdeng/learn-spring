package com.koreanair.ksms.ocu.gen.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegInfoDto;

import jakarta.validation.Valid;

/**
 * 법규등록대장 정보 service
 */
public interface OcuLawRegInfoService {

	/**
	 * 법규등록대장 정보 목록 조회
	 * @param paramDto
	 * @return
	 */
	public PageInfo<OcuLawRegInfoDto> selectOcuLawRegInfoList(OcuLawRegInfoDto paramDto);
	
    /**
     * 법규등록대장 정보 상세 조회
     * @param lawSeq
     * @return
     */
	public OcuLawRegInfoDto selectOcuLawRegInfo(String lawSeq);

    /**
     * 법규등록대장 정보 등록
     */
    public void insertOcuLawRegInfo(@Valid OcuLawRegInfoDto dto);
    
    /**
     * 법규등록대장 정보 수정
     */
    public void updateOcuLawRegInfo(@Valid OcuLawRegInfoDto dto);
    
    /**
     * 법규등록대장 정보 삭제
     * @param lawSeq
     */
    public void deleteOcuLawRegInfo(String lawSeq);

	/**
	 * 법규등록대장 승인
	 * @param lawSeq
	 */
	public void approvalLawRegInfo(String lawSeq);

	
	
    
 
}
