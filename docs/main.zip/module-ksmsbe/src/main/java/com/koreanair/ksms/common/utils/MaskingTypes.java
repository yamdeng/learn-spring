package com.koreanair.ksms.common.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MaskingTypes {
	ALL,
	EMP_NO,
	NONE;
}
