package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode.*;
import com.koreanair.ksms.common.dto.TbAvnSmGroup;
import com.koreanair.ksms.common.dto.TbAvnSmGroupList;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import io.micrometer.common.util.StringUtils;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.ValidationException;
import jakarta.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
public class AvnReportProcessServiceImpl extends AbstractBaseService implements AvnReportProcessService {

    @Autowired
    private Validator validator;

    @Autowired
    KsmsCommonService ksmsCommonService;

    //보고서 묶음 처리 시 유효성 체크
    @Override
    public boolean getIsValidateGroupReport(Integer groupId) {
        int cnt = 0;

        //보고서 상태 체크
        cnt = commonSql.selectOne("AvnReportProcess.selectStatusValidateGroupReport", groupId);
        if (cnt == 0) {
            return false;
        }

        //보고서 묶임 체크
        cnt = commonSql.selectOne("AvnReportProcess.selectGroupedValidateGroupReport", groupId);
        if (cnt != 1) {
            return false;
        }

        return true;
    }

    //(기존)보고서 묶음 처리
    @Transactional
    @Override
    public void insertMergeGroupReport(List<Integer> groupReportList) {
        TbAvnSmGroupList groupList = new TbAvnSmGroupList();
        TbAvnSmGroup oldGroupList = new TbAvnSmGroup();

        for (Integer groupId : groupReportList) {
            //첫번째 보고서의 그룹ID 저장
            if (groupReportList.indexOf(groupId) == 0) {
                groupList.setGroupId(groupId);
                continue;
            }
            groupList.setOldGroupId(groupId);
            commonSql.insert("AvnReportProcess.insertMergeGroupReportList", groupList);

            oldGroupList.setId(groupId);
            commonSql.delete("AvnReportProcess.deleteGroupReportList", oldGroupList);
            commonSql.delete("AvnReportProcess.deleteGroupReport", oldGroupList);
        }
    }

    //(신규)보고서 묶음 처리
    @Transactional
    public void insertGroupReport(TbAvnSmGroup group) {
        commonSql.insert("AvnReportProcess.insertNewGroupReport", group);

        TbAvnSmGroupList groupList = new TbAvnSmGroupList();
        groupList.setGroupId(group.getId());
        groupList.setReportId(group.getReportId());
        commonSql.insert("AvnReportProcess.insertNewGroupReportList", groupList);
    }

    //보고서 대표 보고서 수정
    @Transactional
    @Override
    public void updateIsMainReport(TbAvnSmGroupList tbAvnSmGroupList) {
        commonSql.update("AvnReportProcess.updateIsMainReport", tbAvnSmGroupList);
    }

    /** <pre>
     * 보고서 상태 관리
     * {@link ReportProcessVo}:
     * {@link StepType}(진행상태) / reason(reject, void 시에는 사유도 같이 포함됨)
     </pre> */
    @SuppressWarnings("unused")
    @Transactional
    @Override
    public boolean smsReportProcess(ReportProcessVo processVo) throws Exception {

        validateProcessVo(processVo);

        //현재 상태 조회
        ReportProcessDto status = selectReportStatus(processVo.getReportId());

        ReportProcess report = ReportProcess.find(status.getPhase(), status.getStepCode());

        ReportStatus nextStat = report.findProc(processVo.getStepType());

        logger.debug("\r\n\r\n\r\n@@@ Report {} Current Step: {} / {}, => StepType: {}: {} / {}\r\n\r\n"
                , report.name(), report.getStatus().name(), report.getStatus().getName(), nextStat.getName()
                , nextStat.name(), nextStat.getName());

        if(nextStat != null) {
            processAction(processVo, status.getReportType(), nextStat); // Execute function
            return true;
        }
        return false;
    }

    @Transactional
    @Override
    public void processAction(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        for(Action action : stat.getActionList()) {
            switch (action) {
                case UPDATE_REPORT:
                    updateReportStatus(processVo, reportType, stat);
                    break;
                case UPDATE_HAZARD:
                    updateHazardStatus(processVo, reportType, stat);
                    break;
                case INSERT_ROLE:
                    insertReportRole(processVo, reportType, stat);
                    break;
                case DELETE_ROLE:
                    deleteReportRole(processVo, reportType, stat);
                    break;
                default:
                    break;
            }
        }
        // send after action completed without void and delete
        if(Step.VOIDED!=stat.getStep() && Step.DELETED !=stat.getStep()) {
            //TODO KHW. 메일, 알림 발송 처리
            //reportSysNotiService.sendNoti(processVo, stat);
            //this.sendNoti(processVo, stat);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateReportStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {

        logger.debug("\r\n\r\n* updateReportStatus\r\n");
        String state = stat.getState().getCode();
        String phase = stat.getPhase().getCode();
        String step = stat.getStep().getCode();
        String reason = processVo.getReason();

        SmReportApprovalLog logParam = new SmReportApprovalLog(processVo.getReportId(), state, phase, step, processVo.getEmpNo(), reason);
        logParam.setTimezone(processVo.getTimezone());
        if(stat.getStep() == Step.REJECTED || stat.getStep() == Step.VOIDED) {
            if(StringUtils.isBlank(processVo.getReason())) {
                throw new ValidationException("[ReportProcessVo.reason] is required");
            }
        }

        if(StringUtils.isNotBlank(processVo.getReason())) {
            logParam.setReason(processVo.getReason());
        }

        commonSql.insert("AvnReportProcess.insertReportApprovalLog", logParam);

        SmReport reportParam = new SmReport(processVo.getReportId(), state, phase, step, reportType);
        if (stat.getStep() == Step.VOIDED) {
            // state => voided
            reportParam.setStateType(step);
        }
        commonSql.update("ReportProcess.updateReportStatus", reportParam);

        // 2022-06-24 RSR 보고서가 제출 완료된 경우  추가처리
        if("rsr".equals(reportType) && Phase.REPORTING==stat.getPhase() && Step.SUBMITTED == stat.getStep() ) {
            updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
        }

        //2024-09 보고서가 제출 완료된 경우 그룹(묶음)보고서를 자동 생성함(rsr 보고서 제외)
        if(!"rsr".equals(reportType) && Phase.REPORTING==stat.getPhase() && Step.SUBMITTED == stat.getStep() ) {
            TbAvnSmGroup group = new TbAvnSmGroup();
            group.setReportType(reportType);
            group.setPhase(phase);
            group.setStateType(state);
            group.setReportId(processVo.getReportId());
            this.insertGroupReport(group);
        }
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateHazardStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        logger.debug("\r\n\r\n** updateHazardStatus\r\n");
        String state = stat.getState().getCode();
        String phase = stat.getPhase().getCode();
        String step = stat.getStep().getCode();
        String reason = processVo.getReason();

        SmReportApprovalLog logParam = new SmReportApprovalLog(processVo.getHazardId(), state, phase, step, processVo.getEmpNo(), reason);
        logParam.setTimezone(processVo.getTimezone());
        if(stat.getStep() == Step.REJECTED ||stat.getStep()== Step.REJECTED_MIT || stat.getStep() == Step.VOIDED) {
            if(StringUtils.isBlank(processVo.getReason())) {
                throw new ValidationException("[ReportProcessVo.reason] is required");
            }
        }

        if(StringUtils.isNotBlank(processVo.getReason())) {
            logParam.setReason(processVo.getReason());
        }

        commonSql.insert("ReportProcess.insertHazardApprovalLog", logParam);

        SmReportHazard hazardParam = new SmReportHazard(processVo.getReportId(), processVo.getHazardId(), state, phase, step);
        commonSql.update("ReportProcess.updateHazardStatus", hazardParam);

        // 리포트 CLOSE, VOID, DELETE 처리
        if (stat == ReportStatus.HZD_CLOSE_APPROVED || stat.getStep() == Step.VOIDED || stat.getStep() == Step.DELETED) {
            // 진행중인 HAZARD Count
            int count = commonSql.selectOne("ReportProcess.selectReportInProcessCount", processVo.getReportId());
            if (count == 0) {
                if (stat == ReportStatus.HZD_CLOSE_APPROVED) {
                    // HAZARD CLOSE 시 진행중인 다른 HAZARD가 없을 경우 REPORT CLOSE
                    updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
                } else {
                    // 종료된(Closed) HAZARD Count
                    count = commonSql.selectOne("ReportProcess.selectReportClosedCount", processVo.getReportId());
                    if (count == 0) {
                        if(stat.getStep() == Step.VOIDED) {
                            // HAZARD VOID시 진행중인 다른 HAZARD가 없고 CLOSED 된 HAZARD가 없을 경우 REPORT VOID
                            // (REPORT 상태는 접수단계에서 VOID된 상태로 표시됨)
                            updateReportStatus(processVo, reportType, ReportStatus.RECEPTION_VOIDED); // 리포트 VOID
                        }
                    } else {
                        // HAZARD VOID & DELETE시 진행중인 다른 HAZARD가 없고 CLOSED 된 HAZARD가 있을경우 REPORT CLOSE
                        updateReportStatus(processVo, reportType, ReportStatus.REPORT_CLOSE_APPROVED); // 리포트 CLOSE
                    }
                }
            }
        }else if (stat == ReportStatus.SECOND_RISK_APPROVED) {
            HazardProcess current=processVo.getHazardProcess();
            if(current.getStatus()==ReportStatus.HZD_CLOSE_REJECTED_MIT){
                // 위해요인 종결 반려에서 승인한 경우는 draft 로그를 쌓는다
                updateHazardStatus(processVo, reportType, ReportStatus.SECOND_RISK_DRAFT);
            }
        } else if (processVo.getHazardProcess().getStatus() == ReportStatus.HZD_CLOSE_APPROVED
                && stat == ReportStatus.MIT_RESULT_DRAFT) {
            ReportProcessDto status = selectReportStatus(processVo.getReportId());
            ReportProcess report = ReportProcess.find(status.getPhase(), status.getStepCode());
            if(report.getStatus() == ReportStatus.REPORT_CLOSE_APPROVED) {
                // 2022-08-08 경감조치 유효성 평가(안전보증) 반려시 (RECEPTION_APPROVED 상태로 변경)
                ReportStatus assurance = ReportStatus.RECEPTION_APPROVED;
                updateReportStatus(processVo, reportType, assurance);
            }
        }
    }

    // 권한 부여 (ke_report_fr_account)
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void insertReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        logger.debug("\r\n\r\n*** insertReportRole\r\n");
        ReportRoleAccountDto param = new ReportRoleAccountDto();
        param.setReportId(processVo.getReportId());
        switch (stat) {
            case REPORTING_SUBMITTED:
                /* 보고서 제출 - 시스템 관리자 (SA) Primary 열람 그룹 (PVG)
                 * 보고서별 접수담당자 그룹(?MG), 보고서별 열람 그룹(?VG) */
                param.setType("roleCd");
                param.setRoleCdList(RoleByReport.find(reportType).getRoleCdList());
                break;
            case RECEPTION_APPROVED:
                // 접수 완료 - LSC(ke.sm_lsc)
                param.setType("lsc");
                //TODO khw. 필요한지 확인 필요
                //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
                break;
            case FIRST_RISK_SUBMITTED:
                // 1차위험도평가 제출 (roleCd : SSC)
                param.setType("roleCd");
                param.setRoleCdList(Arrays.asList("SSC"));
                break;
            case MIT_ASSIGN_APPROVED:
                // 경감조치 접수팀장 승인 - MIT 팀 (ke.sm_mitigation) 부서 전체 권한부여
                MitigationMemberDto mitMember = selectMitigationMember(processVo.getHazardId());
                param.setDeptId(mitMember.getDeptId());
                param.setType("mit");
                //TODO khw. 필요한지 확인 필요
                //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
                break;
            default:
                break;
        }
        commonSql.insert("ReportProcess.insertReportFrAccount", param);
    }

    @Transactional
    @Override
    public void deleteReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception {
        logger.debug("\r\n\r\n*** deleteReportRole\r\n");
        ReportRoleAccountDto param = new ReportRoleAccountDto();
        param.setReportId(processVo.getReportId());
        switch (stat) {
            case MIT_ACCEPT_REJECTED:
                MitigationMemberDto mitMember = selectMitigationMember(processVo.getHazardId());
                RejectMitigationDto mitValidate = RejectMitigationDto.builder()
                        .reportId(processVo.getReportId())
                        .deptId(mitMember.getDeptId())
                        .hazardId(processVo.getHazardId())
                        .build();
                //1. 삭제 가능 여부 체크
                if(validateDeleteMitigationRole(mitValidate)) {
                    logger.debug("\r\n\r\n*** MIT role revoke @@@\r\n");
                    param.setDeptId(mitMember.getDeptId());
                    // 1. 내 부서로 할당된 경감조치 목록중 
                    param.setType("mit");
                    commonSql.delete("ReportProcess.deleteReportFrAccount", param);
                }
            default:
                break;
        }
    }
    
    
    private void validateProcessVo(ReportProcessVo processVo) {
        Set<ConstraintViolation<ReportProcessVo>> violations = validator.validate(processVo);
        if (!violations.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (ConstraintViolation<ReportProcessVo> constraintViolation : violations) {
                sb.append(constraintViolation.getMessage());
            }
            throw new ConstraintViolationException("Error occurred: " + sb.toString(), violations);
        }
    }

    @Override
    public ReportProcessDto selectReportStatus(int id) throws Exception {
        ReportProcessDto result = new ReportProcessDto();
        try {
            result = commonSql.selectOne("ReportProcess.selectSmReportStatus", id);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public HazardProcessDto selectHazardStatus(int id) throws Exception {
        HazardProcessDto result = new HazardProcessDto();
        try {
            result = commonSql.selectOne("ReportProcess.selectSmHazardStatus", id);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return result;
    }

    @Override
    public MitigationMemberDto selectMitigationMember(int hazardId) throws Exception {
        MitigationMemberDto mitMember = new MitigationMemberDto();
        try {
            mitMember = commonSql.selectOne("ReportProcess.selectMitigationMember", hazardId);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
        return mitMember;
    }

    @Override
    public boolean insertLscMember(ReportRoleAccountDto param) throws Exception {
        // lsc type 고정
        param.setType("lsc");
        //commonSql.insert("ReportProcess.insertVgroupMember", param); // 가상그룹 추가
        commonSql.insert("ReportProcess.insertReportFrAccount", param);
        return true;
    }

    @Override
    public boolean validateDeleteMitigationRole(RejectMitigationDto param) throws Exception {
        RejectMitigationDto result = commonSql.selectOne("ReportProcess.validateDeleteMitigationRole", param);
        return result.compare();
    }
}
