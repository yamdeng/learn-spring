package com.koreanair.ksms.avn.admin.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbKeConsequenceDto extends CommonDto {

//    @NotBlank
//    @Size(max=30)
//    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
//    private String codeGrpId;
//    private String codeGrpNameKor;
//    private String codeGrpNameEng;
//
//    @NotBlank
//    @Size(max=255)
//    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
//    private String codeId;
//
//    @NotBlank
//    @Size(max=250)
//    private String codeNameKor;
//
//    @NotBlank
//    @Size(max=250)
//    private String codeNameEng;

    private int num;
    private int consequenceId;
    private String reportType;
    private String nameKo;
    private String nameEn;
    private int viewOrder;
    private String useYn;
    private String notes;
    private String delUserId;
    private String delDttm;
}
