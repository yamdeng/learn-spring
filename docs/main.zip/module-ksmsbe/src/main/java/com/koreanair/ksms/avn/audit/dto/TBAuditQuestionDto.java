package com.koreanair.ksms.avn.audit.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / Question")
public class TBAuditQuestionDto {

    @Schema(description = "questionId")
    @NotNull
    private int questionId;

    @Schema(description = "원본 ID")
    private int origId;

    @Schema(description = "챕터 원본 ID")
    private int chapterOrigId;

    @Schema(description = "리비전")
    private int revision;

    @Schema(description = "체크리스트 리비전")
    private int checklistRevision;

    @Schema(description = "질문내용")
    private String content;

    @Schema(description = "참고 매뉴얼")
    private String refManual;

    @Schema(description = "표시 순서")
    private String viewOrder;

    @Schema(description = "메모")
    private String notes;

    @Schema(description = "우선사항")
    private String priority;

    @Schema(description = "우선사항 표기명")
    private String priorityNm;

    @Schema(description = "우선사항 색상")
    private String priorityColor;

    @Schema(description = "발생빈도")
    private String probability;

    @Schema(description = "발생빈도 표기명")
    private String probabilityNm;

    @Schema(description = "발생빈도 색상")
    private String probabilityColor;

    @Schema(description = "심각도")
    private String severity;

    @Schema(description = "심각도 표기명")
    private String severityNm;

    @Schema(description = "심각도 색상")
    private String severityColor;

    @Schema(description = "활성/비활성 상태")
    private String state;

    @Schema(description = "등록자")
    private String regUserId;

    @Schema(description = "등록일시")
    private Timestamp regDttm;

    @Schema(description = "수정자")
    private String updUserId;

    @Schema(description = "수정일시")
    private Timestamp updDttm;

    @Schema(description = "삭제일시")
    private Timestamp deletedAt;
}
