package com.koreanair.ksms.ocu.edu.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class OcuSpecialEduServiceImpl extends AbstractBaseService implements OcuSpecialEduService {
}
