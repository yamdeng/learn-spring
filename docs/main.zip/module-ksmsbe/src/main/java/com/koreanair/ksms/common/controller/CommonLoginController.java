package com.koreanair.ksms.common.controller;

import com.koreanair.ksms.common.dto.LoginRequestDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.CommonLoginService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@Tag(name = "CommonLogin", description = "공통 로그인 API")
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/auth")
public class CommonLoginController {

    private final CommonLoginService authService;

    @Operation(summary = "사번으로 로그인", description = "사번으로 로그인하는 API")
    @PostMapping("login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDto request) {

        Map<String, Object> tokens = this.authService.login(request);
        return ResponseEntity.status(HttpStatus.OK).body(tokens);
    }
}
