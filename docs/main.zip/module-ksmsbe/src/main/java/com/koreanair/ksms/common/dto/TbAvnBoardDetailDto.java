package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "게시판 상세(열람)")
public class TbAvnBoardDetailDto extends CommonDto {
    
    @Schema(description = "게시판 ID")
    @NotBlank
    private String boardId;
    
    @Schema(description = "사번")
    @NotBlank
    private String empNo;
    private String empName;
    
    @Schema(description = "부서코드")
    private String deptCd;
    private String deptNm;
}
