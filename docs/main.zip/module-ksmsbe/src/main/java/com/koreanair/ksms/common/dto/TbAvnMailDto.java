package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "메일양식관리")
public class TbAvnMailDto extends CommonDto {

    @Schema(description = "순번")
    private int num;

    @Schema(description = "메일코드")
    private String mailCode;

    @Schema(description = "메일명")
    @NotBlank
    private String mailName;

    @Schema(description = "메일업무구분")
    @NotBlank
    private String mailJobType;

    @Schema(description = "메일내용")
    private String content;

    @Schema(description = "메모")
    private String notes;

    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;

    @Schema(description = "배치여부")
    private String batYn;

    @Schema(description = "첨부파일 ID")
    private int fileGroupSeq;
}
