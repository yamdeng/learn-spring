package com.koreanair.ksms.common.utils;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.koreanair.ksms.common.dto.MailDto;
import org.apache.commons.text.StringSubstitutor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class MailSender {
	
	@Value("${interface.mailSendUrl}")
	String url;
	
	@Value("${interface.tid}")
	String tid;
	
	@Value("${interface.interfaceId}")
	String interfaceId;
	
	public Map<String, Object> send(List<MailDto> msgParams) {
		Map<String, Object> result = new HashMap<>();
//		DateTime now = new DateTime();
		String now = new SimpleDateFormat("YYYYMMddHHmmssSS").format(System.currentTimeMillis());
		String xml = "";
		xml += "<?xml version='1.0' encoding='UTF-8'?>";
		xml += "<soap:Envelope xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/' xmlns:wsu='http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd'>";
		xml += "<soap:Body xmlns:ns1='http://eai.koreanair.com/EaiMessage'>";
		xml += "<MessageCollection>";
		xml += "<HeaderType>";
		xml += "<InstanceID>" + interfaceId + "_" + now + "</InstanceID>";
		xml += "<SubInstanceID>" + interfaceId + "_" + now + "</SubInstanceID>";
		xml += "<InterfaceID>" + interfaceId + "</InterfaceID>";
		xml += "<CurrentHostName>XW</CurrentHostName>";
		xml += "<TimeStamp>" + now + "</TimeStamp>";
		xml += "<Sequence></Sequence>";
		xml += "<Signal></Signal>";
		xml += "<Loc></Loc>";
		xml += "<Status></Status>";
		xml += "<Msg></Msg>";
		xml += "<KeyValue1></KeyValue1>";
		xml += "<KeyValue2></KeyValue2>";
		xml += "<KeyValue3></KeyValue3>";
		xml += "<ErrorCode></ErrorCode>";
		xml += "<ErrorMsg></ErrorMsg>";
		xml += "<Payload></Payload>";
		xml += "<Attribute1></Attribute1>";
		xml += "<Attribute2></Attribute2>";
		xml += "<Attribute3></Attribute3>";
		xml += "<Attribute4></Attribute4>";
		xml += "<Attribute5></Attribute5>";
		xml += "</HeaderType>";

		xml += "<BodyType>";
		xml += "&lt;ROWSET>";

		String messageBodyTemplate = "";
		messageBodyTemplate += "&lt;ROW num='${rowNum}'>";
		messageBodyTemplate += "&lt;TID>" + tid + "&lt;/TID>";
		messageBodyTemplate += "&lt;MSG_TYPE>M&lt;/MSG_TYPE>";
		messageBodyTemplate += "&lt;EMAIL>${rcvEmail}&lt;/EMAIL>";
		messageBodyTemplate += "&lt;NAME>${rcvName}&lt;/NAME>";
		messageBodyTemplate += "&lt;TITLE>${title} &lt;/TITLE>";
		messageBodyTemplate += "&lt;CONTENTS><![CDATA[${msg}]]>&lt;/CONTENTS>";
		messageBodyTemplate += "&lt;SEMAIL>${strSemail}&lt;/SEMAIL>";
		messageBodyTemplate += "&lt;SNAME>${strSname}&lt;/SNAME>";
		messageBodyTemplate += "&lt;/ROW>";
		
		for (int i = 0; i < msgParams.size(); i += 1) {
			MailDto msg = msgParams.get(i);
			Map<String, Object> xmlParams = new ObjectMapper().convertValue(msg, new TypeReference<Map<String, Object>>() {});
			xmlParams.put("rowNum", i + 1);
			StringSubstitutor stringSubstitutor = new StringSubstitutor(xmlParams);
			String body = stringSubstitutor.replace(messageBodyTemplate);
			xml += body;
		}
		
		xml += "&lt;/ROWSET>";
		xml += "</BodyType>";
		xml += "</MessageCollection>";
		xml += "</soap:Body>";
		xml += "</soap:Envelope>";

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Type", "text/xml; charset=UTF-8");
		headers.add("SOAPAction", "process");
		
		HttpEntity<String> entity = new HttpEntity<>(xml, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
		result.put("response", response);
		return result;
	}

//	private static Document convertStringToXMLDocument(String xmlString) {
//		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
//		DocumentBuilder builder = null;
//		try {
//			builder = factory.newDocumentBuilder();
//			Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
//			return doc;
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return null;
//	}

}
