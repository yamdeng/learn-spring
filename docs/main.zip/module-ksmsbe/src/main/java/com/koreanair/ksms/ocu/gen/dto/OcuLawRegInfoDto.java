package com.koreanair.ksms.ocu.gen.dto;

import java.util.List;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "법규등록대장 기준 정보")
public class OcuLawRegInfoDto extends CommonDto {
	
	private List<String> search;
	
	@Schema(description = "순번")
	private int num;
    
    @Schema(description = "법령_ID")
    private String lawId;
    
    @Schema(description = "법령_일련번호")
    private String lawSeq;
    
    @Schema(description = "법령명")
    private String lawNm;
    
    @Schema(description = "주관_부서_코드")
    private String subjectDeptCd;
    
    
    @Schema(description = "법령 종류")
    private String lawKind;
    
    
    @Schema(description = "공포일자")
    private String fearDt;
    
    
    @Schema(description = "시행일자")
    private String implDt;
    
    
    @Schema(description = "제개정 종류")
    private String lgsltKind;
    
    
    @Schema(description = "소관부처")
    private String respMinistryNm;
    
    
    @Schema(description = "법령 상세 링크")
    private String lawDtlLink;
    
    
    @Schema(description = "개정 내용")
    private String revisionCn;
    
    
    @Schema(description = "영향도 평가")
    private String inflDegreeEval;
    
    
    @Schema(description = "키워드 내용")
    private String keyWordContent;
    
    
    @Schema(description = "승인 ID(승인자)")
    private String aprvId;
    
    @Schema(description = "결재상태")
    private String aprvStat;
    
    @Schema(description = "결재 상태 명")
    private String aprvStatNm;
    
    @Schema(description = "결재 일시")
    private String aprvDt;
    
    
    @Schema(description = "해당부서")
    private String rlvtDeptCd;
    
    
    @Schema(description = "상태")
    private String approvalStatus;
    
    
    @Schema(description = "일자 구분 값")
    private String type;
    
    
    @Schema(description = "시작일자")
    private String fromDt;
    
    @Schema(description = "종료일자")
    private String toDt;
    
    
    @Schema(description = "평가자 ID")
    private String evalId;
    
    @Schema(description = "법규등록대장 해당 부서 정보")
    private List<OcuLawRegInfoDto> list;
      
    @Getter
    @Setter
    public static class Post {
       
       @Schema(description = "법규등록대장")
       private OcuLawRegInfoDto.Create form;
       
       @Schema(description = "법규등록대장 해당 부서 정보")
       private List<OcuLawRegInfoDto> list;
       
    }
    
    @Getter
    @Setter
    public static class Create {

        @Schema(description = "법령_일련번호")
        private String lawSeq;

    	@Schema(description = "개정 내용")
    	private String revisionCn;
    	    
	    @Schema(description = "영향도 평가")
	    private String inflDegreeEval;
	    
	    @Schema(description = "키워드 내용")
	    private String keyWordContent;
	    
	    @Schema(description = "승인 ID(승인자)")
	    private String aprvId;
	    
	    @Schema(description = "결재상태")
	    private String aprvStat;
	    
	    @Schema(description = "평가자 ID")
	    private String evalId;
	    
    }
    

    
    
    
}
 