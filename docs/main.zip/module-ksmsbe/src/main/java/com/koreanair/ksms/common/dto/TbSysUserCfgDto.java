package com.koreanair.ksms.common.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysUserCfgDto extends CommonDto {

    private String userId;
    private String lang;
    private String initMenuId;
    private String reportsLang;

    private String individualReportsLang;
    private String ASR;
    private String CSR;
    private String MSR;
    private String GSR;
    private String HZR;
    private String DSR;
    private String RSR;
    private String FOQA;
}
