package com.koreanair.ksms.ocu.risk.controller;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.risk.service.OcuRiskMainService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 위험성평가 - 서브 메인
 */
@Tag(name = "OcuRiskMain", description = "위험성평가 - 전체 현황 및 진척도 통계정보 조회 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuRiskMainController {

    @Autowired
    OcuRiskMainService service;

    /**
     * 전체 현황 및 진척도 통계정보 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "전체 현황 및 진척도 통계정보 조회", description = "전체 현황 및 진척도 통계정보 조회 API")
    @GetMapping(value = "/risk/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
