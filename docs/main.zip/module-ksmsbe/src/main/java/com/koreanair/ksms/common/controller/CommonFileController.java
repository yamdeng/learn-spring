package com.koreanair.ksms.common.controller;

import com.koreanair.ksms.common.dto.TbSysFileDto;
import com.koreanair.ksms.common.service.CommonFileService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 파일 업로드/다운로드
 */
@Tag(name = "CommonFile", description = "파일 업로드/다운로드 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/com")
public class CommonFileController {

    @Autowired
    CommonFileService fileService;

    @Operation(summary = "파일 그룹 목록 조회", description = "파일 그룹 목록 조회 API")
    @GetMapping(value = "/file-groups")
    public ResponseEntity<?> getFileGroupList() {

        List<TbSysFileDto> resultList = fileService.selectFileGroupList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "파일 그룹의 파일 목록 조회", description = "파일 그룹의 파일 목록 조회 API")
    @GetMapping(value = "/file-groups/{fileGroupSeq}")
    public ResponseEntity<?> getFileList(@PathVariable(value="fileGroupSeq") int fileGroupSeq) {

        List<TbSysFileDto> resultList = fileService.selectFileList(fileGroupSeq);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "파일 다운로드", description = "파일 다운로드 API")
    @GetMapping(value = "/file-groups/file/{fileSeq}")
    public ResponseEntity<?> downloadFile(@PathVariable(value="fileSeq") int fileSeq) {

        TbSysFileDto fileInfo = fileService.selectFileInfo(fileSeq);

        return fileService.downloadFile(fileInfo);
    }

    @Operation(summary = "파일 삭제", description = "파일 삭제 API")
    @DeleteMapping(value = "/file-groups/file/{fileSeq}")
    public ResponseEntity<?> deleteFile(@PathVariable(value="fileSeq") int fileSeq) {

        fileService.deleteFile(fileSeq);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "파일 업로드", description = "파일 업로드 API")
    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "fileGroupSeq", description = "파일 그룹 SEQ. (값이 있을 경우 기존의 그룹에 파일 업로드, 없을 경우 신규 그룹 생성)")
    })
    @PostMapping(value = "/file-groups/file/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadFile(
            @RequestParam(value="workScope", required = false, defaultValue = "S") String workScope,
            @RequestParam(value="fileGroupSeq", required = false) String fileGroupSeq,
            @RequestPart(required = true) List<MultipartFile> files) {

        fileGroupSeq = fileService.uploadFile(workScope, fileGroupSeq, files);

        Map<String, String> result = new HashMap<String, String>();
        result.put("fileGroupSeq", fileGroupSeq);

        return ResponseUtil.createSuccessResponse(result);
    }
}
