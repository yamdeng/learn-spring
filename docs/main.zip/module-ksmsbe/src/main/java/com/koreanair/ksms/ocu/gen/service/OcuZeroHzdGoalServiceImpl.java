package com.koreanair.ksms.ocu.gen.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuZeroHzdGoalDto;

import ch.qos.logback.core.util.StringUtil;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 무재해운동 ServiceImpl
 */
@Service
@Slf4j
public class OcuZeroHzdGoalServiceImpl extends AbstractBaseService implements OcuZeroHzdGoalService {
	
	/**
	 * 무재해운동 목록 조회
	 */
	@Override
	public PageInfo<OcuZeroHzdGoalDto> selectList(OcuZeroHzdGoalDto dto) {
		List<OcuZeroHzdGoalDto> resultList = commonSql.selectList("OcuZeroHzdGoal.selectList", dto);
		return PageInfo.of(resultList);
	}

	/**
	 * 무재해운동 상세정보 조회
	 */
	@Override
	public OcuZeroHzdGoalDto select(int zeroHzdId) {
		return commonSql.selectOne("OcuZeroHzdGoal.select", zeroHzdId);
	}

	/**
	 * 무재해운동 등록
	 */
	@Override
	public void insert(OcuZeroHzdGoalDto dto) {
		commonSql.insert("OcuZeroHzdGoal.insert", dto);
		
	}

	/**
	 * 무재해운동 수정
	 */
	@Override
	@Transactional
	public void update(OcuZeroHzdGoalDto.Post reqDto) {

		// 무재해 목표 수정
		commonSql.update("OcuZeroHzdGoal.update", reqDto.getForm());
		// 무재해 이력 전체 삭제
		commonSql.delete("OcuZeroHzdGoal.deleteStatusAll", reqDto.getForm().getZeroHzdId());
		
		
		if(reqDto.getList().size() != 0) {
			Map<String, Object> param = new HashMap<String, Object>();
		    param.put("list", reqDto.getList());
		    commonSql.insert("OcuZeroHzdGoal.insertZeroHzdAll", param);
		}
	        
		
	
//		if(reqDto.getList().size() != 0) {
//			for(int i=0; i<reqDto.getList().size(); i ++) {
//				// 무재해 이력 입력
//			}
//		}
			
	}

	/**
	 * 무재해운동 삭제
	 */
	@Override
	@Transactional
	public void delete(int zeroHzdId) {
		
		// 무재해 목표 삭제
		commonSql.delete("OcuZeroHzdGoal.deleteGoal", zeroHzdId);
		
		// 무재해 이력 삭제
		commonSql.delete("OcuZeroHzdGoal.deleteStatus", zeroHzdId);
		
	}

	/**
	 * 무재해운동 이력 조회
	 */
	@Override
	public List<OcuZeroHzdGoalDto> selectZeroHzdList(int zeroHzdId) {
		return commonSql.selectList("OcuZeroHzdGoal.selectZeroHzdList", zeroHzdId);
	}

	/**
	 * 무재해운동 목표 및 이력 등록
	 */
	@Override
	@Transactional
	public void saveZeroHzdGoalStatus(@Valid OcuZeroHzdGoalDto reqDto) {
		// 무재해운동 목표 수정
		commonSql.update("OcuZeroHzdGoal.update", reqDto);
		// 무재해운동 이력 입력
		commonSql.insert("OcuZeroHzdGoal.insertZeroHzd", reqDto);
		
	}

	/**
	 * 무재해운동 중복 체크
	 */
	@Override
	public int selectZeroHzdGoalDupChk(String zeroHzdDeptCd) {
		return commonSql.selectOne("OcuZeroHzdGoal.selectZeroHzdGoalDupChk", zeroHzdDeptCd);
	}


}
