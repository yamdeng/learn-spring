package com.koreanair.ksms.ocu.edu.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.edu.dto.OcuManualEduDto;
import com.koreanair.ksms.ocu.edu.dto.OcuManualEduSignDto;

@Service
public class OcuManualEduServiceImpl extends AbstractBaseService implements OcuManualEduService {

    public OcuManualEduDto selectOcuManualEdu(int id) {
        return commonSql.selectOne("OcuManualEdu.select", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuManualEduDto> selectOcuManualEduList(OcuManualEduDto dto) {
    	List<OcuManualEduDto> resultList = commonSql.selectList("selectOcuManualEduList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuManualEdu(OcuManualEduDto dto) {
        commonSql.insert("insertOcuManualEdu", dto);
    }

    @Override
    public void updateOcuManualEdu(OcuManualEduDto dto) {
        commonSql.update("updateOcuManualEdu", dto);
    }

    @Override
    public void deleteOcuManualEdu(int id) {
        commonSql.delete("deleteOcuManualEdu", id);
    }

    @SuppressWarnings("unchecked")
	@Override
    public void saveOcuManualEdu(List<OcuManualEduDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
            .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
            .collect(Collectors.toList());

        // commonSql.save("OcuManualEdu", mapList);
    }
    
    
    public OcuManualEduSignDto selectOcuManualEduSign(int id) {
        return commonSql.selectOne("OcuManualEduSign.select", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuManualEduSignDto> selectOcuManualEduSignList(OcuManualEduSignDto dto) {
    	List<OcuManualEduSignDto> resultList =  commonSql.selectList("selectOcuManualEduSignList", dto);
    	return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuManualEduSign(OcuManualEduSignDto dto) {
        commonSql.insert("insertOcuManualEduSign", dto);
    }

    @Override
    public void updateOcuManualEduSign(OcuManualEduSignDto dto) {
        commonSql.update("updateOcuManualEduSign", dto);
    }

    @Override
    public void deleteOcuManualEduSign(int id) {
        commonSql.delete("deleteOcuManualEduSign", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuManualEduSign(List<OcuManualEduSignDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());
        // commonSql.save("OcuManualEduSign", mapList);
    }
    
}
