package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - MSR정보")
public class MsrReportResponseDto {
    private int id;

    private ReportWithApprovalStep report;

    private MsrFlightResponseDto flight;

    private MsrEventVo event;

    //private UserVo writer;

    private boolean isSubmit;

    private String timezone;
}
