package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "2차 협력업체")
public class OcuPartner2ndInfoDto extends CommonDto {
    
    @Schema(description = "2차협력업체_ID")
    @NotBlank
    private String scndPrtnrId;
    
    @Schema(description = "협력업체_ID")
    @NotBlank
    private String prtnrId;
    
    @Schema(description = "사업장_ID")
    @NotBlank
    private String bizPlaceId;
    
    @Schema(description = "업체_명")
    @NotBlank
    private String companyNm;
    
    @Schema(description = "주요_업무")
    private String majorWorkCn;
    
    @Schema(description = "담당자_명")
    @NotBlank
    private String staffNm;
    
    @Schema(description = "담당자_연락처")
    private String staffContactNo;
}
