package com.koreanair.ksms.ocu.gen.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.service.OcuManageCostService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전경영 - 산업안전보건 관리비
 */
@Tag(name = "OcuManageCost", description = "안전경영 - 산업안전보건 관리비 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuManageCostController {

    @Autowired
    OcuManageCostService service;

    /**
     * 대시보드 - 계획 대비 집행율 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "대시보드 - 계획 대비 집행율 조회", description = "대시보드 - 계획 대비 집행율 조회 API")
    @GetMapping(value = "/general/cost/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 예산관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "예산관리 목록 조회", description = "예산관리 목록 조회 API")
    @GetMapping(value = "/general/cost/budgets")
    public ResponseEntity<?> getBudgetList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "예산관리 상세정보 조회", description = "예산관리 상세정보 조회 API")
    @GetMapping(value = "/general/cost/budgets/{budgetId}")
    public ResponseEntity<?> getBudgetInfo(@PathVariable(value="budgetId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 예산관리 등록", description = "신규 예산관리 등록 API")
    @PostMapping(value = "/general/cost/budgets")
    public ResponseEntity<?> insertBudget(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "예산관리 정보 수정", description = "예산관리 정보 수정 API")
    @PutMapping(value = "/general/cost/budgets/{budgetId}")
    public ResponseEntity<?> updateBudget(
            @PathVariable(value="budgetId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "예산관리 삭제", description = "예산관리 삭제 API")
    @DeleteMapping(value = "/general/cost/budgets/{budgetId}")
    public ResponseEntity<?> deleteBudget(@PathVariable(value="budgetId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 실적관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "실적관리 목록 조회", description = "실적관리 목록 조회 API")
    @GetMapping(value = "/general/cost/performances")
    public ResponseEntity<?> getPerformanceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "실적관리 상세정보 조회", description = "실적관리 상세정보 조회 API")
    @GetMapping(value = "/general/cost/performances/{performanceId}")
    public ResponseEntity<?> getPerformanceInfo(@PathVariable(value="performanceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 실적관리 등록", description = "신규 실적관리 등록 API")
    @PostMapping(value = "/general/cost/performances")
    public ResponseEntity<?> insertPerformance(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "실적관리 정보 수정", description = "실적관리 정보 수정 API")
    @PutMapping(value = "/general/cost/performances/{performanceId}")
    public ResponseEntity<?> updatePerformance(
            @PathVariable(value="performanceId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "실적관리 삭제", description = "실적관리 삭제 API")
    @DeleteMapping(value = "/general/cost/performances/{performanceId}")
    public ResponseEntity<?> deletePerformance(@PathVariable(value="performanceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
