package com.koreanair.ksms.ocu.gen.dto;

import java.util.List;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.Valid;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "무재해운동 목표 관리")
public class OcuZeroHzdGoalDto extends CommonDto {
	
    @Schema(description = "무재해운동_ID")
    private int zeroHzdId;
    
    @Schema(description = "무재해운동_부서_코드")
    private String zeroHzdDeptCd;
    
    @Schema(description = "달성_목표_배수")
    private int completGoalMltp;
    
    @Schema(description = "관리_총_목표_일수")
    private int mgntTotGoalDays;
    
    @Schema(description = "관리_기준_목표_일수")
    private int mgntStdGoalDays;
    
    @Schema(description = "관리_현_목표_일수")
    private int mgntCurrGoalDays;
    
    @Schema(description = "관리_목표_개시일")
    private String mgntglStartDt;
    
    @Schema(description = "관리_목표_달성_목표일")
    private String mgntglCompletGoalDt;
    
    
    /** 무재해 이력**/
    
    @Schema(description = "무재해운동 현황 ID")
    private int zeroHzdStatId;
    
    @Schema(description = "현황_배수")
    private int statMltp;
    
    @Schema(description = "현황_개시일")
    private String statStartDt;
    
    @Schema(description = "현황_달성_목표일")
    private String statCmpltGoalDt;
    
    @Schema(description = "현황_현_배수_목표일")
    private int currMltpGoalDt;
    
    @Schema(description = "현황_총_목표일수")
    private int statTotGoalDays;
    
    @Schema(description = "현황_실패일")
    private String statFailDt;
    
    @Schema(description = "현황_비고")
    private String statRemark;
    
    @Schema(description = "무재해 운동 이력")
    private List<OcuZeroHzdGoalDto> list;
    
    @Getter
    @Setter
    public static class Post {
       
       @Schema(description = "무재해 운동")
       private OcuZeroHzdGoalDto.Create form;
       
       @Schema(description = "무재해 운동 이력")
       private List<OcuZeroHzdGoalDto> list;
       
    }
    
    @Getter
    @Setter
    public static class Create {

    	@Schema(description = "무재해운동_ID")
        private int zeroHzdId;
        
        @Schema(description = "무재해운동_부서_코드")
        private String zeroHzdDeptCd;
        
        @Schema(description = "달성_목표_배수")
        private int completGoalMltp;
        
        @Schema(description = "관리_총_목표_일수")
        private int mgntTotGoalDays;
        
        @Schema(description = "관리_기준_목표_일수")
        private int mgntStdGoalDays;
        
        @Schema(description = "관리_현_목표_일수")
        private int mgntCurrGoalDays;
        
        @Schema(description = "관리_목표_개시일")
        private String mgntglStartDt;
        
        @Schema(description = "관리_목표_달성_목표일")
        private String mgntglCompletGoalDt;
    }


    
 
    
    
}
