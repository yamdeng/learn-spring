package com.koreanair.ksms.common.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.ksms.common.constants.CommonConstants;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.Field;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Supplier;

@UtilityClass
public final class CommonUtil {

    public static boolean isEmpty(final Object str) {
        if (str == null) {
            return true;
        }
        if ((str instanceof String) && (((String) str).trim().length() == 0)) {
            return true;
        }
        if (str instanceof Map) {
            return ((Map<?, ?>) str).isEmpty();
        }
        if (str instanceof List) {
            return ((List<?>) str).isEmpty();
        }
        if (str instanceof Object[]) {
            return (((Object[]) str).length == 0);
        }
        return false;
    }

    /**
     * @param size         more than 0
     * @param allowedChars not empty
     * @return random string, or null
     */
    public static String generateRandomString(final int size, final String allowedChars) {
        if (size < 1 || CommonUtil.isEmpty(allowedChars)) {
            return null;
        }

        var random = new SecureRandom();
        var sb = new StringBuilder();

        for (var i = 0; i < size; i++) {
            var randomIndex = random.nextInt(allowedChars.length());
            sb.append(allowedChars.charAt(randomIndex));
        }

        return sb.toString();
    }

    public static <T> T safeGet(Supplier<T> supplier) {
        try {
            return supplier.get();
        } catch (Exception e) {
            return null;
        }
    }

    public static <T> T safeGetWithDefault(Supplier<T> supplier, T defaultValue) {
        try {
            if (supplier.get() != null) return supplier.get();
        } catch (Exception e) {
            return defaultValue;
        }
        return defaultValue;
    }

    public static String getIfNotEmptyOrDefault(String value, String defaultValue) {
        return StringUtils.isEmpty(value) ? defaultValue : value;
    }

    public static Field findField(Class<?> clazz, String fieldName) {
        try {
            return clazz.getDeclaredField(fieldName);
        } catch (NoSuchFieldException e) {
            Class<?> superClass = clazz.getSuperclass();
            if (superClass != null) {
                return findField(superClass, fieldName);
            }
            return null;
        }
    }

    public static String stringFormatIfNullToEmpty(String format, Object... args) {
        return String.format(
                format,
                Arrays.stream(args).toList().stream()
                        .map(e -> e == null ? "" : e)
                        .toArray());
    }

    public static String decodeBase64(String data) {
        return new String(Base64.getDecoder().decode(data));
    }

    public static String decodeBase64Safe(String data) {
        return new String(Base64.getUrlDecoder().decode(data));
    }

    public static String decodeUrl(String data) {
        if (data == null) {
            return null;
        } else {
            return URLDecoder.decode(data, StandardCharsets.UTF_8);
        }
    }

    private static final ObjectMapper mapper;

    static {
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public static <T> T mapJsonToObject(String jsonData, Class<T> clazz) {
        if (jsonData == null) {
            return null;
        }

        try {
            return mapper.readValue(jsonData, clazz);
        } catch (Exception e) {
            throw new CustomBusinessException(e.getMessage());
        }
    }

    public static <T> T mapJsonToObject(String jsonData, TypeReference<T> typeReference) {
        if (jsonData == null) {
            return null;
        }

        try {
            return mapper.readValue(jsonData, typeReference);
        } catch (Exception e) {
            throw new CustomBusinessException(e.getMessage());
        }
    }

    public static boolean isNumeric(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static String generateUniqueKey() {
        String currentDateTime =
                LocalDateTime.now().format(DateTimeFormatter.ofPattern(CommonConstants.DATE_FORMAT_YYYYMMDDHHMMSSMS));
        String generatedUuid = UUID.randomUUID().toString().replace("-", "");
        return currentDateTime + generatedUuid;
    }
}