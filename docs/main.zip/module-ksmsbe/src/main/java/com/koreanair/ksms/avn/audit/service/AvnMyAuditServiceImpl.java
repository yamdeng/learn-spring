package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnMyAuditServiceImpl extends AbstractBaseService implements AvnMyAuditService {

    // My Audit 현황 조회
    @Override
    public TBMyAuditStatisticsDto selectMyAuditStatistics(String searchDto) {
        return commonSql.selectOne("AvnMyAudit.selectMyAuditStatistics", searchDto);
    }
        
    // My Audit 목록 조회
    @Override
    public List<TBMyAuditListDto> selectMyAuditList(String searchDto) {
        return commonSql.selectList("AvnMyAudit.selectMyAuditList", searchDto);
    }
}
