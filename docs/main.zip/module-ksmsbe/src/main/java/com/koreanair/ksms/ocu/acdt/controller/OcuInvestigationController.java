package com.koreanair.ksms.ocu.acdt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.acdt.service.OcuInvestigationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 업무상재해 - 사고조사
 */
@Tag(name = "OcuInvestigation", description = "업무상재해 - 사고조사 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuInvestigationController {

    @Autowired
    OcuInvestigationService service;

    /**
     * 사고조사_산업재해 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "사고조사_산업재해 목록 조회", description = "사고조사_산업재해 목록 조회 API")
    @GetMapping(value = "/accident/investigation/occupations")
    public ResponseEntity<?> getOccupationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "사고조사_산업재해 상세정보 조회", description = "사고조사_산업재해 상세정보 조회 API")
    @GetMapping(value = "/accident/investigation/occupations/{occupationId}")
    public ResponseEntity<?> getOccupationInfo(@PathVariable(value="occupationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 사고조사_산업재해 등록", description = "신규 사고조사_산업재해 등록 API")
    @PostMapping(value = "/accident/investigation/occupations")
    public ResponseEntity<?> insertOccupation(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사고조사_산업재해 정보 수정", description = "사고조사_산업재해 정보 수정 API")
    @PutMapping(value = "/accident/investigation/occupations/{occupationId}")
    public ResponseEntity<?> updateOccupation(
            @PathVariable(value="occupationId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사고조사_산업재해 삭제", description = "사고조사_산업재해 삭제 API")
    @DeleteMapping(value = "/accident/investigation/occupations/{occupationId}")
    public ResponseEntity<?> deleteOccupation(@PathVariable(value="occupationId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 사고조사_중대재해 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "사고조사_중대재해 목록 조회", description = "사고조사_중대재해 목록 조회 API")
    @GetMapping(value = "/accident/investigation/serious")
    public ResponseEntity<?> getSeriousList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "사고조사_중대재해 상세정보 조회", description = "사고조사_중대재해 상세정보 조회 API")
    @GetMapping(value = "/accident/investigation/serious/{seriousId}")
    public ResponseEntity<?> getSeriousInfo(@PathVariable(value="seriousId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 사고조사_중대재해 등록", description = "신규 사고조사_중대재해 등록 API")
    @PostMapping(value = "/accident/investigation/serious")
    public ResponseEntity<?> insertSerious(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사고조사_중대재해 정보 수정", description = "사고조사_중대재해 정보 수정 API")
    @PutMapping(value = "/accident/investigation/serious/{seriousId}")
    public ResponseEntity<?> updateSerious(
            @PathVariable(value="seriousId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "사고조사_중대재해 삭제", description = "사고조사_중대재해 삭제 API")
    @DeleteMapping(value = "/accident/investigation/serious/{seriousId}")
    public ResponseEntity<?> deleteSerious(@PathVariable(value="seriousId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
