package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationDto;

public interface AvnSafetyInvestigationService {

    PageInfo<AvnSafetyInvestigationDto> selectInveReportList();
}
