package com.koreanair.ksms.avn.srm.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestifationConsequenceDto;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestifationHazardDto;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationDto;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationEventTypeDto;

public interface AvnSafetyInvestigationService {

    // 안전위험관리 > 안전조사 > 조사보고서 목록 조회
    PageInfo<AvnSafetyInvestigationDto> selectInveReportList(AvnSafetyInvestigationDto avnSafetyInvestigationDto);

    // 이벤트 타입 목록 조회
    List<AvnSafetyInvestigationEventTypeDto> selectEventTypeASRList();

    // consequence 목록 조회
    List<AvnSafetyInvestifationConsequenceDto> selectConsequenceList();

    // hazard 목록 조회
    List<AvnSafetyInvestifationHazardDto> selectHazardList();
}
