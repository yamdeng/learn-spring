package com.koreanair.ksms.ocu.risk.service;

public interface OcuRiskMainService {
}
