package com.koreanair.ksms.avn.sftr.service;

public interface AvnSafetyReportService {
}
