package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.service.AvnAuditCarSearchService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * AUDIT - 개선 조치(CAR) 조회(CAR Searching)
 */
@Tag(name = "AvnAuditCarSearch", description = "AUDIT - 개선 조치(CAR) 조회(CAR Searching) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditCarSearchController {

    @Autowired
    AvnAuditCarSearchService service;

    /**
     * Top 10 CAR 목록 조회 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Top 10 CAR 목록 조회", description = "Top 10 CAR 목록 조회 API")
    @GetMapping(value = "/audit/car-searching/top10-cars")
    public ResponseEntity<?> getTop10CarList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Airport (공항별) 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Airport (공항별) 통계 조회", description = "Airport (공항별) 통계 조회 API")
    @GetMapping(value = "/audit/car-searching/airports")
    public ResponseEntity<?> getAuditAirportList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Region (지역별) 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Region (지역별) 통계 조회", description = "Region (지역별) 통계 조회 API")
    @GetMapping(value = "/audit/car-searching/regions")
    public ResponseEntity<?> getAuditRegionList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * ESP (업체별) 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "ESP (업체별) 통계 조회", description = "ESP (업체별) 통계 조회 API")
    @GetMapping(value = "/audit/car-searching/esps")
    public ResponseEntity<?> getAuditEspList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Flight Phase (비행단계별) 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Flight Phase (비행단계별) 통계 조회", description = "Flight Phase (비행단계별) 통계 조회 API")
    @GetMapping(value = "/audit/car-searching/flight-phase")
    public ResponseEntity<?> getAuditFlightPhaseList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 기간별 품질심사 목록조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "기간별 품질심사 목록조회", description = "기간별 품질심사 목록조회 API")
    @GetMapping(value = "/audit/car-searching/period")
    public ResponseEntity<?> getAuditPeriodList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }
}
