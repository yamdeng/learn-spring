package com.koreanair.ksms.avn.admin.controller;

import com.koreanair.ksms.avn.admin.service.AvnInstructorManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 강사이력관리
 */
@Tag(name = "AvnInstructorManage", description = "관리자 - 강사이력관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnInstructorManageController {

    @Autowired
    AvnInstructorManageService service;

    /**
     * 강사이력관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "강사이력관리 목록 조회", description = "강사이력관리 목록 조회 API")
    @GetMapping(value = "/admin/instructors")
    public ResponseEntity<?> getInstructorManageList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "강사이력관리 상세정보 조회", description = "강사이력관리 상세정보 조회 API")
    @GetMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> getInstructorManageInfo(@PathVariable(value="instructorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 강사이력관리 등록", description = "신규 강사이력관리 등록 API")
    @PostMapping(value = "/admin/instructors")
    public ResponseEntity<?> insertInstructorManage(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "강사이력관리 정보 수정", description = "강사이력관리 정보 수정 API")
    @PutMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> updateInstructorManage(
            @PathVariable(value="instructorId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "강사이력관리 삭제", description = "강사이력관리 삭제 API")
    @DeleteMapping(value = "/admin/instructors/{instructorId}")
    public ResponseEntity<?> deleteInstructorManage(@PathVariable(value="instructorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
