package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnRiskRegisterServiceImpl extends AbstractBaseService implements AvnRiskRegisterService {
}
