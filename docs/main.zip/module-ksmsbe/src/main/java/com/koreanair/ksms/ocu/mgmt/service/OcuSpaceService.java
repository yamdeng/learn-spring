package com.koreanair.ksms.ocu.mgmt.service;

import com.github.pagehelper.PageInfo;
import java.util.List;

import com.koreanair.ksms.ocu.mgmt.dto.OcuSpaceDto;


public interface OcuSpaceService {

    OcuSpaceDto selectOcuSpace(int id);
    PageInfo<OcuSpaceDto> selectOcuSpaceList(OcuSpaceDto paramDto);

    void insertOcuSpace(OcuSpaceDto dto);
    void updateOcuSpace(OcuSpaceDto dto);
    void deleteOcuSpace(int id);
    void saveOcuSpace(List<OcuSpaceDto> dataList);
    
}
