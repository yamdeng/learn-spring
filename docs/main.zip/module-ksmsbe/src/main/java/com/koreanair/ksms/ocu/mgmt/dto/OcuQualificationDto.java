package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "적격수급업체")
public class OcuQualificationDto extends CommonDto {
    
    @Schema(description = "적격수급업체_ID")
    @NotBlank
    private String qsuppId;
    
    @Schema(description = "담당부문_코드")
    private String chrgSectCd;
    
    @Schema(description = "담당부서_코드")
    private String chrgDeptCd;
    
    @Schema(description = "업체_명")
    @NotBlank
    private String companyNm;
    
    @Schema(description = "대표자_명")
    private String rprsnNm;
    
    @Schema(description = "주소")
    private String addr;
    
    @Schema(description = "계약_시작_일자")
    @NotBlank
    private String agrmStartDt;
    
    @Schema(description = "계약_종료_일자")
    @NotBlank
    private String agrmEndDt;
    
    @Schema(description = "계약_명")
    @NotBlank
    private String agrmNm;
    
    @Schema(description = "주요_업무")
    private String majorWorkCn;
}
