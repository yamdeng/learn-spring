package com.koreanair.ksms.common.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class StatusCodeConstants {

    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";

    public static final String SESSION_EXPIRE = "SESSION_EXPIRE";
    public static final String BAD_REQUEST = "BAD_REQUEST";
    public static final String UNAUTHORIZED_ACCESS = "UNAUTHORIZED_ACCESS";
    public static final String TOO_FREQUENTLY_REQUEST_API = "TOO_FREQUENTLY_REQUEST_API";

    public static final String INTERNAL_SERVER_ERROR = "INTERNAL_SERVER_ERROR";

    public static final String MANDATORY_PARAM_ERROR = "MANDATORY_PARAM_ERROR";
    public static final String INVALID_PARAM_ERROR = "INVALID_PARAM_ERROR";
}
