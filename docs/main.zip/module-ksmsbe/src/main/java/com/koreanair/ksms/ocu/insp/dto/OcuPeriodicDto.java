package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "점검")
public class OcuPeriodicDto extends CommonDto {
    
    @Schema(description = "점검_ID")
    @NotBlank
    private String chkId;
    
    @Schema(description = "점검_구분_코드")
    @NotBlank
    private String chkCls;
    
    @Schema(description = "점검_제목")
    @NotBlank
    private String chkTitle;
    
    @Schema(description = "점검_연도")
    @NotBlank
    private String chkYear;
    
    @Schema(description = "점검_시기_코드")
    @NotBlank
    private String chkPeriodCd;
    
    @Schema(description = "점검_등록_일자")
    @NotBlank
    private String chkRegDt;
    
    @Schema(description = "점검자_사번")
    @NotBlank
    private String chkEmpno;
    
    @Schema(description = "비고")
    private String remark;
    
    @Schema(description = "첨부_사진1_ID")
    private String pohtoId1;
    
    @Schema(description = "첨부_사진2_ID")
    private String pohtoId2;
    
    @Schema(description = "첨부_파일_ID")
    private String fileId;
}
