package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "점검표 사업장")
public class OcuChecklistPlaceDto extends CommonDto {
    
    @Schema(description = "사업장_ID")
    @NotBlank
    private String bizPlaceId;
    
    @Schema(description = "협력업체_ID")
    @NotBlank
    private String prtnrId;
    
    @Schema(description = "점검표_ID")
    @NotBlank
    private String chkListId;
}
