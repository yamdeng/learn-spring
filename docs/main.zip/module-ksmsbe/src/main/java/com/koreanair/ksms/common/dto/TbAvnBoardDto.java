package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "게시판")
public class TbAvnBoardDto extends CommonDto {

    //    @NotBlank
//    @Size(max=30)
//    @Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
    @Schema(description = "게시판 ID")
    private int boardId;        //게시판 ID

    @Schema(description = "게시판 구분")
    private String boardType;   //게시판 구분
    private String boardTypeNm;   //게시판 구분

    @Schema(description = "게시판 순번")
    private int num;            //게시판 순번

    @Schema(description = "공지구분")
    private String notiType;    //공지구분
    private String notiTypeNm;    //공지구분

    @Schema(description = "팝업시작일자 (게시시작일자 / 설문일자)")
    private String popupFromDt; //팝업시작일자 (게시시작일자 / 설문일자)

    @Schema(description = "팝업종료일자 (게시종료일자)")
    private String popupToDt;   //팝업종료일자 (게시종료일자)

    @Schema(description = "팝업여부")
    private String popupYn;     //팝업여부

    @Schema(description = "분석일자")
    private String analysisDt;  //분석일자

    @Schema(description = "열람여부")
    private String viewYn;      //열람여부

    @Schema(description = "상단고정여부")
    private String topFixYn;    //상단고정여부

    @Schema(description = "메인표출여부")
    private String mainShowYn;  //메인표출여부

    @Schema(description = "업무구분")
    private String jobType;     //업무구분
    private String jobTypeNm;     //업무구분

    @Schema(description = "정책구분")
    private String policyType;  //정책구분
    private String policyTypeNm;  //정책구분

    @Schema(description = "제목 국문명")
    private String titleKo;     //제목 국문명

    @Schema(description = "제목 영문명")
    private String titleEn;     //제목 영문명

    @Schema(description = "링크 국문명  (설문링크)")
    private String linkKo;      //링크 국문명

    @Schema(description = "링크 영문명 (설문/답변링크)")
    private String linkEn;      //링크 영문명

    @Schema(description = "배너구분")
    private String bannerType;  //배너구분
    private String bannerTypeNm;  //배너구분

    @Schema(description = "내용")
    private String content;     //내용

    @Schema(description = "SafetyDay URL")
    private String safetyUrl;   //SafetyDay URL

    @Schema(description = "사용여부")
    private String useYn;       //사용여부

    @Schema(description = "링크그룹SEQ")
    private int linkGroupSeq;   //링크그룹SEQ

    @Schema(description = "파일그룹SEQ")
    private int fileGroupSeq;   //파일그룹SEQ

    @Schema(description = "조회수")
    private int viewCount;      //조회수

    @Schema(description = "표시순서")
    private int viewOrder;      //표시순서
}
