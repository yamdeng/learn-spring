package com.koreanair.ksms.ocu.gen.service;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegInfoDto;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 법규등록대장 정보 serviceImpl
 */
@Slf4j
@Service
public class OcuLawRegInfoServiceImpl extends AbstractBaseService implements OcuLawRegInfoService {

	/**
	 * 법규등록대장 정보 목록 조회
	 */
	@Override
	public PageInfo<OcuLawRegInfoDto> selectOcuLawRegInfoList(OcuLawRegInfoDto dto) {
		
		
		List<OcuLawRegInfoDto> resultList = commonSql.selectList("OcuLawRegInfo.selectOcuLawRegInfoList", dto);
		
	    return PageInfo.of(resultList);
	}

	/**
	 * 법규등록대장 정보 상세 조회
	 */
	@Override
	public OcuLawRegInfoDto selectOcuLawRegInfo(String lawSeq) {
		return commonSql.selectOne("OcuLawRegInfo.selectOcuLawRegInfo", lawSeq);
	}

	/**
	 * 법규등록대장 정보 등록
	 */
	@Override
	public void insertOcuLawRegInfo(@Valid OcuLawRegInfoDto dto) {
		commonSql.insert("OcuLawRegInfo.insertOcuLawRegInfo", dto);
		
	}

	/**
	 * 법규등록대장 정보 수정
	 */
	@Override
	@Transactional
	public void updateOcuLawRegInfo(@Valid OcuLawRegInfoDto dto) {
		
		
		/** A: 결재 대기, B: 완료, '': 미저장**/
		// 승인자가 있는 경우 승인상태 값 'A'
		
		// 승인자 id
		String aprvId =  dto.getAprvId();
		if(!StringUtils.isEmpty(aprvId)) {
			dto.setAprvStat("A");
			
			// 메일 전송 필요(추후)
			
		}
		
		// 부서 저장
//		if(reqDto.getList().size() != 0) {
		
//			commonSql.delete("OcuLawRegInfo.deleteOcuLawRegDept", param);
		
//			Map<String, Object> param = new HashMap<String, Object>();
//		    param.put("list", reqDto.getList());
//		    commonSql.insert("OcuLawRegInfo.insertOcuLawRegDept", param);
//		}
		
		
		commonSql.update("OcuLawRegInfo.updateOcuLawRegInfo", dto);
		
	}

	/**
	 * 법규등록대장 정보 삭제
	 */
	@Override
	public void deleteOcuLawRegInfo(String lawSeq) {
		commonSql.delete("OcuLawRegInfo.deleteOcuLawRegInfo", lawSeq);
		
	}

	/**
	 * 법규등록대장 승인
	 */
	@Override
	public void approvalLawRegInfo(String lawSeq) {
		commonSql.update("OcuLawRegInfo.approvalLawRegInfo", lawSeq);
		
		// 메일 전송 필요(추후)
		
	}


   
}
