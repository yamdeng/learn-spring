package com.koreanair.ksms.avn.sfta.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveHzdTopRiskDto;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveSearchDto;

public interface AvnSmsComprehensiveService {
    
    PageInfo<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList(SmsComprehensiveSearchDto param);
    
    PageInfo<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList(SmsComprehensiveSearchDto param);

    PageInfo<SmsComprehensiveHzdTopRiskDto> selectReportDetailList(SmsComprehensiveSearchDto param);
    
}
