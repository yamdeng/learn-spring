package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveHzdTopRiskDto;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveSearchDto;

public interface AvnSmsComprehensiveService {
    
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList1(SmsComprehensiveSearchDto param);
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList2(SmsComprehensiveSearchDto param);
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList3(SmsComprehensiveSearchDto param);
    
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList1(SmsComprehensiveSearchDto param);
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList2(SmsComprehensiveSearchDto param);
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList3(SmsComprehensiveSearchDto param);
    List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList4(SmsComprehensiveSearchDto param);

    PageInfo<SmsComprehensiveHzdTopRiskDto> selectReportDetailList(SmsComprehensiveSearchDto param);
    
}
