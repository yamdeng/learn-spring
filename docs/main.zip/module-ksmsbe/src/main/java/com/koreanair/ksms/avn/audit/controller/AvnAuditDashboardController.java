package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.service.AvnAuditDashboardService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * AUDIT - 품질심사 현황(Audit Dashboard)
 */
@Tag(name = "AvnAuditDashboard", description = "AUDIT - 품질심사 현황(Audit Dashboard) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditDashboardController {

    @Autowired
    AvnAuditDashboardService service;

    /**
     * Audit Dashboard 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit Dashboard 조회", description = "Audit Dashboard 조회 API")
    @GetMapping(value = "/audit/dashboards")
    public ResponseEntity<?> getAuditDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Data Analysis 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Data Analysis 조회", description = "Data Analysis 조회 API")
    @GetMapping(value = "/audit/data-analysis")
    public ResponseEntity<?> getDataAnalysisList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }
}
