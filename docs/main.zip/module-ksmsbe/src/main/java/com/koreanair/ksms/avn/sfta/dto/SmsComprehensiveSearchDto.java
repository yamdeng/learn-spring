package com.koreanair.ksms.avn.sfta.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;

public class SmsComprehensiveSearchDto {
    
    @Schema(description = "부문")
    private String division;
    
    @Schema(description = "보고서구분")
    private String reportType;
    
    @Schema(description = "시작일자")
    private String fromDate;
    
    @Schema(description = "종료일자")
    private String toDate;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "코드")
    private String code;
    
    
    @Builder
    public SmsComprehensiveSearchDto(
            String division,
            String reportType,
            String fromDate,
            String toDate,
            String gubun,
            String code
            ) {
        this.division = division;
        this.reportType = reportType;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.gubun = gubun;
        this.code = code;
    }
}
