package com.koreanair.ksms.avn.admin.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnSurveyManageServiceImpl extends AbstractBaseService implements AvnSurveyManageService {
}
