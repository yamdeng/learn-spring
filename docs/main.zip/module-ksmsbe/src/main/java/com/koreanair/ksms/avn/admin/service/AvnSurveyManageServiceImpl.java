package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSurveyManageServiceImpl extends AbstractBaseService implements AvnSurveyManageService {
    //  관리자 > 안전문화설문관리 조회
    @Override
    public PageInfo<TbAvnBoardDto> selectSurveyList(TbAvnBoardDto tbAvnBoardDto) {
        List<TbAvnBoardDto> resultList = commonSql.selectList("AvnSurveyManage.selectSurveyList", tbAvnBoardDto);
        return PageInfo.of(resultList);
    }

    //  관리자 > 안전문화설문관리 신규 등록
    @Override
    public void insertSurvey(TbAvnBoardDto tbAvnBoardDto) {

        //날짜 포맷 변경
        String DateFormatChange = tbAvnBoardDto.getPopupFromDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(0,8);
        tbAvnBoardDto.setPopupFromDt(DateFormatChange);

        commonSql.insert("AvnSurveyManage.insertSurvey", tbAvnBoardDto);
    }

    //  관리자 > 안전문화설문관리 상세
    @Override
    public TbAvnBoardDto selectSurveyDetail(int boardId) {
        return commonSql.selectOne("AvnSurveyManage.selectSurveyDetail", boardId);
    }

    //  관리자 > 안전문화설문관리 수정
    @Override
    public void updateSurvey(TbAvnBoardDto tbAvnBoardDto) {

        //날짜 포맷 변경
        String DateFormatChange = tbAvnBoardDto.getPopupFromDt();
        DateFormatChange = DateFormatChange.replace("-","");
        DateFormatChange = DateFormatChange.substring(0,8);
        tbAvnBoardDto.setPopupFromDt(DateFormatChange);

        commonSql.update("AvnSurveyManage.updateSurvey", tbAvnBoardDto);
    }

    //  관리자 > 안전문화설문관리 삭제
    @Override
    public void deleteSurvey(int boardId) {
        commonSql.delete("AvnSurveyManage.deleteSurvey", boardId);
    }
}
