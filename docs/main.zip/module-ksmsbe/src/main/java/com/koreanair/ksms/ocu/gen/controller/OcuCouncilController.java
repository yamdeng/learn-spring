package com.koreanair.ksms.ocu.gen.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.service.OcuCouncilService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전경영 - 안전보건협의체
 */
@Tag(name = "OcuCouncil", description = "안전경영 - 안전보건협의체 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuCouncilController {

    @Autowired
    OcuCouncilService service;

    /**
     * 안전보건협의체 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전보건협의체 목록 조회", description = "안전보건협의체 목록 조회 API")
    @GetMapping(value = "/general/councils")
    public ResponseEntity<?> getCouncilList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전보건협의체 상세정보 조회", description = "안전보건협의체 상세정보 조회 API")
    @GetMapping(value = "/general/councils/{councilId}")
    public ResponseEntity<?> getCouncilInfo(@PathVariable(value="councilId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전보건협의체 등록", description = "신규 안전보건협의체 등록 API")
    @PostMapping(value = "/general/councils")
    public ResponseEntity<?> insertCouncil(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전보건협의체 정보 수정", description = "안전보건협의체 정보 수정 API")
    @PutMapping(value = "/general/councils/{councilId}")
    public ResponseEntity<?> updateCouncil(
            @PathVariable(value="councilId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전보건협의체 삭제", description = "안전보건협의체 삭제 API")
    @DeleteMapping(value = "/general/councils/{councilId}")
    public ResponseEntity<?> deleteCouncil(@PathVariable(value="councilId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
