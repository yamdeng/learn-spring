package com.koreanair.ksms.config;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import lombok.RequiredArgsConstructor;
import org.springdoc.core.models.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@OpenAPIDefinition(
        info = @Info(title = "KSMS API",
                description = "KSMS 사이트 API 명세",
                version = "v1"))
@RequiredArgsConstructor
@Configuration
public class SwaggerConfig {

    ////////////////////////////////////////////////////////////////////////////////////////////
    // Swagger 그룹을 적용하기 위해서는 application.yml에서 paths-to-match가 설정되어 있으면 안된다!!
    ////////////////////////////////////////////////////////////////////////////////////////////

    @Bean
    public GroupedOpenApi commonApi() {
        String[] paths = {"/api/v1/com/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 공통 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi01() {
        String[] paths = {"/api/v1/avn/report/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - 안전보고서 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi02() {
        String[] paths = {"/api/v1/avn/policy/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - 안전정책 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi03() {
        String[] paths = {"/api/v1/avn/srm/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - 안전위험관리 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi04() {
        String[] paths = {"/api/v1/avn/assurance/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - 안전보증 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi05() {
        String[] paths = {"/api/v1/avn/promotion/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - 안전증진 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi06() {
        String[] paths = {"/api/v1/avn/audit/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - AUDIT API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi avnApi07() {
        String[] paths = {"/api/v1/avn/admin/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 항공안전 - ADMIN API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi01() {
        String[] paths = {"/api/v1/ocu/general/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 안전경영 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi02() {
        String[] paths = {"/api/v1/ocu/education/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 안전교육 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi03() {
        String[] paths = {"/api/v1/ocu/management/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 안전관리 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi04() {
        String[] paths = {"/api/v1/ocu/inspection/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 안전점검 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi05() {
        String[] paths = {"/api/v1/ocu/risk/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 위험성평가 API v1")
                .pathsToMatch(paths)
                .build();
    }

    @Bean
    public GroupedOpenApi ocuApi06() {
        String[] paths = {"/api/v1/ocu/accident/**/*"};

        return GroupedOpenApi.builder()
                .group("KSMS 산업안전 - 업무상재해 API v1")
                .pathsToMatch(paths)
                .build();
    }
}
