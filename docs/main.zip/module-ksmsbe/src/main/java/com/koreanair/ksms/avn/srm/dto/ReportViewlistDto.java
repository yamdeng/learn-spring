package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Date;
import java.util.List;

@Getter
@Setter
@ToString
@Schema(description = "보고서 분석 조회 조건 Param")
public class ReportViewlistDto {

    @Schema(description = "조회조건_날자구분")
    @NotNull
    private String p_dateType;

    @Schema(description = "조회조건_시작일자")
    //@NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date p_startDate;

    @Schema(description = "조회조건_종료일자")
    //@NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date p_endDate;

    private String s_startDate;
    private String s_endDate;

    @Schema(description = "조회조건_제목")
    private String p_subject;

    @Schema(description = "조회조건_작성자")
    private String p_reportedBy;

    @Schema(description = "조회조건_Fleet")
    private String p_fleet;

    @Schema(description = "조회조건_기종")
    private String p_regNo;

    @Schema(description = "조회조건_부문")
    private String p_sector;

    @Schema(description = "조회조건_업무코드")
    private String p_phase;

    @Schema(description = "조회조건_상태코드")
    private String p_stepCode;

    @Schema(description = "조회조건_my Turn")
    private String p_myTurn;

    @Schema(description = "사용자ID")
    private String p_empNo;

    @Schema(description = "사용자 권한에 맞는 보고서 리스트")
    private List<String> p_reportList;

    @Schema(description = "사용자에게 할당된 보고서 조회하기 위한 조건")
    private String p_assignEmpNo;

    @Schema(description = "경감부서코드")
    private Integer p_mitigationDeptId;


    //@Schema(description = "보고서 묶음 VO")
    //private List<String> groupReportList;



}
