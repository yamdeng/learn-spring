package com.koreanair.ksms.ocu.edu.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.edu.dto.OcuManualEduDto;
import com.koreanair.ksms.ocu.edu.dto.OcuManualEduSignDto;

public interface OcuManualEduService {

    OcuManualEduDto selectOcuManualEdu(int id);
    PageInfo<OcuManualEduDto> selectOcuManualEduList(OcuManualEduDto paramDto);

    void insertOcuManualEdu(OcuManualEduDto dto);
    void updateOcuManualEdu(OcuManualEduDto dto);
    void deleteOcuManualEdu(int id);
    void saveOcuManualEdu(List<OcuManualEduDto> dataList);
   
    
    
    OcuManualEduSignDto selectOcuManualEduSign(int id);
    PageInfo<OcuManualEduSignDto> selectOcuManualEduSignList(OcuManualEduSignDto paramDto);

    void insertOcuManualEduSign(OcuManualEduSignDto dto);
    void updateOcuManualEduSign(OcuManualEduSignDto dto);
    void deleteOcuManualEduSign(int id);
    void saveOcuManualEduSign(List<OcuManualEduSignDto> dataList);
    
}
