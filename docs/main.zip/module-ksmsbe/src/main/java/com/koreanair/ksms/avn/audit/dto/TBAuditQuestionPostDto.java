package com.koreanair.ksms.avn.audit.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.util.List;
import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "Checklist / QuestionPost")
public class TBAuditQuestionPostDto {
    private List<TBAuditQuestionDto> inserted;

    private List<TBAuditQuestionDto> updated;

    private List<Integer> deleted;

    private String empNo;

    private int checklistOriginId;

    private int chapterOriginid;

    private String checklistName;

    private boolean isRevisionUpdate;
}
