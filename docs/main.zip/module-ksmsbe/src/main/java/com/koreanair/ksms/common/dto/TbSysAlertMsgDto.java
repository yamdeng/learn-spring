package com.koreanair.ksms.common.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.sql.Timestamp;

@Getter
@Setter
@ToString
public class TbSysAlertMsgDto {

    private int alertMsgId;

    @NotBlank
    private String alertMsgText;

    private String alertMsgLink;
    private Timestamp sendDttm;
    private String sendUserId;
    private String recvUserId;
    private String recvYn;
    private Timestamp recvDttm;
}
