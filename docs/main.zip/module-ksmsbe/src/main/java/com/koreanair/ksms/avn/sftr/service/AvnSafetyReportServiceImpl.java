package com.koreanair.ksms.avn.sftr.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnSafetyReportServiceImpl extends AbstractBaseService implements AvnSafetyReportService {
}
