package com.koreanair.ksms.avn.sftr.controller;

import com.koreanair.ksms.avn.sftr.service.AvnSafetyReportService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 안전보고서 - My Report, Report List
 */
@Tag(name = "AvnSafetyReport", description = "안전보고서 - My Report, Report List API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyReportController {

    @Autowired
    AvnSafetyReportService service;

    /**
     * My Report(Other) 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Report(Other) 목록 조회", description = "My Report(Other) 목록 조회 API")
    @GetMapping(value = "/report/my-reports")
    public ResponseEntity<?> getMyReportList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Report List 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Report List 조회", description = "Report List 조회 API")
    @GetMapping(value = "/report/all-reports")
    public ResponseEntity<?> getAllReportList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }
}
