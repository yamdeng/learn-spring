package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "협력업체")
public class OcuPartnerDto extends CommonDto {
    
    @Schema(description = "협력업체_ID")
    private String prtnrId;
    
    @Schema(description = "협력업체_명")
    @NotBlank
    private String prtnrNm;
    
    @Schema(description = "사업자_번호")
    @NotBlank
    private String bizNo;
    
    @Schema(description = "대표자")
    @NotBlank
    private String rprsn;
    
    @Schema(description = "업태")
    @NotBlank
    private String bizIndst;
    
    @Schema(description = "업종")
    @NotBlank
    private String bizType;
}
