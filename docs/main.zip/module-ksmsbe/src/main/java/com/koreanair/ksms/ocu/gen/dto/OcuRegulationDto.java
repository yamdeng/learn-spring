package com.koreanair.ksms.ocu.gen.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 규정/지침/매뉴얼/양식 DTO
 */
@Getter
@Setter
@ToString
public class OcuRegulationDto {
	
	/**
	 * 순번
	 */
	private int num;
	
	/**
	 * 규정/지침/매뉴얼/양식 ID
	 */
	private int rulesFormId;
	
	/**
	 * 부문 코드
	 */
	private String sectCd;
	
	/**
	 * 부문명
	 */
	private String sectNm;
	
	/**
	 * 규정/지침/매뉴얼/양식 구분 
	 */
	private String formCls;
	
	/**
	 * 규정/지침/매뉴얼/양식 구분명 
	 */
	private String formClsNm;
	
    /**
     * 개정 번호
     */
    private int revisionNo;
    
    /**
     * 제정 일자
     */
    private String enactedDt;
    /**
     * 개정 일자
     */
    private String revisionDt;
    
    /**
     * 개정 제목
     */
    private String revisionTitle;
    
    /**
     * 주요 개정 내용
     */
    private String majorRevisionCn;
    
    /**
     * FROM 제정일자
     */
    private String fromEnactedDt;
    
    /**
     * TO 제정일자
     */
    private String toEnactedDt;

    /**
     * 첨부 파일 ID
     */
    private int fileId;
    
    /**
     * 첨부 링크 ID
     */
    private int linkId;
    
    /**
     * 등록자 사번
     */
    private String regUserId;
    
    /**
     * 등록 일시 
     */
    private String regDttm;
    
    /**
     * 수정자 사번
     */
    private String updUserId;
    
    /**
     * 수정 일시
     */
    private String updDttm;

}


