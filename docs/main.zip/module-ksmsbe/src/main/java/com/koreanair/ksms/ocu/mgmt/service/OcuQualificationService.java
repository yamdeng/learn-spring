package com.koreanair.ksms.ocu.mgmt.service;

import com.koreanair.ksms.ocu.mgmt.dto.OcuQualificationDto;
import java.util.List;

public interface OcuQualificationService {

    OcuQualificationDto selectOcuQualification(int id);
    List<OcuQualificationDto> selectOcuQualificationList(OcuQualificationDto paramDto);

    void insertOcuQualification(OcuQualificationDto dto);
    void updateOcuQualification(OcuQualificationDto dto);
    void deleteOcuQualification(int id);
    void saveOcuQualification(List<OcuQualificationDto> dataList);
    
}
