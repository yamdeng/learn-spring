package com.koreanair.ksms.avn.sfta.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

public class DashboardDto {
    
    @Schema(description = "연도")
    @NotBlank
    private String year;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "01")
    private int col01;
    
    @Schema(description = "02")
    private int col02;
    
    @Schema(description = "03")
    private int col03;
    
    @Schema(description = "04")
    private int col04;
    
    @Schema(description = "05")
    private int col05;
    
    @Schema(description = "06")
    private int col06;
    
    @Schema(description = "07")
    private int col07;
    
    @Schema(description = "08")
    private int col08;
    
    @Schema(description = "09")
    private int col09;
    
    @Schema(description = "10")
    private int col10;
    
    @Schema(description = "11")
    private int col11;
    
    @Schema(description = "12")
    private int col12;
    
    @Schema(description = "TTL")
    private int colTotal;
}
