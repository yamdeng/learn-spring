package com.koreanair.ksms.avn.admin.controller;

import com.koreanair.ksms.avn.admin.service.AvnRsrManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - RSR 관리
 */
@Tag(name = "AvnRsrManage", description = "관리자 - RSR 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnRsrManageController {

    @Autowired
    AvnRsrManageService service;

    /**
     * 보유 장비 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보유 장비 관리 목록 조회", description = "보유 장비 관리 목록 조회 API")
    @GetMapping(value = "/admin/rsr/equipments")
    public ResponseEntity<?> getGroundEquipmentList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "보유 장비 관리 상세정보 조회", description = "보유 장비 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> getGroundEquipmentInfo(@PathVariable(value="equipmentId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 보유 장비 관리 등록", description = "신규 보유 장비 관리 등록 API")
    @PostMapping(value = "/admin/rsr/equipments")
    public ResponseEntity<?> insertGroundEquipment(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보유 장비 관리 정보 수정", description = "보유 장비 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> updateGroundEquipment(
            @PathVariable(value="equipmentId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "보유 장비 관리 삭제", description = "보유 장비 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/equipments/{equipmentId}")
    public ResponseEntity<?> deleteGroundEquipment(@PathVariable(value="equipmentId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Subject 항목 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Subject 항목 관리 목록 조회", description = "Subject 항목 관리 목록 조회 API")
    @GetMapping(value = "/admin/rsr/subjects")
    public ResponseEntity<?> getSubjectContentsList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Subject 항목 관리 상세정보 조회", description = "Subject 항목 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> getSubjectContentsInfo(@PathVariable(value="rsrSubjectId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Subject 항목 관리 등록", description = "신규 Subject 항목 관리 등록 API")
    @PostMapping(value = "/admin/rsr/subjects")
    public ResponseEntity<?> insertSubjectContents(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Subject 항목 관리 정보 수정", description = "Subject 항목 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> updateSubjectContents(
            @PathVariable(value="rsrSubjectId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Subject 항목 관리 삭제", description = "Subject 항목 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/subjects/{rsrSubjectId}")
    public ResponseEntity<?> deleteSubjectContents(@PathVariable(value="rsrSubjectId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 대시보드 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "대시보드 관리 목록 조회", description = "대시보드 관리 목록 조회 API")
    @GetMapping(value = "/admin/rsr/dashboards")
    public ResponseEntity<?> getRsrDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "대시보드 관리 상세정보 조회", description = "대시보드 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> getRsrDashboardInfo(@PathVariable(value="dashboardId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 대시보드 관리 등록", description = "신규 대시보드 관리 등록 API")
    @PostMapping(value = "/admin/rsr/dashboards")
    public ResponseEntity<?> insertRsrDashboard(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "대시보드 관리 정보 수정", description = "대시보드 관리 정보 수정 API")
    @PutMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> updateRsrDashboard(
            @PathVariable(value="dashboardId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "대시보드 관리 삭제", description = "대시보드 관리 삭제 API")
    @DeleteMapping(value = "/admin/rsr/dashboards/{dashboardId}")
    public ResponseEntity<?> deleteRsrDashboard(@PathVariable(value="dashboardId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
