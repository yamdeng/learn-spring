package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_CSR")
public class TbAvnReportCsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드")
    private String reportDtlTypeCd;
    
    @Schema(description = "환자유형코드")
    private String patientTypeCd;
    
    @Schema(description = "발생시점코드")
    private String occurTimeCd;
    
    @Schema(description = "주요증상코드")
    private String mainSymptomCd;
    
    @Schema(description = "의사치료코드")
    private String doctorTreatmentCd;
    
    @Schema(description = "문서코드")
    private String documentCd;
    
    @Schema(description = "기내발생위치코드")
    private String inflightOccurLocationCd;
    
    @Schema(description = "부상부위코드")
    private String injuryPartCd;
    
    @Schema(description = "좌석벨트표시여부")
    @NotBlank
    private String seatbeltViewYn;
    
    @Schema(description = "주요원인코드")
    private String mainCauseCd;
    
    @Schema(description = "행위종류코드")
    private String actKindCd;
    
    @Schema(description = "승객클래스코드")
    private String paxClsCd;
    
    @Schema(description = "카빈발생시간")
    private String cabinOccurTime;
    
    @Schema(description = "카빈발생타임존코드")
    private String cabinOccurTimezoneCd;
    
    @Schema(description = "안전수검유형코드")
    private String safetyInspectionTypeCd;
    
    @Schema(description = "점검기관베이스코드")
    private String checkAuthorityBaseCd;
    
    @Schema(description = "점검기관코드")
    private String checkAuthorityCd;
    
    @Schema(description = "지적사항코드")
    private String findingCd;
    
    @Schema(description = "점검관명")
    private String inspectorNm;
    
    @Schema(description = "담배종류코드")
    private String cigaKindCd;
    
    @Schema(description = "증거수집여부")
    @NotBlank
    private String evidenceSeizedYn;
    
    @Schema(description = "경찰호출여부")
    @NotBlank
    private String policeCalledYn;
    
    @Schema(description = "단서코드")
    private String clueCd;
    
    @Schema(description = "연기감지기알람작동코드")
    private String smokeDetectorAlarmActivateCd;
    
    @Schema(description = "카빈로그여부")
    @NotBlank
    private String cabinLogYn;
    
    @Schema(description = "자발적하기여부")
    @NotBlank
    private String voluntaryDeplaneYn;
    
    @Schema(description = "하기원인코드")
    private String deplaneCauseCd;
    
    @Schema(description = "동승승객여부")
    @NotBlank
    private String accompaniedPaxYn;
    
    @Schema(description = "지연여부")
    @NotBlank
    private String delayedYn;
    
    @Schema(description = "정비결함종류코드")
    private String maintenanceDefectKindCd;
    
    @Schema(description = "기타보고종류코드")
    private String etcBriefingKindCd;
    
    @Schema(description = "기타보고항목코드")
    private String etcBriefingItemCd;
    
    @Schema(description = "화재연기냄새코드")
    private String fireSmokeSmellCd;
    
    @Schema(description = "기타원인코드")
    private String etcCauseCd;
    
    @Schema(description = "사용의료장비코드배열")
    private String useMedicalEquipCdarr;
    
    @Schema(description = "조치사항코드배열")
    private String carCdarr;
    
    @Schema(description = "추가조치사항코드배열")
    private String addCarCdarr;
    
    @Schema(description = "사용비상장비코드배열")
    private String useEmergencyEquipCdarr;
}
