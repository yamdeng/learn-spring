package com.koreanair.ksms.avn.srm.dto;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ManagerMemberDto {

    //private String roleCd;

    private int userId;

    private String empNo;

    private String email;

    private int deptId;

    private String deptCd;

    private List<Integer> postDeptIdList = new ArrayList<Integer>();

    private List<String> postDeptCdList = new ArrayList<String>();

    private List<String> postNameList = new ArrayList<String>();

    private List<String> mainYnList = new ArrayList<String>();

    public void setPostDeptIdList(String postDeptIdList) {
        if(StringUtils.isNotEmpty(postDeptIdList)) {
            this.postDeptIdList = Stream.of(postDeptIdList.split(",")).map(Integer::parseInt).collect(Collectors.toList());
        }
    }

    public void setPostDeptCdList(String postDeptCdList) {
        if(StringUtils.isNotEmpty(postDeptCdList)) {
            this.postDeptCdList = Stream.of(postDeptCdList.split(",")).collect(Collectors.toList());
        }
    }

    public void setPostNameList(String postNameList) {
        if(StringUtils.isNotEmpty(postNameList)) {
            this.postNameList = Stream.of(postNameList.split(",")).collect(Collectors.toList());
        }
    }

    public void setMainYnList(String mainYnList) {
        if(StringUtils.isNotEmpty(mainYnList)) {
            this.mainYnList = Stream.of(mainYnList.split(",")).collect(Collectors.toList());
        }
    }

    public boolean isManager(int deptId) {
        boolean flag = false;

        int idx = postDeptIdList.indexOf(deptId);
        if(idx > -1 && mainYnList.get(idx).equals("Y")) {
            flag = true;
        }

        return flag;
    }
    public boolean isManager() {
        return mainYnList.contains("Y");
    }


}
