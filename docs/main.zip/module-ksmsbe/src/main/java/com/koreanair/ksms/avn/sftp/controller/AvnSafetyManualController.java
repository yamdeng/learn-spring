package com.koreanair.ksms.avn.sftp.controller;

import com.koreanair.ksms.avn.sftp.service.AvnSafetyManualService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전정책 - 안전 Manual
 */
@Tag(name = "AvnSafetyManual", description = "안전정책 - 안전 Manual API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyManualController {

    @Autowired
    AvnSafetyManualService service;

    /**
     * 안전Manual 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전Manual 목록 조회", description = "안전Manual 목록 조회 API")
    @GetMapping(value = "/policy/manuals")
    public ResponseEntity<?> getManualList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전Manual 상세정보 조회", description = "안전Manual 상세정보 조회 API")
    @GetMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> getManualInfo(@PathVariable(value="manualId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전Manual 등록", description = "신규 안전Manual 등록 API")
    @PostMapping(value = "/policy/manuals")
    public ResponseEntity<?> insertManual(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전Manual 정보 수정", description = "안전Manual 정보 수정 API")
    @PutMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> updateManual(
            @PathVariable(value="manualId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전Manual 삭제", description = "안전Manual 삭제 API")
    @DeleteMapping(value = "/policy/manuals/{manualId}")
    public ResponseEntity<?> deleteManual(@PathVariable(value="manualId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
