package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.RiskAssessmentVo;
import com.koreanair.ksms.avn.srm.dto.SmReportHazardVo;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AvnReportRiskAssessmentServiceImpl extends AbstractBaseService implements AvnReportRiskAssessmentService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    //@Override
    public RiskAssessmentVo selectReportRiskAssessment(ReportInfoDto reportDetailDto) {
        reportDetailDto.setP_isView(true);

        RiskAssessmentVo resultInfo = commonSql.selectOne("AvnReportRiskAssessment.selectRiskAssessmentReport", reportDetailDto);
        if(resultInfo==null) {
            throw new NullPointerException();
        }

        @SuppressWarnings("unchecked")
        List<SmReportHazardVo> reportHazardList = commonSql.selectList("AvnReportRiskAssessment.getReportHazard", reportDetailDto);
        resultInfo.setReportHazardList(reportHazardList);
        String reportType=resultInfo.getReportType();
        //resultInfo.setLinkUrl(PortalAppIdStore.getDataByName(reportType).getAppUrl());

        // 회의록 가림 처리
        hideAssessment(resultInfo);

        int id = resultInfo.getId();
        List<Integer> hazardIds = commonSql.selectList("AvnReportRiskAssessment.getReportHazrdId", id);
        if( hazardIds != null ) {
            for(Integer hazardId : hazardIds) {
                //todo khw 수정 필요
                //List<PoFileVo> attachment = getFirstRiskAssessmentAttachment(hazardId);
                //resultInfo.setAttachment(attachment);
            }
        };
        return resultInfo;
    }

    /**
     *  report가 hazard: non-confidential인 경우 해당 권한을 가진 자만 회의록 확인 가능
     *
     *  System Admin
     *  작성자 본인
     *  담당그룹
     * 	경감조치 수행팀
     *  LSC 멤버
     *  SSC멤버
     */
    private void hideAssessment(RiskAssessmentVo detail) {
        try {
            String reportType = detail.getReportType();
            if (reportType.equals("hzr")) {

                int reportId = detail.getId();
                String isConfidential = commonSql.selectOne("AvnReportRiskAssessment.selectConfidential", reportId);

                if (isConfidential.equals("Y")) {
                    return;
                }

                // 회의록을 볼 수 있는 사람의 목록을 가져오기
                // account_ids: user id 목록
                // emp_noㅣ 작성자의 사번

                Map<String, Object> parameter = new HashMap<>();
                parameter.put("reportId", reportId);
                //todo khw 수정 필요
                //parameter.put("empNo", sessionInfo.getString("EMP_NO"));
                //parameter.put("accountIds", sessionInfo.getJsonArray("ACCOUNT_IDS").getList());

                int result = commonSql.selectOne("AvnReportRiskAssessment.selectAssessmentNoteAuth", parameter);
                logger.debug("result: {}", result);

                if (result <= 0) {
                    detail.setAssessmentNotes(null);
                    detail.setVisibleNote(false);
                }
            }
        } catch (Exception exception) {
            logger.error("cause: {}", exception.getCause());
        }
    }


}
