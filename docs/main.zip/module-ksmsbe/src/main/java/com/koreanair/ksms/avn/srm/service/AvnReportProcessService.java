package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.constants.AvnStatusCode.ReportStatus;
import com.koreanair.ksms.common.dto.TbAvnSmGroupList;

import java.util.List;

public interface AvnReportProcessService {

    //그룹묶기 유효성 체크
    boolean getIsValidateGroupReport(Integer groupId);

    //그룹묶기 처리
    void insertMergeGroupReport(List<Integer> groupReportList);

    //보고서 대표 보고서 수정
    void updateIsMainReport(TbAvnSmGroupList tbAvnSmGroupList);


    boolean smsReportProcess(ReportProcessVo processVo) throws Exception;

    void processAction(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception;

    void updateReportStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception;

    void updateHazardStatus(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception;

    void insertReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception;

    void deleteReportRole(ReportProcessVo processVo, String reportType, ReportStatus stat) throws Exception;

    ReportProcessDto selectReportStatus(int id) throws Exception;

    HazardProcessDto selectHazardStatus(int id) throws Exception;

    MitigationMemberDto selectMitigationMember(int hazardId) throws Exception;

    boolean insertLscMember(ReportRoleAccountDto param) throws Exception;

    boolean validateDeleteMitigationRole(RejectMitigationDto param)  throws Exception;
}
