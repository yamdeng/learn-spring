package com.koreanair.ksms.ocu.mgmt.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class OcuMuscleServiceImpl extends AbstractBaseService implements OcuMuscleService {
}
