package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_RSR")
public class TbAvnReportRsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드")
    @NotBlank
    private String reportDtlTypeCd;
    
    @Schema(description = "RSR유형코드")
    private String rsrTypeCd;
    
    @Schema(description = "STN코드")
    private String stnCd;
    
    @Schema(description = "장소코드배열")
    private String placeCdarr;
    
    @Schema(description = "장소명")
    private String placeNm;
    
    @Schema(description = "날씨코드배열")
    private String weatherCdarr;
    
    @Schema(description = "작업단계코드")
    private String workPhaseCd;
    
    @Schema(description = "주요클래스코드")
    private String mainClsCd;
    
    @Schema(description = "발급자코드")
    private String issuerCd;
    
    @Schema(description = "인과요인코드배열")
    private String casualFactorCdarr;
    
    @Schema(description = "발생유형코드배열")
    private String occurTypeCdarr;
    
    @Schema(description = "GSE코드")
    private String gseCd;
    
    @Schema(description = "GSE등록번호명")
    private String gseRegNoNm;
    
    @Schema(description = "항공기코드")
    private String aircraftCd;
    
    @Schema(description = "회사코드")
    private String companyCd;
    
    @Schema(description = "관련부서코드")
    private String relDeptCd;
    
    @Schema(description = "팀부서코드")
    private String teamDeptCd;
    
    @Schema(description = "GRP코드")
    private String grpCd;
    
    @Schema(description = "관련자명")
    private String involveNm;
    
    @Schema(description = "처벌유형코드")
    private String penaltyTypeCd;
    
    @Schema(description = "P코드")
    private String pCd;
    
    @Schema(description = "처벌점수")
    private Double penaltyScore;
    
    @Schema(description = "접수일시")
    private Timestamp receivedDttm;
    
    @Schema(description = "종료일시")
    private Timestamp closedDttm;
    
    @Schema(description = "발급일시")
    private Timestamp issueDttm;
    
    @Schema(description = "마감일시")
    private Timestamp dueDttm;
}
