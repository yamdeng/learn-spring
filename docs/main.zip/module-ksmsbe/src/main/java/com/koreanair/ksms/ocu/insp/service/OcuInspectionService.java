package com.koreanair.ksms.ocu.insp.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.insp.dto.*;

import java.util.List;


public interface OcuInspectionService {

    OcuChecklistDto selectOcuChecklist(int id);
    PageInfo<OcuChecklistDto> selectOcuChecklistList(OcuChecklistDto paramDto);

    void insertOcuChecklist(OcuChecklistDto dto);
    void updateOcuChecklist(OcuChecklistDto dto);
    void deleteOcuChecklist(int id);
    void saveOcuChecklist(List<OcuChecklistDto> dataList);
    
    OcuChecklistItemDto selectOcuChecklistItem(int id);
    PageInfo<OcuChecklistItemDto> selectOcuChecklistItemList(OcuChecklistItemDto paramDto);

    void insertOcuChecklistItem(OcuChecklistItemDto dto);
    void updateOcuChecklistItem(OcuChecklistItemDto dto);
    void deleteOcuChecklistItem(int id);
    void saveOcuChecklistItem(List<OcuChecklistItemDto> dataList);
    
    OcuChecklistPlaceDto selectOcuChecklistPlace(int id);
    PageInfo<OcuChecklistPlaceDto> selectOcuChecklistPlaceList(OcuChecklistPlaceDto paramDto);

    void insertOcuChecklistPlace(OcuChecklistPlaceDto dto);
    void updateOcuChecklistPlace(OcuChecklistPlaceDto dto);
    void deleteOcuChecklistPlace(int id);
    void saveOcuChecklistPlace(List<OcuChecklistPlaceDto> dataList);

    OcuPeriodicDto selectOcuPeriodic(int id);
    PageInfo<OcuPeriodicDto> selectOcuPeriodicList(OcuPeriodicDto paramDto);

    void insertOcuPeriodic(OcuPeriodicDto dto);
    void updateOcuPeriodic(OcuPeriodicDto dto);
    void deleteOcuPeriodic(int id);
    void saveOcuPeriodic(List<OcuPeriodicDto> dataList);

    OcuPeriodicContDto selectOcuPeriodicCont(int id);
    PageInfo<OcuPeriodicContDto> selectOcuPeriodicContList(OcuPeriodicContDto paramDto);

    void insertOcuPeriodicCont(OcuPeriodicContDto dto);
    void updateOcuPeriodicCont(OcuPeriodicContDto dto);
    void deleteOcuPeriodicCont(int id);
    void saveOcuPeriodicCont(List<OcuPeriodicContDto> dataList);

    OcuWalkaroundDto selectOcuWalkaround(int id);
    PageInfo<OcuWalkaroundDto> selectOcuWalkaroundList(OcuWalkaroundDto paramDto);

    void insertOcuWalkaround(OcuWalkaroundDto dto);
    void updateOcuWalkaround(OcuWalkaroundDto dto);
    void deleteOcuWalkaround(int id);
    void saveOcuWalkaround(List<OcuWalkaroundDto> dataList);

    OcuWalkaroundCheckDto selectOcuWalkaroundCheck(int id);
    PageInfo<OcuWalkaroundCheckDto> selectOcuWalkaroundCheckList(OcuWalkaroundCheckDto paramDto);

    void insertOcuWalkaroundCheck(OcuWalkaroundCheckDto dto);
    void updateOcuWalkaroundCheck(OcuWalkaroundCheckDto dto);
    void deleteOcuWalkaroundCheck(int id);
    void saveOcuWalkaroundCheck(List<OcuWalkaroundCheckDto> dataList);

    OcuWalkaroundContDto selectOcuWalkaroundCont(int id);
    PageInfo<OcuWalkaroundContDto> selectOcuWalkaroundContList(OcuWalkaroundContDto paramDto);

    void insertOcuWalkaroundCont(OcuWalkaroundContDto dto);
    void updateOcuWalkaroundCont(OcuWalkaroundContDto dto);
    void deleteOcuWalkaroundCont(int id);
    void saveOcuWalkaroundCont(List<OcuWalkaroundContDto> dataList);

    PageInfo<OcuCorrectionDto> selectOcuCorrectionList(OcuCorrectionDto paramDto);


}
