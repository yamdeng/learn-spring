package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서 - 그룹내역")
public class TbAvnSmGroupList extends CommonDto {

    @Schema(description = "tb_avn_sm_group id")
    @NotBlank
    private Integer groupId;

    @Schema(description = "tb_avn_sm_report id")
    @NotBlank
    private Integer reportId;

    @Schema(description = "대표 보고서 여부(Y일 때 대표보고서)")
    private String isMainReport;

    @Schema(description = "old group id")
    private Integer oldGroupId;
}
