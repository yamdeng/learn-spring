package com.koreanair.ksms.ocu.gen.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuCommitteeDto;
import com.koreanair.ksms.ocu.gen.dto.OcuHsCommitteeDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 안전보건협의체 ServiceImpl
 */
@Service
@Slf4j
public class OcuHsCommitteeServiceImpl extends AbstractBaseService implements OcuHsCommitteeService {

	/**
	 *  안전보건협의체 목록 조회
	 */
	@Override
	public PageInfo<OcuHsCommitteeDto> selectHsCommitteeList(OcuHsCommitteeDto dto) {
		
		String activeTab = dto.getActiveTab();
		
		List<OcuHsCommitteeDto> resultList;
	
		// 현황 조회 (A)
		if(!StringUtils.equals(activeTab, "B")) {
			resultList = commonSql.selectList("OcuHsCommittee.selectHsCommitteeStaList", dto);
		// 목록 조회 (B)
		}else {
			resultList = commonSql.selectList("OcuHsCommittee.selectHsCommitteeivtList", dto);
		}
	    return PageInfo.of(resultList);
	}

	/**
	 * 안전보건협의체 상세정보 조회
	 */
	@Override
	public OcuHsCommitteeDto getHsCommitteeInfo(int advCmitId) {
		return commonSql.selectOne("OcuHsCommittee.getHsCommitteeInfo", advCmitId);
	}

	/**
	 * 신규 안전보건협의체 등록
	 */
	@Override
	public void insertHsCommittee(@Valid OcuHsCommitteeDto dto) {
		commonSql.insert("OcuHsCommittee.insertHsCommittee", dto);
		
	}

	/**
	 * 안전보건협의체 정보 수정
	 */
	@Override
	public void updateHsCommittee(@Valid OcuHsCommitteeDto dto) {
		commonSql.update("OcuHsCommittee.updateHsCommittee", dto);
		
	}

	/**
	 * 안전보건협의체 삭제
	 */
	@Override
	public void deleteHsCommittee(int advCmitId) {
		commonSql.delete("OcuHsCommittee.deleteHsCommittee", advCmitId);
		
	}
}
