package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "작업장순회점검")
public class OcuWalkaroundDto extends CommonDto {
    
    @Schema(description = "점검_ID")
    @NotBlank
    private String chkId;
    
    @Schema(description = "점검표_ID")
    @NotBlank
    private String chkListId;
    
    @Schema(description = "점검표_구분_코드")
    @NotBlank
    private String chkListClsCd;
    
    @Schema(description = "점검_제목")
    @NotBlank
    private String chkTitle;
    
    @Schema(description = "점검_등록_시작일자")
    @NotBlank
    private String chkRegStartDt;
    
    @Schema(description = "점검_등록_종료일자")
    @NotBlank
    private String chkRegEndDt;
}
