package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "보고서 접수 - 보고서묶음리스트")
public class ReceiptGroupListVo {

    @Schema(description = "ID")
    private Integer id;

    @Schema(description = "Report ID")
    private Integer reportId;

    @Schema(description = "리포트 유형, code_group=Report Type")
    private String reportType;

    @Schema(description = "대표 보고서 여부(Y일 때 대표보고서)")
    private String isMainReport;

    @Schema(description = "보고서 번호")
    private String docNo;

    @Schema(description = "사원번호")
    private String empNo;

    @Schema(description = "제출여부")
    private String isSubmitted;

    @Schema(description = "제출일자")
    private String submittedAt;

    @Schema(description = "작성자 사원명(한글)")
    private String reportedByUserNameKo;

    @Schema(description = "작성자 사원명(영문)")
    private String reportedByUserNameEn;

    @Schema(description = "비행기 번호")
    private String flightNo;

    @Schema(description = "비행기 등록 번호")
    private String registrationNo;

    @Schema(description = "도착일자")
    private Timestamp departureAt;

}
