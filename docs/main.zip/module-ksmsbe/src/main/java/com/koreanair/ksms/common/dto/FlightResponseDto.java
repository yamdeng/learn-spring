package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class FlightResponseDto {

	private String flightNo;
	
	private String aircraftType;
	
	private String ata;
	
	private String atd;
	
	private String checkIn;
	
	private String fleetCode;
	
	private String from;
	
	private String registrationNo;
	
	private String sta;
	
	private String std;
	
	private String supply;
	
	private String to;
	
	private String delay;
	
	private Timestamp departureLocAt;
	
	private String stdLocTime;
	
	private String staLocTime;
	
	private String atdLocTime;
	
	private String ataLocTime;
	
}
