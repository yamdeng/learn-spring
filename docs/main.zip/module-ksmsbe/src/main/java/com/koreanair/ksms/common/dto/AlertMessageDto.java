package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "알림메시지")
public class AlertMessageDto {

    private int key;
    private String text;
    private String url;
}
