package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서 별 Event Type")
public class TbAvnEventDto extends CommonDto {
    
    @Schema(description = "이벤트 ID")
   // @NotBlank
    private Long eventId;
    
    @Schema(description = "Report Type, code_group = 'Report Type'")
    @NotBlank
    private String reportType;
    
    @Schema(description = "이벤트명")
    @NotBlank
    private String eventName;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
    
    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    private String viewOrder;
    
    @Schema(description = "이전 이벤트 ID")
    private String eventOldId;
    
    @Schema(description = "메모")
    private String notes;
}
