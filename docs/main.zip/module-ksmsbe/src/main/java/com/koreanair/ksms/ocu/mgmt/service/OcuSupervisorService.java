package com.koreanair.ksms.ocu.mgmt.service;

public interface OcuSupervisorService {
}
