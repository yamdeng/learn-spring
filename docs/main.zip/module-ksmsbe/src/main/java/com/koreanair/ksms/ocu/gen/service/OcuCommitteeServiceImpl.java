package com.koreanair.ksms.ocu.gen.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class OcuCommitteeServiceImpl extends AbstractBaseService implements OcuCommitteeService {
}
