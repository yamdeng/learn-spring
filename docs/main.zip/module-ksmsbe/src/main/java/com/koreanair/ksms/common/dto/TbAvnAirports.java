package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnAirports {

    @Schema(description = "항공ID")
    private String airportId;

    @Schema(description = "항공Code")
    private String airportCode;

    @Schema(description = "항공명(KOR)")
    private String nameKo;

    @Schema(description = "항공명(ENG)")
    private String nameEn;

    @Schema(description = "순번")
    private int viewOrder;

    @Schema(description = "상태")
    private String state;

    @Schema(description = "순위")
    private int ranking;

    @Schema(description = "지역")
    private String area;

    @Schema(description = "라벨")
    private String label;
}
