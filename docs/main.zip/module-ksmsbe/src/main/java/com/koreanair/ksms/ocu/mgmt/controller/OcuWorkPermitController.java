package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuWorkPermitService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전관리 - 외주작업허가
 */
@Tag(name = "OcuWorkPermit", description = "안전관리 - 외주작업허가 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuWorkPermitController {

    @Autowired
    OcuWorkPermitService service;

    /**
     * 외주작업허가 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "외주작업허가 목록 조회", description = "외주작업허가 목록 조회 API")
    @GetMapping(value = "/management/permits")
    public ResponseEntity<?> getPermitList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "외주작업허가 상세정보 조회", description = "외주작업허가 상세정보 조회 API")
    @GetMapping(value = "/management/permits/{permitId}")
    public ResponseEntity<?> getPermitInfo(@PathVariable(value="permitId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 외주작업허가 등록", description = "신규 외주작업허가 등록 API")
    @PostMapping(value = "/management/permits")
    public ResponseEntity<?> insertPermit(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "외주작업허가 정보 수정", description = "외주작업허가 정보 수정 API")
    @PutMapping(value = "/management/permits/{permitId}")
    public ResponseEntity<?> updatePermit(
            @PathVariable(value="permitId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "외주작업허가 삭제", description = "외주작업허가 삭제 API")
    @DeleteMapping(value = "/management/permits/{permitId}")
    public ResponseEntity<?> deletePermit(@PathVariable(value="permitId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 외주작업허가 승인요청/처리
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "외주작업허가 승인요청/처리", description = "외주작업허가 승인요청/처리 API")
    @PostMapping(value = "/management/permits/approval/{permitId}")
    public ResponseEntity<?> approvalPermit(
            @PathVariable(value="permitId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }
}
