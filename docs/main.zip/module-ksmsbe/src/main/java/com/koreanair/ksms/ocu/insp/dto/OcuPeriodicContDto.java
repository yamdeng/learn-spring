package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "점검_내용")
public class OcuPeriodicContDto extends CommonDto {
    
    @Schema(description = "점검결과_ID")
    @NotBlank
    private String chkResultId;
    
    @Schema(description = "점검_ID")
    @NotBlank
    private String chkId;
    
    @Schema(description = "점검_항목_명")
    @NotBlank
    private String chkItemNm;
    
    @Schema(description = "점검_대분류_코드")
    @NotBlank
    private String chkLclsCd;
    
    @Schema(description = "점검_소분류_코드")
    @NotBlank
    private String chkScls;
    
    @Schema(description = "점검_내용")
    @NotBlank
    private String chkContent;
    
    @Schema(description = "점검_관계법령")
    private String chkRelLaw;
    
    @Schema(description = "점검_첨부_사진_ID1")
    private String chkPohtoId1;
    
    @Schema(description = "점검_첨부_사진_ID2")
    private String chkPohtoId2;
    
    @Schema(description = "점검_첨부_파일")
    private String chkFile;
    
    @Schema(description = "즉시_조치_여부")
    private String rightActionYn;
    
    @Schema(description = "조치_상태_코드")
    private String actionStatusCd;
    
    @Schema(description = "조치_내용")
    private String actionContent;
    
    @Schema(description = "조치_첨부_사진_ID")
    private String actionAttPhotoId;
    
    @Schema(description = "조치_첨부_파일_ID")
    private String actionAttFileId;
    
    @Schema(description = "조치_일자")
    private String actionDt;
    
    @Schema(description = "조치_부서_코드")
    private String actionDeptCd;
    
    @Schema(description = "조치자_사번")
    private String actionEmpno;
    
    @Schema(description = "승인_일자")
    private String aprvDt;
    
    @Schema(description = "승인_부서_코드")
    private String aprvDeptCd;
    
    @Schema(description = "승인자_사번")
    private String aprvEmpno;
}
