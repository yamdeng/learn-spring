package com.koreanair.ksms.common.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysMessageDto extends CommonDto {

    @NotBlank
    @Size(max=200)
    @Pattern(regexp="^[A-Za-z0-9\\-\\.]+$") // 영문 대소문자, 숫자, "-", "." 문자만 허용
    private String msgKey;

    private String msgKor;
    private String msgEng;
    private String msgChn;
    private String msgJpn;
    private String msgEtc;
}
