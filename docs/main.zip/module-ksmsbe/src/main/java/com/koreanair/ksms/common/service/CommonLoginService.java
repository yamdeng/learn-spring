package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.CustomUserInfoDto;
import com.koreanair.ksms.common.dto.LoginRequestDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Map;

public interface CommonLoginService {

    public Map<String, Object> login(LoginRequestDto dto);

    CustomUserInfoDto loadUserByUserId(String string);
}
