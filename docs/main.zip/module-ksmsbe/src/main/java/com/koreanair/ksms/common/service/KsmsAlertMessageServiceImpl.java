package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.TbSysAlertMsgDto;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class KsmsAlertMessageServiceImpl extends AbstractBaseService implements KsmsAlertMessageService {

    /**
     * 알림 메시지 발송: 수신자 한명에게 발송
     *
     * @param userId 수신자 ID
     * @param alertMsgText 메시지 내용
     * @param alertMsgLink 메시지 링크
     */
    @Override
    public void sendAlertMessageUser(String userId, String alertMsgText, String alertMsgLink) {

        String sessionUserId = SecurityContextHolder.getContext().getAuthentication().getName();

        TbSysAlertMsgDto dto = new TbSysAlertMsgDto();
        dto.setAlertMsgText(alertMsgText);
        dto.setAlertMsgLink(alertMsgLink);
        dto.setSendUserId(sessionUserId);
        dto.setRecvUserId(userId);

        commonSql.insert("KsmsAlertMessage.sendAlertMessageUser", dto);
    }

    /**
     * 알림 메시지 발송: 부서의 모든 인원에게 발송
     *
     * @param deptCd 부서코드
     * @param alertMsgText 메시지 내용
     * @param alertMsgLink 메시지 링크
     */
    @Override
    public void sendAlertMessageDept(String deptCd, String alertMsgText, String alertMsgLink) {

        String sessionUserId = SecurityContextHolder.getContext().getAuthentication().getName();

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("deptCd", deptCd);
        param.put("alertMsgText", alertMsgText);
        param.put("alertMsgLink", alertMsgLink);
        param.put("sendUserId", sessionUserId);

        commonSql.insert("KsmsAlertMessage.sendAlertMessageDept", param);
    }

    /**
     * 알림 메시지 발송: 권한그룹의 모든 인원에게 발송
     *
     * @param groupId 그룹ID
     * @param alertMsgText 메시지 내용
     * @param alertMsgLink 메시지 링크
     */
    @Override
    public void sendAlertMessageGroup(int groupId, String alertMsgText, String alertMsgLink) {

        String sessionUserId = SecurityContextHolder.getContext().getAuthentication().getName();

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("alertMsgText", alertMsgText);
        param.put("alertMsgLink", alertMsgLink);
        param.put("sendUserId", sessionUserId);

        commonSql.insert("KsmsAlertMessage.sendAlertMessageGroup", param);
    }
}
