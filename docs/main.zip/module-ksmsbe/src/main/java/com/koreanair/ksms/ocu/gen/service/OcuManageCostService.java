package com.koreanair.ksms.ocu.gen.service;

public interface OcuManageCostService {
}
