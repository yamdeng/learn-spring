package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "작업장순회점검 대상")
public class OcuWalkaroundCheckDto extends CommonDto {
    
    @Schema(description = "사업장_ID")
    @NotBlank
    private String bizPlaceId;
    
    @Schema(description = "협력업체_ID")
    @NotBlank
    private String prtnrId;
    
    @Schema(description = "점검_ID")
    @NotBlank
    private String chkId;
    
    @Schema(description = "점검_일자")
    private String chkDt;
    
    @Schema(description = "점검자_사번")
    private String chkEmpno;
    
    @Schema(description = "비고")
    private String remark;
}
