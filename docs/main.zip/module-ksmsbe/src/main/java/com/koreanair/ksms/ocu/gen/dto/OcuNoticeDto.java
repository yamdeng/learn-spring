package com.koreanair.ksms.ocu.gen.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

/**
 * 공지사항 DTO
 */
@Getter
@Setter
@ToString
public class OcuNoticeDto {
	
	/**
	 * 순번
	 */
	private int num;
	
	/**
	 * 공지사항 ID 
	 */
	private int noticeId;
	
	/**
	 * 공지사항 제목 
	 */
	private String noticeTitle;
	
    /**
     * 공지사항 내용
     */
    private String noticeContent;
    
    /**
     * 공지사항 구분
     */
    private String noticeCls;
    
    /**
     * 공지사항 구분명
     */
    private String noticeClsNm;
    
    /**
     * 상위 표출 여부
     */
    private String upViewYn;
     
    /**
     * 상위 표출 여부명
     */
    private String upViewYnNm;
        
    /**
     * 부문 코드
     */
    private String sectCd;
    
    /**
     * 부문명
     */
    private String sectNm;
    
    /**
     * 첨부 파일 ID
     */
    private int fileId;
    
    /**
     * 검색 구분 값 
     */
    private String selectType;
    
    /**
     * FROM 등록일자
     */
    private String fromRegDttm;
    
    /**
     * TO 등록일자
     */
    private String toRegDttm;
    
    /**
     * 등록자 사번
     */
    private String regUserId;
    
    /**
     * 등록 일시 
     */
    private String regDttm;
    
    /**
     * 수정자 사번
     */
    private String updUserId;
    
    /**
     * 수정 일시
     */
    private String updDttm;
    
    
    
    private String noticeType;
    private String noticeYn;
    private String sector;
    private String comFileId;
    
    
    
    
}


