package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerPlaceDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuPartnerService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartner2ndInfoDto;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerDto;

import java.util.List;

@Tag(name = "협력업체", description = "협력업체 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuPartnerController {

    @Autowired
    private OcuPartnerService ocuPartnerService;

    @Operation(summary = "협력업체 상세 조회", description = "협력업체 상세 조회 API")
    @GetMapping("/management/partner/{id}")
    public ResponseEntity<?> selectOcuPartner(@PathVariable(value="id", required=true) int id) {
        
        OcuPartnerDto result = ocuPartnerService.selectOcuPartner(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "협력업체 목록 조회", description = "협력업체 목록 조회 API")
    @GetMapping("/management/partner")
    public ResponseEntity<?> selectOcuPartnerList(
        @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
        ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){
  
        OcuPartnerDto paramDto = new OcuPartnerDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuPartnerDto> pageList = ocuPartnerService.selectOcuPartnerList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "협력업체 일괄 저장", description = "협력업체 일괄 저장 API")
    @PostMapping("/management/partner/bulk")
    public ResponseEntity<?> saveOcuPartner(@RequestBody List<OcuPartnerDto> reqDtoList) {

        ocuPartnerService.saveOcuPartner(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 등록", description = "협력업체 등록 API")
    @PostMapping(value = "/management/partner")
    public ResponseEntity<?> insertOcuPartner(@Valid @RequestBody(required=true) OcuPartnerDto reqDto){
        log.debug("테스트1");
        try {
            ocuPartnerService.insertOcuPartner(reqDto);
        }catch(Exception e) {
            e.printStackTrace();
        }
        log.debug("테스트2");
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 수정", description = "협력업체 수정 API")
    @PutMapping(value = "/management/partner")
    public ResponseEntity<?> updateOcuPartner(@Valid @RequestBody(required=true) OcuPartnerDto reqDto){
        
        ocuPartnerService.updateOcuPartner(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 삭제", description = "협력업체 삭제 API")
    @DeleteMapping(value = "/management/partner/{id}")
    public ResponseEntity<?> deleteOcuPartner(@PathVariable(value="id", required=true) int id){
        ocuPartnerService.deleteOcuPartner(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 사업장 상세 조회", description = "협력업체 사업장 상세 조회 API")
    @GetMapping("/management/partner/palce/{id}")
    public ResponseEntity<?> selectOcuPartnerPlace(@PathVariable(value="id", required=true) int id) {

        OcuPartnerPlaceDto result = ocuPartnerService.selectOcuPartnerPlace(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "협력업체 사업장 목록 조회", description = "협력업체 사업장 목록 조회 API")
    @GetMapping("/management/partner/palce")
    public ResponseEntity<?> selectOcuPartnerPlace(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuPartnerPlaceDto paramDto = new OcuPartnerPlaceDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuPartnerPlaceDto> pageList = ocuPartnerService.selectOcuPartnerPlaceList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "협력업체 사업장 일괄 저장", description = "협력업체 사업장 일괄 저장 API")
    @PostMapping("/management/partner/palce/bulk")
    public ResponseEntity<?> saveOcuPartnerPlace(@RequestBody List<OcuPartnerPlaceDto> reqDtoList) {

        ocuPartnerService.saveOcuPartnerPlace(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 사업장 등록", description = "협력업체 사업장 등록 API")
    @PostMapping(value = "/management/partner/palce")
    public ResponseEntity<?> insertOcuPartnerPlace(@Valid @RequestBody(required=true) OcuPartnerPlaceDto reqDto){

        ocuPartnerService.insertOcuPartnerPlace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 사업장 수정", description = "협력업체 사업장 수정 API")
    @PutMapping(value = "/management/partner/palce")
    public ResponseEntity<?> updateOcuPartnerPlace(@Valid @RequestBody(required=true) OcuPartnerPlaceDto reqDto){

        ocuPartnerService.updateOcuPartnerPlace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "협력업체 사업장 삭제", description = "협력업체 사업장 삭제 API")
    @DeleteMapping(value = "/management/partner/palce/{id}")
    public ResponseEntity<?> deleteOcuPartnerPlace(@PathVariable(value="id", required=true) int id){
        ocuPartnerService.deleteOcuPartnerPlace(id);
        return ResponseUtil.createSuccessResponse();
    }
    
    
    @Operation(summary = "2차 협력업체 상세 조회", description = "2차 협력업체 상세 조회 API")
    @GetMapping("/management/partner/2ndinfo/{id}")
    public ResponseEntity<?> selectOcuPartner2ndInfo(@PathVariable(value="id", required=true) int id) {
        
        OcuPartner2ndInfoDto result = ocuPartnerService.selectOcuPartner2ndInfo(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "2차 협력업체 목록 조회", description = "2차 협력업체 목록 조회 API")
    @GetMapping("/management/partner/2ndinfo")
    public ResponseEntity<?> selectOcuPartner2ndInfoeptList(
        @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
        ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){
  
        OcuPartner2ndInfoDto paramDto = new OcuPartner2ndInfoDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuPartner2ndInfoDto> pageList = ocuPartnerService.selectOcuPartner2ndInfoList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "2차 협력업체 일괄 저장", description = "2차 협력업체 일괄 저장 API")
    @PostMapping("/management/partner/2ndinfo/bulk")
    public ResponseEntity<?> saveOcuPartner2ndInfo(@RequestBody List<OcuPartner2ndInfoDto> reqDtoList) {

        ocuPartnerService.saveOcuPartner2ndInfo(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "2차 협력업체 등록", description = "2차 협력업체 등록 API")
    @PostMapping(value = "/management/partner/2ndinfo")
    public ResponseEntity<?> insertOcuPartner2ndInfo(@Valid @RequestBody(required=true) OcuPartner2ndInfoDto reqDto){

        ocuPartnerService.insertOcuPartner2ndInfo(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "2차 협력업체 수정", description = "2차 협력업체 수정 API")
    @PutMapping(value = "/management/partner/2ndinfo")
    public ResponseEntity<?> updateOcuPartner2ndInfo(@Valid @RequestBody(required=true) OcuPartner2ndInfoDto reqDto){
        
        ocuPartnerService.updateOcuPartner2ndInfo(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "2차 협력업체 삭제", description = "2차 협력업체 삭제 API")
    @DeleteMapping(value = "/management/partner/2ndinfo/{id}")
    public ResponseEntity<?> deleteOcuPartner2ndInfo(@PathVariable(value="id", required=true) int id){
        ocuPartnerService.deleteOcuPartner2ndInfo(id);
        return ResponseUtil.createSuccessResponse();
    }



}


