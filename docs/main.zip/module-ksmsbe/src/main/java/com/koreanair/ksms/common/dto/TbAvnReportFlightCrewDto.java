package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트비행승무원")
public class TbAvnReportFlightCrewDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "사원번호")
    @NotBlank
    private String empNo;
    
    @Schema(description = "승무원유형코드")
    @NotBlank
    private String crewTypeCd;
}
