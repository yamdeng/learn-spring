package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.vo.*;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class AvnAuditChecklistServiceImpl extends AbstractBaseService implements AvnAuditChecklistService {

    // Checklist 목록 조회 (with Chapter)
    @Override
    public List<TBAuditChecklistChapterDto> selectAuditChecklist(TBAuditChecklistDto searchDto) {

        List<TBAuditChecklistChapterDto> checklistDto = commonSql.selectList("AvnAuditChecklist.selectAuditChecklist", searchDto);
        // View 화면에서 조회하는 경우
        if(searchDto.getOrigId() > 0) {
            List<ChecklistRevisionsVo> revisions = commonSql.selectList("AvnAuditChecklist.selectAuditChecklistRevision", searchDto.getOrigId());
            checklistDto.get(0).setRevisions(revisions);
        }
        return checklistDto;
    }

    // Question 목록 조회
    @Override
    public List<TBAuditQuestionDto> selectAuditQuestionList(TBAuditQuestionDto searchDto) {
        return commonSql.selectList("AvnAuditChecklist.selectQuestionsByChapterOrigId", searchDto);
    }

    // Checklist 등록
    @Override
    public Integer insertAuditChecklist(TBAuditChecklistDto tbAuditChecklistDto){
        tbAuditChecklistDto.setRegUserId("ADMIN");
        commonSql.insert("AvnAuditChecklist.insertAuditChecklist", tbAuditChecklistDto);
        return tbAuditChecklistDto.getChecklistId();
    }

    // Checklist 수정 (chapter,question CUD 포함)
    @Override
    @Transactional
    public TBAuditQuestionPostDto updateAuditChecklist(TBAuditQuestionPostDto tbQuestionsDto){
        List<TBAuditQuestionDto> inserted = tbQuestionsDto.getInserted();
        List<TBAuditQuestionDto> updated = tbQuestionsDto.getUpdated();
        List<Integer> deletedIds = tbQuestionsDto.getDeleted();
        int checklistOriginId = tbQuestionsDto.getChecklistOriginId();
        int chapterOriginId = tbQuestionsDto.getChapterOriginid();
        String checklistName = tbQuestionsDto.getChecklistName();
        //String empNo = tbQuestionsDto.getEmpNo();
        String empNo = "ADMIN";

        // Revision update - Y
        if(tbQuestionsDto.isRevisionUpdate()) {
            // 1. 새 체크리스트 버전 생성
            TBAuditChecklistDto newChecklistDto = createNewChecklistVersion(checklistOriginId);
            commonSql.insert("AvnAuditChecklist.insertAuditChecklistNextRevision", newChecklistDto);
            int newChecklistRevision = newChecklistDto.getRevision();

            // 체크리스트명만 변경 시 (챕터가 없는 경우 chapterOriginId 0 으로 보냄)
            if (chapterOriginId < 1) {
                // 챕터를 선택하지 않고 체크리스트명만 변경시 리턴
                return tbQuestionsDto;
            }

            // 2. 새 챕터 버전 생성
            TBAuditChapterDto newChapterRevision = createNewChapterVersion(chapterOriginId, newChecklistRevision);
            commonSql.insert("AvnAuditChecklist.insertAuditChapterNextRevision", newChapterRevision);

            // 3-1. Question 등록
            for(TBAuditQuestionDto question : inserted) {
                question.setRegUserId(empNo);
                question.setChapterOrigId(chapterOriginId);
                question.setChecklistRevision(newChecklistRevision);
                commonSql.insert("AvnAuditChecklist.insertAuditQuestion", question);
            }
            
            // 3-2. Question 수정
            for(TBAuditQuestionDto updatedQuestion : updated) {
                TBAuditQuestionDto newQuestion = createNewQuestionVersion(updatedQuestion, newChecklistRevision);
                newQuestion.setRegUserId(empNo);
                commonSql.insert("AvnAuditChecklist.insertQuestionUdpRevision", newQuestion);
            }
            
            // 3-3. Question 삭제
            for(Integer deletedId : deletedIds) {
                TBAuditQuestionDto targetQuestion = commonSql.selectOne("AvnAuditChecklist.findQuestionsById", deletedId);
                targetQuestion.setRevision(targetQuestion.getRevision() + 1);
                targetQuestion.setChecklistRevision(newChecklistRevision);
                targetQuestion.setRegUserId(empNo);
                targetQuestion.setUpdUserId(empNo);
                commonSql.insert("AvnAuditChecklist.insertQuestionDelRevision", targetQuestion);
            }
        }
        // Revision update - N
        else {
            // 1. 체크리스트 수정
            TBAuditChecklistDto currentChecklist = commonSql.selectOne("AvnAuditChecklist.findLatestAuChecklistByOriginId", checklistOriginId);
            currentChecklist.setListName(checklistName);
            currentChecklist.setUpdUserId(empNo);
            int newChecklistRevision = currentChecklist.getRevision();
            commonSql.update("AvnAuditChecklist.updateAuditChecklist", currentChecklist);

            // 2. Chapter 수정 (없음)

            // 3-1. Question 등록
            for(TBAuditQuestionDto question : inserted) {
                question.setRegUserId(empNo);
                question.setChapterOrigId(chapterOriginId);
                question.setChecklistRevision(newChecklistRevision);
                commonSql.insert("AvnAuditChecklist.insertAuditQuestion", question);
            }

            // 3-2. Question 수정
            for(TBAuditQuestionDto question : updated) {
                question.setUpdUserId(empNo);
                commonSql.update("AvnAuditChecklist.updateAuditQuestion", question);
            }

            // 3-3. Question 삭제
            if (deletedIds != null && !deletedIds.isEmpty()) {
                QuestionDeleteVo deletedTarget = new QuestionDeleteVo(deletedIds, empNo);
                commonSql.update("AvnAuditChecklist.deleteAuditQuestions", deletedTarget);
            }
        }

        return tbQuestionsDto;
    }

    // Checklist 삭제
    @Override
    public void deleteAuditChecklist(TBAuditChecklistDto tbAuditChecklistDto){
        commonSql.update("AvnAuditChecklist.deleteAuditChecklist", tbAuditChecklistDto);
    }

    // Chapter 등록
    @Override
    @Transactional
    public TBAuditChapterDto insertAuditChapter(TBAuditChapterDto tbAuditChapterDto){

        TBAuditChecklistDto checkListDto = new TBAuditChecklistDto();
        tbAuditChapterDto.setRegUserId("ADMIN");
        // Revision update - Y
        if(tbAuditChapterDto.isRevisionUpdate()) {
            checkListDto = createNewChecklistVersion(tbAuditChapterDto.getChecklistOrigId());
            commonSql.insert("AvnAuditChecklist.insertAuditChecklistNextRevision", checkListDto);
        }
        // Revision update - N
        else {
            checkListDto = commonSql.selectOne("AvnAuditChecklist.findLatestAuChecklistByOriginId", tbAuditChapterDto.getChecklistOrigId());
        }

        tbAuditChapterDto.setChecklistOrigId(checkListDto.getOrigId());
        tbAuditChapterDto.setChecklistRevision(checkListDto.getRevision());
        commonSql.insert("AvnAuditChecklist.insertAuditChapter", tbAuditChapterDto);
        return tbAuditChapterDto;
    }

    // Chapter 수정
    @Override
    @Transactional
    public TBAuditChapterDto updateAuditChapter(TBAuditChapterDto tbAuditChapterDto){

        TBAuditChecklistDto checkListDto = new TBAuditChecklistDto();
        tbAuditChapterDto.setRegUserId("ADMIN");

        // Revision update - Y
        if(tbAuditChapterDto.isRevisionUpdate()) {
            checkListDto = createNewChecklistVersion(tbAuditChapterDto.getChecklistOrigId());
            commonSql.insert("AvnAuditChecklist.insertAuditChecklistNextRevision", checkListDto);

            tbAuditChapterDto = createNewChapterVersion(tbAuditChapterDto.getOrigId(), checkListDto.getRevision());
            commonSql.insert("AvnAuditChecklist.insertAuditChapterNextRevision", tbAuditChapterDto);
        }
        // Revision update - N
        else {
            commonSql.update("AvnAuditChecklist.updateAuditChapter", tbAuditChapterDto);
        }

        return tbAuditChapterDto;
    }

    // Chapter 삭제
    @Override
    @Transactional
    public TBAuditChapterDto deleteAuditChapter(TBAuditChapterDto tbAuditChapterDto){

        TBAuditChecklistDto checkListDto = new TBAuditChecklistDto();
        tbAuditChapterDto.setRegUserId("ADMIN");

        // Revision update - Y
        if(tbAuditChapterDto.isRevisionUpdate()) {
            checkListDto = createNewChecklistVersion(tbAuditChapterDto.getChecklistOrigId());
            commonSql.insert("AvnAuditChecklist.insertAuditChecklistNextRevision", checkListDto);

            tbAuditChapterDto = createNewChapterVersion(tbAuditChapterDto.getOrigId(), checkListDto.getRevision());
            commonSql.insert("AvnAuditChecklist.deleteAuditChapterNextRevision", tbAuditChapterDto);
        }
        // Revision update - N
        else {
            commonSql.update("AvnAuditChecklist.deleteAuditChapter", tbAuditChapterDto);
        }

        return tbAuditChapterDto;
    }

    // checklistoriginId로 다음 버전의 체크리스트를 생성하는 함수
    private TBAuditChecklistDto createNewChecklistVersion(int checklistOriginId) {
        TBAuditChecklistDto nextChecklistRevision = commonSql.selectOne("AvnAuditChecklist.findLatestAuChecklistByOriginId", checklistOriginId);
        nextChecklistRevision.setRevision(nextChecklistRevision.getRevision() + 1);
        return nextChecklistRevision;
    }

    // chapterOriginId로 다음 버전의 챕터를 생성하는 함수
    private TBAuditChapterDto createNewChapterVersion(int chapterOriginId, int checklistRevision) {
        TBAuditChapterDto nextChapterRevision = commonSql.selectOne("AvnAuditChecklist.findLatestAuChapterByOriginId", chapterOriginId);
        nextChapterRevision.setRevision(nextChapterRevision.getRevision() + 1);
        nextChapterRevision.setChecklistRevision(checklistRevision);
        return nextChapterRevision;
    }

    // QuestionId로 다음 버전의 문항를 생성하는 함수
   private TBAuditQuestionDto createNewQuestionVersion(TBAuditQuestionDto updatedQuestion, int checklistRevision) {
       TBAuditQuestionDto nextQuestionRevision = commonSql.selectOne("AvnAuditChecklist.findQuestionsById", updatedQuestion.getQuestionId());
       nextQuestionRevision.setRevision(nextQuestionRevision.getRevision() + 1);
       nextQuestionRevision.setChecklistRevision(checklistRevision);
       nextQuestionRevision.setContent(updatedQuestion.getContent());
       nextQuestionRevision.setRefManual(updatedQuestion.getRefManual());
       nextQuestionRevision.setPriority(updatedQuestion.getPriority());
       nextQuestionRevision.setProbability(updatedQuestion.getProbability());
       nextQuestionRevision.setSeverity(updatedQuestion.getSeverity());
       return nextQuestionRevision;
   }
}
