package com.koreanair.ksms.common.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbTbAvnDisplayStatusDto extends CommonDto {
    private String id;
    private String systemType;
    private String phase;
    private String state;
    private String stepCode;
    private String textUserEn;
    private String textUserKo;
    private String textAdminEn;
    private String textAdminKo;
    private String notes;
    private String deletedAt;
    private int viewOrder;
    private String pageCode;
}
