package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = " 레포트_MSR_상세정보")
public class TbAvnReportMsrDtlInfoDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "ID")
    @NotBlank
    private int id;
    
    @Schema(description = "레포트상세정보유형코드")
    private String reportDtlInfoTypeCd;
    
    @Schema(description = "명명법명")
    private String nomenclatureNm;
    
    @Schema(description = "부품명")
    private String partNm;
    
    @Schema(description = "일련번호명")
    private String serialnoNm;
    
    @Builder
    public TbAvnReportMsrDtlInfoDto(

            Integer reportId,
            Integer id,
            String reportDtlInfoTypeCd,
            String nomenclatureNm,
            String partNm,
            String serialnoNm

            ) {
        this.reportId = reportId == null ? 0 : reportId;
        this.id = id == null ? 0 : id;
        this.reportDtlInfoTypeCd = reportDtlInfoTypeCd;
        this.nomenclatureNm = nomenclatureNm;
        this.partNm = partNm;
        this.serialnoNm = serialnoNm;
    }
}
