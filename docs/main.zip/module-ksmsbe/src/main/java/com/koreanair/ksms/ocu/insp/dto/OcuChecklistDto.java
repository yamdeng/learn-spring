package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "점검표")
public class OcuChecklistDto extends CommonDto {
    
    @Schema(description = "점검표_ID")
    private String chkListId;
    
    @Schema(description = "점검표_구분_코드")
    @NotBlank
    private String chkListClsCd;
    
    @Schema(description = "점검_버전")
    private Integer chkVer;
    
    @Schema(description = "점검표_제목")
    @NotBlank
    private String chkListTitle;
    
    @Schema(description = "기준_레벨")
    private Integer stdLevel;
}
