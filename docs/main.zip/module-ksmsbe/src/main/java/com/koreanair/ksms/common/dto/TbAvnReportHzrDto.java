package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_HZR")
public class TbAvnReportHzrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "익명여부")
    @NotBlank
    private String anonyYn;
    
    @Schema(description = "피드백여부")
    @NotBlank
    private String feedbackYn;
    
    @Schema(description = "이메일주소")
    private String emailAddr;
    
    @Schema(description = "SAFETY여부")
    @NotBlank
    private String safetyYn;
    
    @Schema(description = "KAIRS여부")
    @NotBlank
    private String kairsYn;
}
