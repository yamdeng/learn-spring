package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.ReceiptVo;
import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.ReportViewlistDto;
import com.koreanair.ksms.avn.srm.dto.ReportViewlistVo;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AvnReportAnalysisServiceImpl extends AbstractBaseService implements AvnReportAnalysisService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    @Autowired
    AvnCommonService avnCommonService;

    @Autowired
    AvnReportReceiptService avnReportReceiptService;

    @Override
    public void getAuthSetting(ReportViewlistDto reportViewlistDto){

        String empNo = SecurityContextHolder.getContext().getAuthentication().getName();

        //LSC 맴버확인용 empNo;
        reportViewlistDto.setP_empNo(empNo);

        // report status filter 생성
        String actionPhase = reportViewlistDto.getP_phase();
        if ("receipt".equals(actionPhase) || "1stRiskAssessment".equals(actionPhase)) {
            selectReportAuthSetting(actionPhase, reportViewlistDto);
        } else {
            selectHazardAuthSetting(actionPhase, reportViewlistDto);
        }
    }

    //보고서접수 | 1차위험평가(LSC) Auth 조회
    public void selectReportAuthSetting(String actionPhase, ReportViewlistDto reportViewlistDto) {
        List<String> authParam = new ArrayList<>();
        if ("receipt".equals(actionPhase)) {
            //접수
            authParam.add("report_acceptance");
        } else if ("1stRiskAssessment".equals(actionPhase)) {
            //1차위험도평가 와 1차 SRC
            authParam.add("risk_assessment");
            authParam.add("ssc_review");
        }
        //사용자 권한별 보고서 목록 조회
        List<String> reportList = avnCommonService.getAuthReportList(authParam);

        // size가 0인경우는 allList
        if (reportList.size() > 0) {
            if (reportList.contains("assigned_report")) {
                reportViewlistDto.setP_assignEmpNo(reportViewlistDto.getP_empNo());
            }
            reportViewlistDto.setP_reportList(reportList);
        }
    }

    //1차위험평가(SRC) | 경감조치 | 2차위험평가 | 종결 Auth 조회
    public void selectHazardAuthSetting(String actionPhase, ReportViewlistDto reportViewlistDto) {
        List<String> authParam = new ArrayList<>();
        if ("riskAcceptance".equals(actionPhase)) {
            authParam.add("ssc_review");
        } else if ("mitigation".equals(actionPhase)) {
            authParam.add("mitigation");
        } else if ("2ndRiskAssessment".equals(actionPhase)) {
            authParam.add("2nd_risk_assessment");
            authParam.add("2nd_ssc_review");
        } else if ("2ndRiskAcceptance".equals(actionPhase)) {
            authParam.add("2nd_ssc_review");
        } else if("riskAcceptanceApproval".equals(actionPhase)) {
            authParam.add("approval");
        }
        //사용자 보고서 권한(ROLE)조회
        List<String> reportList = avnCommonService.getAuthReportList(authParam);

        // size가 0인경우는 allList
        if (reportList.size() > 0) {
            if ("mitigation".equals(actionPhase)) {
                if(reportList.contains("assigned_hazard")) {
                    TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
                    int deptId = userInfo.getDeptId();
                    reportViewlistDto.setP_mitigationDeptId(deptId);
                }
            }
            if ("2ndRiskAssessment".equals(actionPhase)) {
                if (reportList.contains("assigned_report")) {
                    reportViewlistDto.setP_assignEmpNo(reportViewlistDto.getP_empNo());
                }
            }
            reportViewlistDto.setP_reportList(reportList);
        }
    }

    //안전위험관리 > 보고서 분석 > 목록 조회
    @Override
    public PageInfo<ReportViewlistVo> getAnalysisList(ReportViewlistDto reportViewlistDto){

        List<ReportViewlistVo> resultReportList = new ArrayList<ReportViewlistVo>();
        List<ReportViewlistVo> resultHazardList = new ArrayList<ReportViewlistVo>();

        // report status filter 생성
        String actionPhase = reportViewlistDto.getP_phase();
        switch (actionPhase) {
            case "receipt":
            case "1stRiskAssessment":
                resultReportList = selectReportList(actionPhase, reportViewlistDto);
                return PageInfo.of(resultReportList);
            default:
                resultHazardList = selectHazardList(actionPhase, reportViewlistDto);
                return PageInfo.of(resultHazardList);
        }
    }

    //보고서접수 | 1차위험평가(LSC) 조회
    public List<ReportViewlistVo> selectReportList(String actionPhase, ReportViewlistDto reportViewlistDto) {
        return commonSql.selectList("AvnReportAnalysis.selectReportViewlist", reportViewlistDto);
    }

    //1차위험평가(SRC) | 경감조치 | 2차위험평가 | 종결 조회
    public List<ReportViewlistVo> selectHazardList(String actionPhase, ReportViewlistDto reportViewlistDto) {
        return commonSql.selectList("AvnReportAnalysis.selectHazardViewlist", reportViewlistDto);
    }

    //안전위험관리 > 보고서 분석 > 상세 조회
    @SuppressWarnings("unchecked")
    @Override
    public ReportInfoDto getAnalysisInfo(ReportInfoDto reportInfoDto){
        List<String> roleList = this.getRoleList();
        reportInfoDto.setP_roleList(roleList);

        TbSysUserDto userInfo = ksmsCommonService.selectUser(SecurityContextHolder.getContext().getAuthentication().getName());
        reportInfoDto.setP_empNo(userInfo.getEmpNo());


        //보고서 데이터 생성
        //1. 마스터 보고서 데이터
        //대표보고서 번호 가져옴





        //접수데이터 생성
        reportInfoDto.setP_resourceName("report_acceptance");
        ReceiptVo receiptData = avnReportReceiptService.selectReportReceipt(reportInfoDto);

        reportInfoDto.setReceiptVo(receiptData);

        //1차위험평가 데이터


        //1차SRC 데이터


        //경감조치 데이터



        //2차위험평가 데이터


        //2차SRC 데이터


        //종결 데이터




        return reportInfoDto;
    }







    public List<String> getRoleList () {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        List<String> roleList = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
        return roleList;
    }



}
