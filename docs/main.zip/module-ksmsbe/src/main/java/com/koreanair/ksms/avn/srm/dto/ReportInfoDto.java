package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import java.util.List;

@Getter
@Setter
@ToString
@Accessors(chain = true)
@Schema(description = "보고서 접수 상세")
public class ReportInfoDto {

    @Schema(description = "group id")
    @NotNull
    private Integer p_groupId;

    @Schema(description = "hazard id")
    private Integer p_hazardId;

    @Schema(description = "role list")
    private List<String> p_roleList;

    private boolean p_isView;

    @Schema(description = "업무명")
    private String p_resourceName="";

    private Integer p_lscUserId;

    @Schema(description = "사원번호")
    @NotNull
    private String p_empNo;

    @Schema(description = "step Number")
    @NotNull
    private Integer p_step;

    @Schema(description = "보고서 타입")
    @NotNull
    private String p_reportType;

    @Schema(description = "step별 상태")
    private String p_step1State;
    private String p_step2State;
    private String p_step3State;
    private String p_step4State;
    private String p_step5State;
    private String p_step6State;
    private String p_step7State;
    private String p_step8State;
    private String p_step9State;




    @Schema(description = "사용자 권한 타입 : 일반(열람) | 담당 | 관리자")
    private String p_userRoleType;

    //대표보고서 VO


    @Schema(description = "접수 VO")
    private ReceiptVo receiptVo;
}
