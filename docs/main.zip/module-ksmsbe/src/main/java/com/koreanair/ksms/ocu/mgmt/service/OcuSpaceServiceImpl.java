package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.github.pagehelper.PageInfo;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuSpaceDto;

@Service
public class OcuSpaceServiceImpl extends AbstractBaseService implements OcuSpaceService {

    public OcuSpaceDto selectOcuSpace(int id) {
        return commonSql.selectOne("OcuSpace.selectOcuSpace", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuSpaceDto> selectOcuSpaceList(OcuSpaceDto dto) {
        List<OcuSpaceDto> resultList = commonSql.selectList("OcuSpace.selectOcuSpaceList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuSpace(OcuSpaceDto dto) {
        commonSql.insert("OcuSpace.insertOcuSpace", dto);
    }

    @Override
    public void updateOcuSpace(OcuSpaceDto dto) {
        commonSql.update("OcuSpace.updateOcuSpace", dto);
    }

    @Override
    public void deleteOcuSpace(int id) {
        commonSql.delete("OcuSpace.deleteOcuSpace", id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuSpace(List<OcuSpaceDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuSpace", mapList);
    }
}
