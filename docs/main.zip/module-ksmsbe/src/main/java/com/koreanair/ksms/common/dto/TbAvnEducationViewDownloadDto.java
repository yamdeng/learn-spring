package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS 교육 열람/다운로드")
public class TbAvnEducationViewDownloadDto extends CommonDto {
    
    @Schema(description = "교육ID")
    @NotBlank
    private String educationViewDownloadId;
    
    @Schema(description = "사번")
    @NotBlank
    private String educationId;
    
    @Schema(description = "부서코드")
    @NotBlank
    private String empNo;
    
    @Schema(description = "업로드 링크ID")
    @NotBlank
    private String deptCd;
    
    @Schema(description = "업로드 첨부파일")
    @NotBlank
    private String viewDownloadType;
}
