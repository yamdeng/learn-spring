package com.koreanair.ksms.ocu.risk.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.risk.service.OcuHighRiskService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 위험성평가 - 중요위험 관리
 */
@Tag(name = "OcuHighRisk", description = "위험성평가 - 중요위험 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuHighRiskController {

    @Autowired
    OcuHighRiskService service;

    /**
     * 중요위험 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "중요위험 관리 목록 조회", description = "중요위험 관리 목록 조회 API")
    @GetMapping(value = "/risk/high-risks")
    public ResponseEntity<?> getHighRiskList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "중요위험 관리 상세정보 조회", description = "중요위험 관리 상세정보 조회 API")
    @GetMapping(value = "/risk/high-risks/{highRiskId}")
    public ResponseEntity<?> getHighRiskInfo(@PathVariable(value="highRiskId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
