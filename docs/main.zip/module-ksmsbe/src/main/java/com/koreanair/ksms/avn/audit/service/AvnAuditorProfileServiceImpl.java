package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnAuditorProfileServiceImpl extends AbstractBaseService implements AvnAuditorProfileService {
}
