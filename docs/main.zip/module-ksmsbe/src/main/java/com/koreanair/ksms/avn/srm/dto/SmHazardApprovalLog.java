package com.koreanair.ksms.avn.srm.dto;

import java.sql.Timestamp;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.hibernate.validator.constraints.Length;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Valid
public class SmHazardApprovalLog {

    @NotNull
    private int id;

    @NotNull
    private int hazard_id;

    @NotBlank
    @Length(max = 50)
    private String state;

    @NotBlank
    @Length(max = 50)
    private String phase;

    @NotBlank
    @Length(max = 50)
    private String stepCode;

    @NotBlank
    @Length(max = 50)
    private String empNo;

    @Length(max = 255)
    private String reason;

    @NotBlank
    @Length(max = 50)
    private String timezone;

    @NotNull
    private Timestamp createdAt;

    public SmHazardApprovalLog(int id, String state, String phase, String stepCode, String empNo) {
        this.id = id;
        this.state = state;
        this.phase = phase;
        this.stepCode = stepCode;
        this.empNo = empNo;
    }
}
