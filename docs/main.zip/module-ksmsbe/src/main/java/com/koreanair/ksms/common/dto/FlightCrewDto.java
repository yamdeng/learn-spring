package com.koreanair.ksms.common.dto;

import lombok.*;

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class FlightCrewDto {

    private String userId;
    private String empNo;
    private String empNm;
    private String crewGb;

}
