package com.koreanair.ksms.avn.main.service;

public interface AvnMainService {
}
