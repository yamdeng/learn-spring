package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "보고서 - 상태정보")
public class ReportWithApprovalStep {
    @NotNull
    private int id;

    private String docNo;

    @NotBlank
    private String reportType;

    @NotBlank
    private String empNo;

    private String subject;

    @NotBlank
    private String timeZone;

    @NotBlank
    private String phase;

    @NotBlank
    private String state;

    private String stepCode;

    //@NotNull
    //private Timestamp createdAt;

    //@NotNull
    //private Timestamp updatedAt;

    private Timestamp deletedAt;

    private String isSubmitted;

    private Timestamp submittedAt;

    private String assessmentNotes;

    private String isStatisticsOnly;

    private String approvalState;

    private String approvalPhase;

    private String approvalStepCode;
}
