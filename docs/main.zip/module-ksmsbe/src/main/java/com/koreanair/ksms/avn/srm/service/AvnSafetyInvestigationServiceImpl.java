package com.koreanair.ksms.avn.srm.service;

import java.util.List;

import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestifationConsequenceDto;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestifationHazardDto;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationDto;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationEventTypeDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSafetyInvestigationServiceImpl extends AbstractBaseService implements AvnSafetyInvestigationService {

    @Override
    public PageInfo<AvnSafetyInvestigationDto>selectInveReportList(AvnSafetyInvestigationDto avnSafetyInvestigationDto){
        List<AvnSafetyInvestigationDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectInveReportList", avnSafetyInvestigationDto);
        return PageInfo.of(resultList);
    }

    @Override
    public List<AvnSafetyInvestigationEventTypeDto>selectEventTypeASRList(){
        List<AvnSafetyInvestigationEventTypeDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectEventTypeASRList");
        return resultList;
    }

    @Override
    public List<AvnSafetyInvestifationConsequenceDto> selectConsequenceList(){
        List<AvnSafetyInvestifationConsequenceDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectConsequenceList");
        return resultList;
    }

    @Override
    public List<AvnSafetyInvestifationHazardDto> selectHazardList(){
        List<AvnSafetyInvestifationHazardDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectHazardList");
        return resultList;
    }
}
