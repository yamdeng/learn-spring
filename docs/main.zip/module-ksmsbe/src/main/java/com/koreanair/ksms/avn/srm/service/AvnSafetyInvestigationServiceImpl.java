package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.AvnSafetyInvestigationDto;
import com.koreanair.ksms.common.dto.TbAvnSafeConferenceDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnSafetyInvestigationServiceImpl extends AbstractBaseService implements AvnSafetyInvestigationService {

    @Override
    public PageInfo<AvnSafetyInvestigationDto>selectInveReportList(){
        List<AvnSafetyInvestigationDto> resultList = commonSql.selectList("AvnSafetyInvestigation.selectInveReportList");
        return PageInfo.of(resultList);
    }
}
