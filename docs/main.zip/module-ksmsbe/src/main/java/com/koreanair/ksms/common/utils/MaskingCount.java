package com.koreanair.ksms.common.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MaskingCount {
	EMP_NO(7),
	DEPT(5),
	NAME(3);
	
	private int count;

}
