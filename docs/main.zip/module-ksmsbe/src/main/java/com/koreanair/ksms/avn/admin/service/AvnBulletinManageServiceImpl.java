package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.TbBoardDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnBulletinManageServiceImpl extends AbstractBaseService implements AvnBulletinManageService {

    @Override
    public List<GenericDto> selectList() {
        return List.of();
    }

    //관리자 > 게시판 관리 > 안전정책 목록 조회
    @Override
    public PageInfo<TbBoardDto> selectSafetyPolicisList(TbBoardDto tbBoardDto){
        List<TbBoardDto> resultList = commonSql.selectList("AvnBulletinManage.selectSafetyPolicisList", tbBoardDto);
        return PageInfo.of(resultList);
    }

    //관리자 > 게시판 관리 > 안정정책 신규 등록
    @Override
    public void insertSafetyPolicy(TbBoardDto tbBoardDto){
        commonSql.insert("AvnBulletinManage.insertSafetyPolicy", tbBoardDto);
    }

    //관리자 > 게시판 관리 > 안전정책 상세
    @Override
    public TbBoardDto selectSafetyPolicy(String boardId){
        return commonSql.selectOne("AvnBulletinManage.selectSafetyPolicy", boardId);
    }

    //관리자 > 게시판 관리 > 안정정책 수정
    @Override
    public void updateSafetyPolicy(TbBoardDto tbBoardDto){
        commonSql.update("AvnBulletinManage.updateSafetyPolicy", tbBoardDto);
    }

    //관리자 > 게시판 관리 > 안정정책 삭제
    @Override
    public void deleteSafetyPolicy(String boardId){
        commonSql.delete("AvnBulletinManage.deleteSafetyPolicy", boardId);
    }
}
