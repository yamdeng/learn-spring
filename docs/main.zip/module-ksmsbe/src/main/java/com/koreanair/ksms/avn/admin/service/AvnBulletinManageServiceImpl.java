package com.koreanair.ksms.avn.admin.service;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnBulletinManageServiceImpl extends AbstractBaseService implements AvnBulletinManageService {

    @Override
    public List<GenericDto> selectList() {
        return List.of();
    }
}
