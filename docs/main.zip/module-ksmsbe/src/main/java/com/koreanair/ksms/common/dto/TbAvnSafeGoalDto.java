package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "안전목표")
public class TbAvnSafeGoalDto extends CommonDto {
    
    @Schema(description = "안전목표 ID")
    @NotBlank
    private String safeGoalId;
    
    @Schema(description = "연도")
    @NotBlank
    private String year;
    
    @Schema(description = "정성목표")
    private String qualitativeGoal;
    
    @Schema(description = "정량목표")
    private String quantitativeGoal;
    
    @Schema(description = "목표수치")
    private String goalPoint;
    
    @Schema(description = "사용여부")
    @NotBlank
    private String useYn;
}
