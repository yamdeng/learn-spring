package com.koreanair.ksms.common.utils;

import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.List;

@Slf4j
public class MaskingUtils {


	private MaskingTypes maskingType;

	private FieldTypes fieldType;
	

	public <T> T maskingOne(T object, MaskingTypes maskingType, FieldTypes fieldType)
			throws IllegalArgumentException, IllegalAccessException, InstantiationException, InvocationTargetException,
			NoSuchMethodException, SecurityException {
		this.maskingType = maskingType;
		this.fieldType = fieldType;
		return masking(object);
	}

	public <T> List<T> maskingList(List<T> list, MaskingTypes maskingType, FieldTypes fieldType)
			throws IllegalArgumentException, IllegalAccessException, InstantiationException, InvocationTargetException,
			NoSuchMethodException, SecurityException {
		this.maskingType = maskingType;
		this.fieldType = fieldType;
		for (T entity : list) {
			masking(entity);
		}

		return list;
	}

	/**
	 * Get MaskingType with report type, empNo of logged in user and target.
	 *
	 * @param reportType   ASR, CSR, MSR, GSR, HZR, DSR, RSR, FOQA.
	 * @param loggedInUser session information of logged in user as JsonObject.
	 * @param writerEmpNo  EMP_NO of report writer as String.
	 * @param targetEmpNo  EMP_NO of target as String.
	 * @return MaskingType if user is not same with target. If same, return null.
	 */
	public MaskingTypes getMaskingTypeForReport(
			String reportType, JsonObject loggedInUser, String writerEmpNo, String targetEmpNo) {
		// Extract EMP_NO of logged in user information.
		String userEmpNo = loggedInUser.getString("EMP_NO", "UNKNOWN");
		//logger.debug("session: {} / writer: {} / target: {}", userEmpNo, writerEmpNo, targetEmpNo);

		// Validate parameters: EMP_NO
		if ("UNKNOWN".equals(userEmpNo) || StringUtils.isEmpty(targetEmpNo)) {
			// If either side contains the wrong EMP_NO, return MaskingTypes.ALL to mask all
			// of values.
			//logger.warn("Could not define EMP_NO of logged in user or target user. Hide all of information.");
			return MaskingTypes.ALL;
		}

		// If user is same one with target, escape from util.
		if (userEmpNo.equals(targetEmpNo)) {
			//logger.info("Target user {} is same with logged in user. Show all of information.", targetEmpNo);
			return null;
		}

		// If user is NOT same with target but the writer, return MaskingTypes.EMP_NO to
		// maks only EMP_NO.
		if (userEmpNo.equals(writerEmpNo)) {
			//logger.info(
			//		"Logged in user is NOT the target user, but the writer. Hide only EMP_NO and show other information.");
			return MaskingTypes.EMP_NO;
		}

		// Validate parameter: reportType
		if (StringUtils.isEmpty(reportType)) {
			// If reportTypes contains the wrong value, return MaskingTypes.ALL to mask all
			// of values.
			//logger.warn("Could not define report type. Hide all of information.");
			return MaskingTypes.ALL;
		}
		String lowerReportType = reportType.toLowerCase();
		//logger.debug("lowerReportType is {}.", lowerReportType);

		// Check user role: System Administrator.
		JsonArray roleList = loggedInUser.getJsonArray("ROLE_LIST", new JsonArray());
		if (roleList.contains("SA")) {
			// User is System Administrator, so return null to skip masking value.
			//logger.info("Logged in user is the System Administrator. Show all of information.");
			return null;
		}

		// Compare user resource with report type.
		JsonObject resourceAuth = loggedInUser.getJsonObject("RESOURCE_AUTH", new JsonObject());
		JsonObject reportAuthority = resourceAuth.getJsonObject("report_authority", new JsonObject());

		// Check user resource: Receptionist.
		JsonArray reportAcceptance = reportAuthority.getJsonArray("report_acceptance", new JsonArray());
		if (reportAcceptance.contains("all_report") || reportAcceptance.contains(lowerReportType)) {
			//logger.info("Logged in user has the right to be in charge of reception. Show all of information.");
			return null;
		}

		JsonArray viewList = reportAuthority.getJsonArray("view_list", new JsonArray());
		if (viewList.contains("all_report") || viewList.contains(lowerReportType)) {
			//logger.info("Logged in user has access to view. Check exceptions: ASR, FOQA");

			List<String> exceptTarget = Arrays.asList("asr", "foqa");
			StringBuffer logMsgBuffer = new StringBuffer()
					.append("Logged in user belongs to the ")
					.append(lowerReportType.toUpperCase())
					.append(" view group.");
			if (exceptTarget.contains(lowerReportType)) {
				//logger.info(logMsgBuffer.append(" Hide all of information.").toString());
				return MaskingTypes.ALL;
			}

			//logger.info(logMsgBuffer.append(" Show all of information.").toString());
			return null;
		}

		// Return MaskingTypes.ALL to mask all of values because it does not correspond
		// to any condition.
		//logger.info("No conditions are met. Hide all of information.");
		return MaskingTypes.ALL;
	}

	private <T> T masking(T object) throws IllegalArgumentException, IllegalAccessException, InstantiationException,
			InvocationTargetException, NoSuchMethodException, SecurityException {
		if (this.maskingType == MaskingTypes.ALL) {
			String nameKo = (String) object.getClass().getMethod(getterFromFieldName(fieldType.getNameKo())).invoke(object);
			String nameEn = (String) object.getClass().getMethod(getterFromFieldName(fieldType.getNameEn())).invoke(object);
			String empNo = (String) object.getClass().getMethod(getterFromFieldName(fieldType.getEmpNo())).invoke(object);

			object.getClass().getMethod(setterFromFieldName(fieldType.getNameKo()), String.class).invoke(object, maskingAll(nameKo));
			object.getClass().getMethod(setterFromFieldName(fieldType.getNameEn()), String.class).invoke(object, maskingAll(nameEn));
			object.getClass().getMethod(setterFromFieldName(fieldType.getEmpNo()), String.class).invoke(object, maskingAll(empNo));
		} else if (maskingType == MaskingTypes.EMP_NO) {
			String empNo = (String) object.getClass().getMethod(getterFromFieldName(fieldType.getEmpNo())).invoke(object);
			object.getClass().getMethod(setterFromFieldName(fieldType.getEmpNo()), String.class).invoke(object, maskingApart(empNo));
		} else if (maskingType == MaskingTypes.NONE) {
			return object;
		}
		return object;
	}

	private String getterFromFieldName(String fieldName) {
		return "get" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
	}

	private String setterFromFieldName(String fieldName) {
		return "set" + fieldName.substring(0, 1).toUpperCase() + fieldName.substring(1);
	}

	public String maskingAll(String value) {
		return value.replaceAll("(?<=.{0}).", "*");
	}
	
	public String maskingAll(MaskingCount masking) {
		String text="";
		for(int i=0;i<masking.getCount();i++) {
			text+="*";
		}
		return text;
	}

	public String maskingApart(String value) {
		return value.replaceAll("(?<=.{3}).", "*");
	}

}
