package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_ASR")
public class TbAvnReportAsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드")
    private String reportDtlTypeCd;
    
    @Schema(description = "발생통로코드")
    private String runwayCd;
    
    @Schema(description = "비행단계코드")
    private String flightPhaseCd;
    
    @Schema(description = "고도수")
    private int altitudeCo;
    
    @Schema(description = "고도단위코드")
    private String altitudeUnitCd;
    
    @Schema(description = "속도수")
    private int speedCo;
    
    @Schema(description = "속도단위코드")
    private String speedUnitCd;
    
    @Schema(description = "MET코드")
    private String metCd;
    
    @Schema(description = "바람1수")
    private int windOneCo;
    
    @Schema(description = "바람2수")
    private int windTwoCo;
    
    @Schema(description = "승객수")
    private int paxCo;
    
    @Schema(description = "시정명")
    private String visibilityNm;
    
    @Schema(description = "구름명")
    private String cloudNm;
    
    @Schema(description = "고도계수")
    private int altimeterCo;
    
    @Schema(description = "고도계단위코드")
    private String altimeterUnitCd;
    
    @Schema(description = "온도수")
    private int tempCo;
    
    @Schema(description = "날씨코드배열")
    private String weatherCdarr;
    
    @Schema(description = "새유형코드")
    private String birdTypeCd;
    
    @Schema(description = "새크기코드")
    private String birdSizeCd;
    
    @Schema(description = "새수코드")
    private String birdCoCd;
    
    @Schema(description = "부딫친새수코드")
    private String struckBirdCoCd;
    
    @Schema(description = "시간유형코드")
    private String timeTypeCd;
    
    @Schema(description = "착륙점등여부")
    @NotBlank
    private String landingLightYn;
    
    @Schema(description = "파일럿경고여부")
    @NotBlank
    private String pilotWarnedYn;
    
    @Schema(description = "충돌시점명")
    private String impactTimeNm;
    
    @Schema(description = "새설명내용")
    private String birdDescriptionCn;
}
