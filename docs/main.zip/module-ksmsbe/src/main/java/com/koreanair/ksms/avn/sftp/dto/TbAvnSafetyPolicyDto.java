package com.koreanair.ksms.avn.sftp.dto;

import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbAvnSafetyPolicyDto extends CommonDto {

    @Schema(description = "게시판 ID")
    private int boardId;

    @Schema(description = "파일그룹SEQ")
    private int fileGroupSeq;

}
