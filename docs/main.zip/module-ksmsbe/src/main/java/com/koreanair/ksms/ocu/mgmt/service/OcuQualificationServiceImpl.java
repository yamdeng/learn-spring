package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuQualificationDto;

@Service
public class OcuQualificationServiceImpl extends AbstractBaseService implements OcuQualificationService {

    public OcuQualificationDto selectOcuQualification(int id) {
        return commonSql.selectOne("OcuQualification.select", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<OcuQualificationDto> selectOcuQualificationList(OcuQualificationDto dto) {
        return commonSql.selectList("selectOcuQualificationList", dto);
    }

    @Override
    public void insertOcuQualification(OcuQualificationDto dto) {
        commonSql.insert("insertOcuQualification", dto);
    }

    @Override
    public void updateOcuQualification(OcuQualificationDto dto) {
        commonSql.update("updateOcuQualification", dto);
    }

    @Override
    public void deleteOcuQualification(int id) {
        commonSql.delete("deleteOcuQualification", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuQualification(List<OcuQualificationDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());
        // commonSql.save("OcuQualification", mapList);
    }
}
