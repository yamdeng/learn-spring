package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.TbAvnAirports;
import com.koreanair.ksms.common.dto.TbSysUserCfgDto;
import com.koreanair.ksms.common.dto.TbTbAvnDisplayStatusDto;
import com.github.pagehelper.PageInfo;
import jakarta.validation.Valid;

import java.util.List;

public interface AvnCommonService {
    List<TbTbAvnDisplayStatusDto> selectPageCodeList(String pageCode);
    
    //공항 목록 조회
    PageInfo<TbAvnAirports> selectAirportList(String keyword);

    // 개인별 환경설정 조회
    TbSysUserCfgDto selectUserCfg();

    // 개인별 환경설정 저장
    void saveUserCfg(@Valid TbSysUserCfgDto dto);
}
