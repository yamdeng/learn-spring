package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.*;
import com.github.pagehelper.PageInfo;
import jakarta.validation.Valid;

import java.util.List;

public interface AvnCommonService {
    List<TbTbAvnDisplayStatusDto> selectPageCodeList(String pageCode);
    
    //공항 목록 조회
    PageInfo<TbAvnAirports> selectAirportList(String keyword);

    //항공기 목록 조회
    PageInfo<TbAvnAircrafts> selectAircraftList(String keyword);

    // 개인별 환경설정 조회
    TbSysUserCfgDto selectUserCfg();

    // 개인별 환경설정 저장
    void saveUserCfg(@Valid TbSysUserCfgDto dto);

    //권한에 알맞는 리포트 조회
    List<String> getAuthReportList(List<String> authList);

    //사용자 권한 조회
    List<String> selectRoleList();
    
    //전체 사용자 조회(보고서)
    PageInfo<TbAvnSysUserDto> selectUserListPage(String searchWord);

}
