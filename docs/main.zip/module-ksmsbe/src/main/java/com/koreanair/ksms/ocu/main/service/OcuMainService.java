package com.koreanair.ksms.ocu.main.service;

public interface OcuMainService {
}
