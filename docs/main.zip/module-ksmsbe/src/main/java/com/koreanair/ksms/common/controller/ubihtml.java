package com.koreanair.ksms.common.controller;

import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import com.ubireport.common.util.StrUtil;

public class ubihtml extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ubihtml() {

    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html; charset=utf-8");

		PrintWriter out = new PrintWriter(new OutputStreamWriter(response.getOutputStream(), "UTF-8"));		
		StringBuffer str = new StringBuffer();
		
		request.setCharacterEncoding("UTF-8");
		
		String appName = StrUtil.nvl(request.getContextPath(), "");
		if( appName.indexOf("/") == 0 ) {
			appName = appName.substring(1, appName.length());
		}
		
		String appUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort() + ((appName.length() == 0)?"":"/") + appName;

		String file = StrUtil.nvl(request.getParameter("reportFile"), "ubi_sample.jrf");
		String arg = StrUtil.nvl(request.getParameter("reportArg"), "user#ubireport#");
		arg = StrUtil.encrypt64(arg,"UTF-8");
		
		String resid  = StrUtil.nvl(request.getParameter("resid"), "UBIHTML");
		
		HttpSession session = request.getSession();
		
		try{
		      str.append(" \r\n");
		      str.append("<!DOCTYPE html PUBLIC '-//W3C//DTD HTML 4.01 Transitional//EN' 'http://www.w3.org/TR/html4/loose.dtd'> \r\n");
		      str.append("<html> \r\n");
		      str.append("<head> \r\n");
		      str.append("<meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\"/> \r\n");
		      str.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\"> \r\n");
		      str.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.5,user-scalable=yes\"> \r\n");
		      str.append("<title>UbiReport Viewer</title> \r\n");
		      str.append("<link rel=\"stylesheet\" type=\"text/css\" href=\"" + appUrl + "/api/v1/ubi4/css/ubieform.css\" /> \r\n");
		      str.append("<!--[if IE]><script src='./js/ubiexcanvas.js'></script><![endif]--> \r\n");
		      str.append("<script src='" + appUrl + "/api/v1/ubi4/js/ubicommon.js'></script> \r\n");
		      str.append("<script src='" + appUrl + "/api/v1/ubi4/js/ubihtml.js'></script> \r\n");
		      str.append("<script src='" + appUrl + "/api/v1/ubi4/js/msg.js'></script> \r\n");
		      str.append("<script src='" + appUrl + "/api/v1/ubi4/js/ubinonax.js'></script> \r\n");
		      str.append("<script src='" + appUrl + "/api/v1/ubi4/js/ubieform.js'></script> \r\n");
		      str.append(" \r\n");
		      str.append("<script language='javascript'> \r\n");
		      str.append("<!-- \r\n");
		      str.append(" \r\n");
		      str.append("//request.getScheme() 정보를 잘 못 가지고 온다면 아래의 변수 사용해서 호출 \r\n");
		      str.append("var appUrl = self.location.protocol + '//' + self.location.host + '" + ((appName.length() == 0)?"":"/") + appName + "';  \r\n");
		      str.append(" \r\n");

		      str.append("var ubiHtmlViewer = null; \r\n");
		      str.append("var ubiParams = { \r\n");
		      str.append("\t \"appurl\": \"" + appUrl + "\" //오류가 발생한다면 \"appurl\":appUrl 로 호출 \r\n");
		      str.append("\t ,\"key\": \"" + session.getId() + "\"  \r\n");
		      str.append("\t ,\"jrffile\": \"" + file + "\"  \r\n");
		      str.append("\t ,\"arg\": \"" + arg + "\"  \r\n");
		      str.append("\t ,\"resid\": \"" + resid+ "\"  \r\n");
		      str.append("}; \r\n");

		      str.append("var ubiEvents ={ \r\n");
		      str.append("\t  \"reportevent.previewend\": ubiReportPreviwEnd \r\n");
		      str.append("\t ,\"reportevent.printend\": ubiReportPrintEnd \r\n");
		      str.append("\t ,\"reportevent.exportend\": ubiReportExportEnd \r\n");
		      str.append("//\t ,\"reportevent.printClicked\": ubiReportPrintClicked \r\n");
		      str.append("//\t ,\"reportevent.exportClicked\": ubiReportExportClicked \r\n");
		      str.append("//\t ,\"eformevent.previewend\": ubiEformPreviewEnd \r\n");
		      str.append("//\t ,\"eformevent.saveend\": ubiEformSaveEnd \r\n");
		      str.append("}; \r\n");
		      str.append(" \r\n");
		      str.append("function ubiStart() { \r\n");
		      str.append("\t ubiHtmlViewer = UbiLoad(ubiParams, ubiEvents); \r\n");
		      str.append("\t ubiHtmlViewer.HmlExtension = 'hwp'; \r\n");
		      str.append(" \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiReportPreviwEnd() { \r\n");
		      str.append("\t //console.log('ubiPreviwEnd......'); \r\n");
		      str.append("\t  \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiReportPrintEnd() { \r\n");
		      str.append("\t //console.log('ubiReportPrintEnd......'); \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiReportExportEnd(filepath) { \r\n");
		      str.append("\t //console.log('ubiExportEnd......'); \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiReportPrintClicked() { \r\n");
		      str.append("\t //console.log('ubiReportPrintClicked......'); \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiReportExportClicked(flag) { \r\n");
		      str.append("\t //console.log('ubiReportExportClicked......' + flag); \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiEformSaveEnd() { \r\n");
		      str.append("\t //console.log('ubiEformSaveEnd......'); \r\n");
		      str.append("} \r\n");
		      str.append(" \r\n");
		      str.append("function ubiEformPreviewEnd() { \r\n");
		      str.append("\t //console.log('ubiEformPreviewEnd......'); \r\n");
		      str.append("}; \r\n");
		      str.append(" \r\n");
		      str.append("function ubiEformSaveEnd(file) { \r\n");
		      str.append("\t //console.log('ubiEformSaveEnd......' + file); \r\n");
		      str.append("}; \r\n");
		      str.append(" \r\n");
		      str.append("//--> \r\n");
		      str.append("</script> \r\n");
		      str.append("</head> \r\n");
		      str.append("<body onload='ubiStart()'> \r\n");
		      str.append("</body> \r\n");
		      str.append("</html> \r\n");
		      
		      out.write(str.toString());
		      out.flush();
			
		}catch (Exception e) {
			out.write(e.getMessage());
		} 
	
		if (out != null) {
			try {
				out.close();
			} catch (Exception e) {
			} finally {
				out = null;
			}
		}
		
	}

}