package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartner2ndInfoDto;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerDto;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerPlaceDto;


public interface OcuPartnerService {

    OcuPartnerDto selectOcuPartner(int id);
    PageInfo<OcuPartnerDto> selectOcuPartnerList(OcuPartnerDto paramDto);

    void insertOcuPartner(OcuPartnerDto dto);
    void updateOcuPartner(OcuPartnerDto dto);
    void deleteOcuPartner(int id);
    void saveOcuPartner(List<OcuPartnerDto> dataList);


    OcuPartnerPlaceDto selectOcuPartnerPlace(int id);
    PageInfo<OcuPartnerPlaceDto> selectOcuPartnerPlaceList(OcuPartnerPlaceDto paramDto);

    void insertOcuPartnerPlace(OcuPartnerPlaceDto dto);
    void updateOcuPartnerPlace(OcuPartnerPlaceDto dto);
    void deleteOcuPartnerPlace(int id);
    void saveOcuPartnerPlace(List<OcuPartnerPlaceDto> dataList);


    OcuPartner2ndInfoDto selectOcuPartner2ndInfo(int id);
    PageInfo<OcuPartner2ndInfoDto> selectOcuPartner2ndInfoList(OcuPartner2ndInfoDto paramDto);

    void insertOcuPartner2ndInfo(OcuPartner2ndInfoDto dto);
    void updateOcuPartner2ndInfo(OcuPartner2ndInfoDto dto);
    void deleteOcuPartner2ndInfo(int id);
    void saveOcuPartner2ndInfo(List<OcuPartner2ndInfoDto> dataList);



}
