package com.koreanair.ksms.avn.main.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnMainServiceImpl extends AbstractBaseService implements AvnMainService {
}
