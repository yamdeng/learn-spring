package com.koreanair.ksms.ocu.acdt.service;

public interface OcuPreventionService {
}
