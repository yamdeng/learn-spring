package com.koreanair.ksms.common.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import io.vertx.core.json.JsonObject;

import java.util.List;
import java.util.Map;

public interface KsmsCommonService {

    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    PageInfo<TbSysUserDto> selectUserList(String searchWord, String deptCd);

    JsonObject selectMessagesAll();

    TbSysUserDto selectUserProfile(String userId);

    List<TbSysVirtualGroupDto> selectUserGroups(String userId);

    TbSysUserDto selectUser(String userId);

    TbSysDeptDto selectDeptId(int deptId);

    TbSysDeptDto selectDeptCd(String deptCd);

    List<TbSysAlertMsgDto> selectAlertMessages(String userId, String recvYn);

    void setMessageRead(int alertMsgId);

    void setMessageReadAll(String userId);

    Map<String, Object> selectUserCfg(String userId);
}
