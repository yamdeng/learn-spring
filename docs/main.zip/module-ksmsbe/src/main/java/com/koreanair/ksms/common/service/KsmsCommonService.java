package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.common.dto.TbSysDeptDto;
import com.koreanair.ksms.common.dto.TbSysUserDto;

import java.util.List;
import java.util.Map;

public interface KsmsCommonService {

    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    List<TbSysUserDto> selectUserList(String searchWord, String deptCd);
}
