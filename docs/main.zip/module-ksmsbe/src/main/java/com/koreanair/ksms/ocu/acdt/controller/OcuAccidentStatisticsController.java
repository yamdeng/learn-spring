package com.koreanair.ksms.ocu.acdt.controller;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.acdt.service.OcuAccidentStatisticsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 업무상재해 - 사고 집계/통계
 */
@Tag(name = "OcuAccidentStatistics", description = "업무상재해 - 사고 집계/통계 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuAccidentStatisticsController {

    @Autowired
    OcuAccidentStatisticsService service;

    /**
     * 산업재해,중대재해 전체 통계 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "산업재해,중대재해 전체 통계 목록 조회", description = "산업재해,중대재해 전체 통계 목록 조회 API")
    @GetMapping(value = "/accident/statistics/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 산업재해 통계목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "산업재해 통계 목록 조회", description = "산업재해 통계 목록 조회 API")
    @GetMapping(value = "/accident/statistics/occupations")
    public ResponseEntity<?> getOccupationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 중대재해 통계목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "중대재해 통계 목록 조회", description = "중대재해 통계 목록 조회 API")
    @GetMapping(value = "/accident/statistics/serious")
    public ResponseEntity<?> getSeriousList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
