package com.koreanair.ksms.common.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import io.vertx.core.json.JsonObject;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class KsmsCommonServiceImpl extends AbstractBaseService implements KsmsCommonService {

    @Override
    public List<Map<String, Object>> selectLeftMenu(String workScope) {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("workScope", workScope);
        param.put("userId", userId);

        return commonSql.selectList("KsmsCommon.selectLeftMenu", param);
    }

    @Override
    public List<TbSysCodeGroupDto> selectCodeGroupList() {

        return commonSql.selectList("KsmsCommon.selectCodeGroupList");
    }

    @Override
    public List<TbSysCodeDto> selectCodeList(String codeGrpId) {

        return commonSql.selectList("KsmsCommon.selectCodeList", codeGrpId);
    }

    @Override
    public List<TbSysCodeDto> selectCodeListAll() {

        return commonSql.selectList("KsmsCommon.selectCodeListAll");
    }

    @Override
    public List<TbSysDeptDto> selectDeptList() {

        return commonSql.selectList("KsmsCommon.selectDeptList");
    }

    @Override
    public PageInfo<TbSysUserDto> selectUserList(String searchWord, String deptCd) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("searchWord", searchWord);
        param.put("deptCd", deptCd);

        List<TbSysUserDto> resultList = commonSql.selectList("KsmsCommon.selectUserList", param);

        return PageInfo.of(resultList);
    }

    @Override
    public JsonObject selectMessagesAll() {

        JsonObject korMessages = new JsonObject();
        JsonObject engMessages = new JsonObject();
        String msgKey = "";

        List<TbSysMessageDto> listKor = commonSql.selectList("KsmsCommon.selectMessagesKor");
        List<TbSysMessageDto> listEng = commonSql.selectList("KsmsCommon.selectMessagesEng");

        for(TbSysMessageDto dto: listKor) {
            msgKey = dto.getMsgKey();
            korMessages.put(msgKey, dto.getMsgKor());
        }

        for(TbSysMessageDto dto: listEng) {
            msgKey = dto.getMsgKey();
            engMessages.put(msgKey, dto.getMsgEng());
        }

        JsonObject messages = new JsonObject();
        messages.put("ko", korMessages);
        messages.put("en", engMessages);

        return messages;
    }

    @Override
    public TbSysUserDto selectUserProfile(String userId) {

        return commonSql.selectOne("KsmsCommon.selectUserProfile", userId);
    }

    @Override
    public List<TbSysVirtualGroupDto> selectUserGroups(String userId) {

        return commonSql.selectList("KsmsCommon.selectUserGroups", userId);
    }

    @Override
    public TbSysUserDto selectUser(String userId) {

        return commonSql.selectOne("KsmsCommon.selectUserDetail", userId);
    }

    @Override
    public TbSysDeptDto selectDeptId(int deptId) {

        return commonSql.selectOne("KsmsCommon.selectDeptIdDetail", deptId);
    }

    @Override
    public TbSysDeptDto selectDeptCd(String deptCd) {

        return commonSql.selectOne("KsmsCommon.selectDeptCdDetail", deptCd);
    }

    @Override
    public List<TbSysAlertMsgDto> selectAlertMessages(String userId, String recvYn) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("userId", userId);
        param.put("recvYn", recvYn);

        return commonSql.selectList("KsmsCommon.selectAlertMessages", param);
    }

    @Override
    public void setMessageRead(int alertMsgId) {

        commonSql.update("KsmsCommon.setMessageRead", alertMsgId);
    }

    @Override
    public void setMessageReadAll(String userId) {

        commonSql.update("KsmsCommon.setMessageReadAll", userId);
    }

    @Override
    public Map<String, Object> selectUserCfg(String userId) {

        Map<String, Object> result = commonSql.selectOne("KsmsCommon.selectUserCfg", userId);
        String reportsLang = (String) result.get("reportsLang");

        JSONParser parser = new JSONParser(reportsLang);
        Object jsonObject = null;
        try {
            jsonObject = parser.parse();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        result.put("reportsLang", jsonObject);

        return result;
    }
}
