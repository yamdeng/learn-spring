package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.*;
import io.vertx.core.json.JsonObject;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class KsmsCommonServiceImpl extends AbstractBaseService implements KsmsCommonService {

    @Override
    public List<Map<String, Object>> selectLeftMenu(String workScope) {

        return commonSql.selectList("KsmsCommon.selectLeftMenu", workScope);
    }

    @Override
    public List<TbSysCodeGroupDto> selectCodeGroupList() {

        return commonSql.selectList("KsmsCommon.selectCodeGroupList");
    }

    @Override
    public List<TbSysCodeDto> selectCodeList(String codeGrpId) {

        return commonSql.selectList("KsmsCommon.selectCodeList", codeGrpId);
    }

    @Override
    public List<TbSysCodeDto> selectCodeListAll() {

        return commonSql.selectList("KsmsCommon.selectCodeListAll");
    }

    @Override
    public List<TbSysDeptDto> selectDeptList() {

        return commonSql.selectList("KsmsCommon.selectDeptList");
    }

    @Override
    public List<TbSysUserDto> selectUserList(String searchWord, String deptCd) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("searchWord", searchWord);
        param.put("deptCd", deptCd);

        return commonSql.selectList("KsmsCommon.selectUserList", param);
    }

    @Override
    public JsonObject selectMessagesAll() {

        JsonObject korMessages = new JsonObject();
        JsonObject engMessages = new JsonObject();
        String msgKey = "";

        List<TbSysMessageDto> listKor = commonSql.selectList("KsmsCommon.selectMessagesKor");
        List<TbSysMessageDto> listEng = commonSql.selectList("KsmsCommon.selectMessagesEng");

        for(TbSysMessageDto dto: listKor) {
            msgKey = dto.getMsgKey();
            korMessages.put(msgKey, dto.getMsgKor());
        }

        for(TbSysMessageDto dto: listEng) {
            msgKey = dto.getMsgKey();
            engMessages.put(msgKey, dto.getMsgEng());
        }

        JsonObject messages = new JsonObject();
        messages.put("ko", korMessages);
        messages.put("en", engMessages);

        return messages;
    }
}
