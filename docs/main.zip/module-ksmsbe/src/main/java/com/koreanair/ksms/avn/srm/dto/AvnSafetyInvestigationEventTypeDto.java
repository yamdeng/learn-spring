package com.koreanair.ksms.avn.srm.dto;
import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnSafetyInvestigationEventTypeDto extends CommonDto {

    @Schema(description = "이벤트 ID")
    private int eventID;

    @Schema(description = "report Type")
    private String reportType;

    @Schema(description = "이벤트명")
    private String eventName;

    @Schema(description = "사용여부")
    private String useYn;

    @Schema(description = "표시순서")
    private String viewOrder;

    @Schema(description = "이전 이벤트 ID")
    private String eventOldId;

    @Schema(description = "notes")
    private String notes;

}
