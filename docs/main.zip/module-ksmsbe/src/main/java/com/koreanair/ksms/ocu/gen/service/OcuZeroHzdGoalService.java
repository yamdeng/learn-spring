package com.koreanair.ksms.ocu.gen.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuHsCommitteeDto;
import com.koreanair.ksms.ocu.gen.dto.OcuZeroHzdGoalDto;

import jakarta.validation.Valid;

/**
 * 무재해운동 목표 Service
 */
public interface OcuZeroHzdGoalService {

	/**
	 * 무재해운동 목표 관리 목록 조회
	 * @param dto
	 * @return
	 */
	public PageInfo<OcuZeroHzdGoalDto> selectList(OcuZeroHzdGoalDto dto);
	
	/**
	 * 무재해운동 목표 관리 상세 조회
	 * @param zeroHzdId
	 * @return
	 */
	public OcuZeroHzdGoalDto select(int zeroHzdId);

	/**
	 * 무재해운동 목표 관리 등록
	 * @param dto
	 */
	public void insert(OcuZeroHzdGoalDto dto);
	
	/**
	 * 무재해운동 목표 관리 수정
	 * @param zeroHzdId 
	 * @param reqDto
	 */
	public void update( @Valid OcuZeroHzdGoalDto.Post reqDto);
	
	/**
	 * 무재해운동 목표 관리 삭제
	 * @param zeroHzdId
	 */
	public void delete(int zeroHzdId);

	/**
	 * 무재해운동 이력 조회
	 * @param codeGroupId
	 * @return
	 */
	public List<OcuZeroHzdGoalDto> selectZeroHzdList(int zeroHzdId);

	/**
	 * 무재해운동 목표 및 이력 등록
	 * @param reqDto
	 */
	public void saveZeroHzdGoalStatus(@Valid OcuZeroHzdGoalDto reqDto);

	/**
	 * 무재해운동 중복 체크
	 * @param zeroHzdId
	 * @return
	 */
	public int selectZeroHzdGoalDupChk(String zeroHzdDeptCd);


    
}
