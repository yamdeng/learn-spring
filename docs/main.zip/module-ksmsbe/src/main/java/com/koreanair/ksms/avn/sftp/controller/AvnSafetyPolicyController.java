package com.koreanair.ksms.avn.sftp.controller;

import com.koreanair.ksms.avn.sftp.dto.TbAvnSafetyPolicyDto;
import com.koreanair.ksms.avn.sftp.service.AvnSafetyPolicyService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 안전정책 - 안전정책
 */
@Tag(name = "AvnSafetyPolicy", description = "안전정책 - 안전정책 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyPolicyController {

    @Autowired
    AvnSafetyPolicyService service;

    /**
     * 안전정책 목록 조회
     *
     * @return the TbSafetyPolicyDto
     * @throws Exception the exception
     */
    @Operation(summary = "안전정책 이미지 조회", description = "안전정책 이미지 조회 API")
    @GetMapping(value = "/policy/safety-policys")
    public ResponseEntity<?> getPolicyList() {

        TbAvnSafetyPolicyDto result = service.selectSafetyPolicyImg();
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "안전정책 상세정보 조회", description = "안전정책 상세정보 조회 API")
    @GetMapping(value = "/policy/safety-policys/{saftyPolicyId}")
    public ResponseEntity<?> getPolicyInfo(@PathVariable(value="saftyPolicyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 안전정책 등록", description = "신규 안전정책 등록 API")
    @PostMapping(value = "/policy/safety-policys")
    public ResponseEntity<?> insertPolicy(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전정책 정보 수정", description = "안전정책 정보 수정 API")
    @PutMapping(value = "/policy/safety-policys/{saftyPolicyId}")
    public ResponseEntity<?> updatePolicy(
            @PathVariable(value="saftyPolicyId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "안전정책 삭제", description = "안전정책 삭제 API")
    @DeleteMapping(value = "/policy/safety-policys/{saftyPolicyId}")
    public ResponseEntity<?> deletePolicy(@PathVariable(value="saftyPolicyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
