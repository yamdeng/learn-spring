package com.koreanair.ksms.common.utils;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Pattern;

//import com.koreanair.common.api.model.entity.KeAuditor;

public class KeUtils {
	
	public static ZonedDateTime parseUTC(Timestamp time,String timezone){
		try {
			LocalDateTime localDateTime = time.toLocalDateTime();
			ZonedDateTime zoneDateTime =localDateTime.atZone(ZoneId.of("UTC"));
			ZonedDateTime userZoneDateTime = zoneDateTime.withZoneSameInstant(ZoneId.of(timezone));
			return userZoneDateTime;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * lead|${empNo}|${nameKo}|${nameEn}\rauditor|${empNo}|${nameKo}|${nameEn}
	 * lead auditor parsing..
	 * 
	 * @param auditorStr
	 * @return KeAuditor
	 */
	/*
	public static KeAuditor getLeadAuditor(String auditorStr) {
		String [] auditors = auditorStr.split("\\\\r");
		for (String auditor: auditors) {
			if(Pattern.matches("^lead+.*", auditor)) {
				String[] fields = auditor.split("\\|");
				// 만약에 NAME_ENG가 없을 경우 NAME_KOR로 값 세팅
				String nameEn = fields.length > 3 ? fields[3] : fields[2];
				return KeAuditor.builder()
						.type(fields[0])
						.empNo(fields[1])
						.nameKo(fields[2])
						.nameEn(nameEn)
						.build();
			}
		}
		return null;
	}
	*/
	/**
     * validate that end date is greater than start date
     *
     * @param startDate start date
     * @param endDate end date
     * @return constraint violations or an empty set if none
     */
    public static boolean validateRange(Date startDate, Date endDate) {
        if (startDate != null && endDate != null) {
	    return endDate.equals(startDate) || endDate.after(startDate);
	}
			
	return false;
    }
	
	
    /**
     * validate that end date has not expired(year).
     *
     * @param startDate start date
     * @param endDate end date
     * @param year period of year
     * @return constraint violations or an empty set if none
     */
    public static boolean validatePeriodByYear(Date startDate, Date endDate, Integer year) {
        if (startDate != null && endDate != null) {
            Calendar target = Calendar.getInstance();
            target.setTime(startDate);
            target.add(Calendar.YEAR, year);

            return validateRange(startDate, endDate) && endDate.before(target.getTime());
        }

        return false;
    }

}
