package com.koreanair.ksms.avn.sftm.controller;

import com.koreanair.ksms.avn.sftm.service.AvnSafetySurveyService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전증진 - 안전문화설문
 */
@Tag(name = "AvnSafetySurvey", description = "안전증진 - 안전문화설문 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetySurveyController {

    @Autowired
    AvnSafetySurveyService service;

    /**
     * 안전문화설문 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "안전문화설문 목록 조회", description = "안전문화설문 목록 조회 API")
    @GetMapping(value = "/promotion/survey")
    public ResponseEntity<?> getSurveyList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "안전문화설문 상세정보 조회", description = "안전문화설문 상세정보 조회 API")
    @GetMapping(value = "/promotion/survey/{surveyId}")
    public ResponseEntity<?> getSurveyInfo(@PathVariable(value="surveyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
