package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - ASR정보")
public class ReceiptAsrVo extends SmReceptionAsr {
    private String docNo;
    private String reportType;
}
