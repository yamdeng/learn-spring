package com.koreanair.ksms.avn.admin.controller;

import com.koreanair.ksms.avn.admin.service.AvnCriteriaManageService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 - 필수 항목 관리
 */
@Tag(name = "AvnCriteriaManage", description = "관리자 - 필수 항목 관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnCriteriaManageController {

    @Autowired
    AvnCriteriaManageService service;

    /**
     * 위해요인 등록부 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "위해요인 등록부 관리 목록 조회", description = "위해요인 등록부 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> getHazardRegisterList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "위해요인 등록부 관리 상세정보 조회", description = "위해요인 등록부 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/taxonomies/{taxonomyId}")
    public ResponseEntity<?> getHazardRegisterInfo(@PathVariable(value="taxonomyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 위해요인 등록부 관리 등록", description = "신규 위해요인 등록부 관리 등록 API")
    @PostMapping(value = "/admin/criteria/taxonomies")
    public ResponseEntity<?> insertHazardRegister(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 정보 수정", description = "위해요인 등록부 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/taxonomies/{taxonomyId}")
    public ResponseEntity<?> updateHazardRegister(
            @PathVariable(value="taxonomyId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "위해요인 등록부 관리 삭제", description = "위해요인 등록부 관리 삭제 API")
    @DeleteMapping(value = "/admin/criteria/taxonomies/{taxonomyId}")
    public ResponseEntity<?> deleteHazardRegister(@PathVariable(value="taxonomyId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Potential Consequence 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Potential Consequence 목록 조회", description = "Potential Consequence 목록 조회 API")
    @GetMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> getPotentialConsequenceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Potential Consequence 상세정보 조회", description = "Potential Consequence 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> getPotentialConsequenceInfo(@PathVariable(value="consequenceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Potential Consequence 등록", description = "신규 Potential Consequence 등록 API")
    @PostMapping(value = "/admin/criteria/consequences")
    public ResponseEntity<?> insertPotentialConsequence(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 정보 수정", description = "Potential Consequence 정보 수정 API")
    @PutMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> updatePotentialConsequence(
            @PathVariable(value="consequenceId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Potential Consequence 삭제", description = "Potential Consequence 삭제 API")
    @DeleteMapping(value = "/admin/criteria/consequences/{consequenceId}")
    public ResponseEntity<?> deletePotentialConsequence(@PathVariable(value="consequenceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 이벤트 타입 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "이벤트 타입 관리 목록 조회", description = "이벤트 타입 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> getEventTypeList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "이벤트 타입 관리 상세정보 조회", description = "이벤트 타입 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> getEventTypeInfo(@PathVariable(value="eventTypeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 이벤트 타입 관리 등록", description = "신규 이벤트 타입 관리 등록 API")
    @PostMapping(value = "/admin/criteria/event-types")
    public ResponseEntity<?> insertEventType(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 정보 수정", description = "이벤트 타입 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> updateEventType(
            @PathVariable(value="eventTypeId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "이벤트 타입 관리 삭제", description = "이벤트 타입 관리 삭제 API")
    @DeleteMapping(value = "/admin/criteria/event-types/{eventTypeId}")
    public ResponseEntity<?> deleteEventType(@PathVariable(value="eventTypeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * RISK MATRIX 관리 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "RISK MATRIX 관리 목록 조회", description = "RISK MATRIX 관리 목록 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix")
    public ResponseEntity<?> getRiskMatrixList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "RISK MATRIX 관리 상세정보 조회", description = "RISK MATRIX 관리 상세정보 조회 API")
    @GetMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> getRiskMatrixInfo(@PathVariable(value="riskMatrixId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "RISK MATRIX 관리 정보 수정", description = "RISK MATRIX 관리 정보 수정 API")
    @PutMapping(value = "/admin/criteria/risk-matrix/{riskMatrixId}")
    public ResponseEntity<?> updateRiskMatrix(
            @PathVariable(value="riskMatrixId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }
}
