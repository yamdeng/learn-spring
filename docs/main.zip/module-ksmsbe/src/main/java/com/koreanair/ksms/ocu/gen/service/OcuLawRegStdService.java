package com.koreanair.ksms.ocu.gen.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegStdDto;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;
import com.koreanair.ksms.ocu.gen.dto.OcuZeroHzdGoalDto;

import jakarta.validation.Valid;

import java.util.List;

/**
 * 법규등록대장 기준 정보 service
 */
public interface OcuLawRegStdService {

	/**
	 * 법규등록대장 기준 정보 목록 조회
	 * @param paramDto
	 * @return
	 */
	public PageInfo<OcuLawRegStdDto> selectOcuLawRegStdList(OcuLawRegStdDto paramDto);
	
    /**
     * 법규등록대장 기준 정보 상세 조회
     * @param lawSeq
     * @return
     */
	public OcuLawRegStdDto selectOcuLawRegStd(String lawId);

    /**
     * 법규등록대장 기준 정보 등록
     */
    public void insertOcuLawRegStd(@Valid OcuLawRegStdDto dto);
    
    /**
     * 법규등록대장 기준 정보 수정
     */
    public void updateOcuLawRegStd(@Valid OcuLawRegStdDto dto);
    
    /**
     * 법규등록대장 기준 정보 삭제
     * @param lawSeq
     */
    public void deleteOcuLawRegStd(String lawId);

	/**
	 * 법규등록대장 존재 여부 체크
	 * @param lawId
	 * @return
	 */
	public int selectOcuLawRegInfoChk(String lawId);
	
	/**
	 * 기준 정보값 법규등록대장 존재 여부 체크
	 * @param codeGroupId
	 * @return
	 */
	public List<OcuLawRegStdDto> selectLawBatchChk();
    
	
	/** 
	 * 1. 오늘날짜에 입력 된 값 조회
	 * 2. 리스트 뽑아서 법규 id 비교 후 없는 경우  
	 * 3. insert
	 * 
	 * 
	 * **/
	
	
    
    
}
