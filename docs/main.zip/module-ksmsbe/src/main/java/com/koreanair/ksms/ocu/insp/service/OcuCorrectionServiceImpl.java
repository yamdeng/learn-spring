package com.koreanair.ksms.ocu.insp.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class OcuCorrectionServiceImpl extends AbstractBaseService implements OcuCorrectionService {
}
