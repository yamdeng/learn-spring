package com.koreanair.ksms.common.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
@Getter
@Setter
public class AccessApiModel {
    private String name;
    private List<String> apis;
}