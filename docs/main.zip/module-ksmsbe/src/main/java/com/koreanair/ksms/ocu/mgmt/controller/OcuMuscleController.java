package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuMuscleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전관리 - 근골격계 유해요인 조사
 */
@Tag(name = "OcuMuscle", description = "안전관리 - 근골격계 유해요인 조사 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuMuscleController {

    @Autowired
    OcuMuscleService service;

    /**
     * 기본조사 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "기본조사 목록 조회", description = "기본조사 목록 조회 API")
    @GetMapping(value = "/management/muscle/basics")
    public ResponseEntity<?> getBasicList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "기본조사 상세정보 조회", description = "기본조사 상세정보 조회 API")
    @GetMapping(value = "/management/muscle/basics/{basicId}")
    public ResponseEntity<?> getBasicInfo(@PathVariable(value="basicId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 기본조사 등록", description = "신규 기본조사 등록 API")
    @PostMapping(value = "/management/muscle/basics")
    public ResponseEntity<?> insertBasic(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "기본조사 정보 수정", description = "기본조사 정보 수정 API")
    @PutMapping(value = "/management/muscle/basics/{basicId}")
    public ResponseEntity<?> updateBasic(
            @PathVariable(value="basicId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "기본조사 삭제", description = "기본조사 삭제 API")
    @DeleteMapping(value = "/management/muscle/basics/{basicId}")
    public ResponseEntity<?> deleteBasic(@PathVariable(value="basicId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 증상조사 통계 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "증상조사 통계 조회", description = "증상조사 통계 조회 API")
    @GetMapping(value = "/management/muscle/symptoms")
    public ResponseEntity<?> getSymptomList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 정밀조사 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "정밀조사 목록 조회", description = "정밀조사 목록 조회 API")
    @GetMapping(value = "/management/muscle/precisions")
    public ResponseEntity<?> getPrecisionList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "정밀조사 상세정보 조회", description = "정밀조사 상세정보 조회 API")
    @GetMapping(value = "/management/muscle/precisions/{precisionId}")
    public ResponseEntity<?> getPrecisionInfo(@PathVariable(value="precisionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 정밀조사 등록", description = "신규 정밀조사 등록 API")
    @PostMapping(value = "/management/muscle/precisions")
    public ResponseEntity<?> insertPrecision(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "정밀조사 정보 수정", description = "정밀조사 정보 수정 API")
    @PutMapping(value = "/management/muscle/precisions/{precisionId}")
    public ResponseEntity<?> updatePrecision(
            @PathVariable(value="precisionId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "정밀조사 삭제", description = "정밀조사 삭제 API")
    @DeleteMapping(value = "/management/muscle/precisions/{precisionId}")
    public ResponseEntity<?> deletePrecision(@PathVariable(value="precisionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 전체결과 목록조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "전체결과 목록조회", description = "전체결과 목록조회 API")
    @GetMapping(value = "/management/muscle/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 부서별/작업별/요인별 세부사항 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "부서별/작업별/요인별 세부사항 조회", description = "부서별/작업별/요인별 세부사항 조회 API")
    @GetMapping(value = "/management/muscle/details")
    public ResponseEntity<?> getDetailList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
