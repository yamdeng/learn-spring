package com.koreanair.ksms.ocu.mgmt.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuSpaceService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuSpaceDto;

import java.util.List;

@Tag(name = "밀폐공간 현황", description = "밀폐공간 현황 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuSpaceController {

    @Autowired
    private OcuSpaceService ocuSpaceService;

    @Operation(summary = "밀폐공간 현황 상세 조회", description = "밀폐공간 현황 상세 조회 API")
    @GetMapping("/management/sealSpace/{id}")
    public ResponseEntity<?> selectOcuSpace(@PathVariable(value="id", required=true) int id) {
        
        OcuSpaceDto result = ocuSpaceService.selectOcuSpace(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "밀폐공간 현황 목록 조회", description = "밀폐공간 현황 목록 조회 API")
    @GetMapping("/management/sealSpace")
    public ResponseEntity<?> getDeptList(
        @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
        ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){
  
        OcuSpaceDto paramDto = new OcuSpaceDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuSpaceDto> pageList = ocuSpaceService.selectOcuSpaceList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "밀폐공간 현황 일괄 저장", description = "밀폐공간 현황 일괄 저장 API")
    @PostMapping("/management/sealSpace/bulk")
    public ResponseEntity<?> saveOcuSpace(@RequestBody List<OcuSpaceDto> reqDtoList) {

        ocuSpaceService.saveOcuSpace(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간 현황 등록", description = "밀폐공간 현황 등록 API")
    @PostMapping(value = "/management/sealSpace")
    public ResponseEntity<?> insertOcuSpace(@Valid @RequestBody(required=true) OcuSpaceDto reqDto){

        ocuSpaceService.insertOcuSpace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간 현황 수정", description = "밀폐공간 현황 수정 API")
    @PutMapping(value = "/management/sealSpace")
    public ResponseEntity<?> updateOcuSpace(@Valid @RequestBody(required=true) OcuSpaceDto reqDto){
        
        ocuSpaceService.updateOcuSpace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간 현황 삭제", description = "밀폐공간 현황 삭제 API")
    @DeleteMapping(value = "/management/sealSpace/{id}")
    public ResponseEntity<?> deleteOcuSpace(@PathVariable(value="id", required=true) int id){
        ocuSpaceService.deleteOcuSpace(id);
        return ResponseUtil.createSuccessResponse();
    }

}


