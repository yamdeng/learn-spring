package com.koreanair.ksms.ocu.mgmt.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.mgmt.service.OcuSpaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전관리 - 밀폐공간관리
 */
@Tag(name = "OcuSpace", description = "안전관리 - 밀폐공간관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuSpaceController {

    @Autowired
    OcuSpaceService service;

    /**
     * 밀폐공간관리_부문별 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "밀폐공간관리_부문별 목록 조회", description = "밀폐공간관리_부문별 목록 조회 API")
    @GetMapping(value = "/management/space/sectors")
    public ResponseEntity<?> getSectorList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "밀폐공간관리_부문별 상세정보 조회", description = "밀폐공간관리_부문별 상세정보 조회 API")
    @GetMapping(value = "/management/space/sectors/{sectorId}")
    public ResponseEntity<?> getSectorInfo(@PathVariable(value="sectorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 밀폐공간관리_부문별 등록", description = "신규 밀폐공간관리_부문별 등록 API")
    @PostMapping(value = "/management/space/sectors")
    public ResponseEntity<?> insertSector(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간관리_부문별 정보 수정", description = "밀폐공간관리_부문별 정보 수정 API")
    @PutMapping(value = "/management/space/sectors/{sectorId}")
    public ResponseEntity<?> updateSector(
            @PathVariable(value="sectorId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간관리_부문별 삭제", description = "밀폐공간관리_부문별 삭제 API")
    @DeleteMapping(value = "/management/space/sectors/{sectorId}")
    public ResponseEntity<?> deleteSector(@PathVariable(value="sectorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 밀폐공간관리_사업장별 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "밀폐공간관리_사업장별 목록 조회", description = "밀폐공간관리_사업장별 목록 조회 API")
    @GetMapping(value = "/management/space/workplaces")
    public ResponseEntity<?> getWorkplaceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "밀폐공간관리_사업장별 상세정보 조회", description = "밀폐공간관리_사업장별 상세정보 조회 API")
    @GetMapping(value = "/management/space/workplaces/{workspaceId}")
    public ResponseEntity<?> getWorkplaceInfo(@PathVariable(value="workspaceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 밀폐공간관리_사업장별 등록", description = "신규 밀폐공간관리_사업장별 등록 API")
    @PostMapping(value = "/management/space/workplaces")
    public ResponseEntity<?> insertWorkplace(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간관리_사업장별 정보 수정", description = "밀폐공간관리_사업장별 정보 수정 API")
    @PutMapping(value = "/management/space/workplaces/{workspaceId}")
    public ResponseEntity<?> updateWorkplace(
            @PathVariable(value="workspaceId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "밀폐공간관리_사업장별 삭제", description = "밀폐공간관리_사업장별 삭제 API")
    @DeleteMapping(value = "/management/space/workplaces/{workspaceId}")
    public ResponseEntity<?> deleteWorkplace(@PathVariable(value="workspaceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
