package com.koreanair.ksms.ocu.edu.service;

public interface OcuEducationService {
}
