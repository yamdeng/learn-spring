package com.koreanair.ksms.ocu.gen.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.service.OcuLeadingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전경영 - 행동기반안전(BBS)
 */
@Tag(name = "OcuLeading", description = "안전경영 - 행동기반안전(BBS) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuLeadingController {

    @Autowired
    OcuLeadingService service;

    /**
     * BBS활동목표 및 실적 조회(대시보드) 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "BBS활동목표 및 실적 조회(대시보드) 조회", description = "BBS활동목표 및 실적 조회(대시보드) 조회 API")
    @GetMapping(value = "/general/leading-indicator/dashboards")
    public ResponseEntity<?> getDashboardList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 선행지표 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "선행지표 목록 조회", description = "선행지표 목록 조회 API")
    @GetMapping(value = "/general/leading-indicator/precedings")
    public ResponseEntity<?> getPrecedingList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 선행지표 목표 입력(저장)
     *
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "선행지표 목표 입력(저장)", description = "선행지표 목표 입력(저장) API")
    @PostMapping(value = "/general/leading-indicator/precedings/objectives")
    public ResponseEntity<?> insertObjective(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 선행지표 활동 입력(저장)
     *
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "선행지표 활동 입력(저장)", description = "선행지표 활동 입력(저장) API")
    @PostMapping(value = "/general/leading-indicator/precedings/activities")
    public ResponseEntity<?> insertActivity(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }
}
