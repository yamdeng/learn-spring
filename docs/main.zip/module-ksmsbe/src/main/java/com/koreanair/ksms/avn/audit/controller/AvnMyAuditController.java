package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.service.AvnMyAuditService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * AUDIT - 나의 품질심사(My Audit)
 */
@Tag(name = "AvnMyAudit", description = "AUDIT - 나의 품질심사(My Audit) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnMyAuditController {

    @Autowired
    AvnMyAuditService service;

    /**
     * My Audit 현황 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 현황 조회", description = "My Audit 현황 조회 API")
    @GetMapping(value = "/audit/my-audit/0/list/audit-statistics")
    public ResponseEntity<?> getAuditMyAuditStatistics(@RequestParam(value="searchWord", required=false) String searchWord) {
        TBMyAuditStatisticsDto result = service.selectMyAuditStatistics(searchWord);
        return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * My Audit 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "My Audit 목록 조회", description = "My Audit 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/0/list/audit-list")
    public ResponseEntity<?> getAuditMyAuditList(@RequestParam(value="searchWord", required=false) String searchWord) {
        List<TBMyAuditListDto> resultList = service.selectMyAuditList(searchWord);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /**
     * Audit 일괄등록
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 일괄등록", description = "Audit 일괄등록 API")
    @PostMapping(value = "/audit/my-audit/0/list/audit-batch")
    public ResponseEntity<?> insertMyAudit(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Audit 상세조회
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Audit 상세조회", description = "Audit 상세조회 API")
    @GetMapping(value = "/audit/my-audit/0/list/audit/{auditId}")
    public ResponseEntity<?> getMyAuditInfo(@PathVariable(value="auditId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * Plan 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Plan 상세 조회", description = "Plan 상세 조회 API")
    @GetMapping(value = "/audit/my-audit/1/plan/{planId}")
    public ResponseEntity<?> getMyAuditPlanList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "신규 Plan 등록", description = "신규 Plan 등록 API")
    @PostMapping(value = "/audit/my-audit/1/plan")
    public ResponseEntity<?> insertMyAuditPlan(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 정보 수정", description = "Plan 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/1/plan/{planId}")
    public ResponseEntity<?> updateMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {
        dto.setKey(key);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 삭제", description = "Plan 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/1/plan/{planId}")
    public ResponseEntity<?> deleteMyAuditPlan(@PathVariable(value="planId", required=true) String key) {
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Plan 정보 제출", description = "Plan 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/1/plan/submit/{planId}")
    public ResponseEntity<?> submitMyAuditPlan(
            @PathVariable(value="planId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }


    /**
     * Conduct 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Conduct 상세정보 조회", description = "Conduct 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/2/conduct/{auditId}")
    public ResponseEntity<?> getMyAuditConductList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "신규 Conduct 등록", description = "신규 Conduct 등록 API")
    @PostMapping(value = "/audit/my-audit/2/conduct")
    public ResponseEntity<?> insertMyAuditConduct(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 정보 수정", description = "Conduct 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/2/conduct/{auditId}")
    public ResponseEntity<?> updateMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Conduct 삭제", description = "Conduct 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/2/conduct/{auditId}")
    public ResponseEntity<?> deleteMyAuditConduct(@PathVariable(value="conductId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
    @Operation(summary = "Conduct 정보 제출", description = "Conduct 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/2/conduct/submit/{auditId}")
    public ResponseEntity<?> submitMyAuditConduct(
            @PathVariable(value="conductId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * CAR 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "CAR 목록 조회", description = "CAR 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/3/cars")
    public ResponseEntity<?> getMyAuditCARList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "CAR 상세정보 조회", description = "CAR 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/3/cars/{carId}")
    public ResponseEntity<?> getMyAuditCARInfo(@PathVariable(value="carId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 CAR 등록", description = "신규 CAR 등록 API")
    @PostMapping(value = "/audit/my-audit/3/cars/ca")
    public ResponseEntity<?> insertMyAuditCAR(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 정보 수정", description = "CAR 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/3/cars/ca/{carId}")
    public ResponseEntity<?> updateMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "CAR 삭제", description = "CAR 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/3/cars/ca/{carId}")
    public ResponseEntity<?> deleteMyAuditCAR(@PathVariable(value="carId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "신규 Action Taken 등록", description = "신규 CAR 등록 API")
        @PostMapping(value = "/audit/my-audit/3/cars/ac")
        public ResponseEntity<?> insertMyAuditCARAc(@Valid @RequestBody(required=true) GenericDto dto) {

            return ResponseUtil.createSuccessResponse();
        }

        @Operation(summary = "Action Taken 정보 수정", description = "CAR 정보 수정 API")
        @PutMapping(value = "/audit/my-audit/3/cars/ac/{carId}")
        public ResponseEntity<?> updateMyAuditCARAc(
                @PathVariable(value="carId", required=true) String key,
                @Valid @RequestBody(required=true) GenericDto dto) {

            dto.setKey(key);

            return ResponseUtil.createSuccessResponse();
        }

        @Operation(summary = "Action Taken 삭제", description = "CAR 삭제 API")
        @DeleteMapping(value = "/audit/my-audit/3/cars/ac/{carId}")
        public ResponseEntity<?> deleteMyAuditCARAc(@PathVariable(value="carId", required=true) String key) {

            return ResponseUtil.createSuccessResponse();
        }

    @Operation(summary = "CAR 정보 제출", description = "CAR 정보 제출 API")
    @PutMapping(value = "/audit/my-audit/3/cars/submit/{carId}")
    public ResponseEntity<?> submitMyAuditCAR(
            @PathVariable(value="carId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Close 정보 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Close 정보 조회", description = "Close 정보 조회 API")
    @GetMapping(value = "/audit/my-audit/4/close")
    public ResponseEntity<?> getMyAuditCloseList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * Close 공유 등록
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 등록", description = "Close 공유 등록 API")
    @PostMapping(value = "/audit/my-audit/4/close")
    public ResponseEntity<?> insertMyAuditClose(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Close 공유 현황 조회
     * @param key the key
     * @return the deadline manage info
     * @throws Exception the exception
     */
    @Operation(summary = "Close 공유 현황 조회", description = "Close 공유 현황 조회 API")
    @GetMapping(value = "/audit/my-audit/4/close/{closeId}")
    public ResponseEntity<?> getMyAuditCloseInfo(@PathVariable(value="closeId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
