package com.koreanair.ksms.common.utils;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum FieldTypes {

	CAMEL_CASE("nameKo", "nameEn", "empNo"),
	UPPER_SNAKE_CASE("NAME_KOR", "NAME_ENG", "EMP_NO");
	
	private String nameKo;
	private String nameEn;
	private String empNo;
}
