package com.koreanair.ksms.common.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysCodeGroupDto extends CommonDto {

    @NotBlank
    @Size(max=30)
    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
    private String codeGrpId;

    private String workScope;

    @NotBlank
    @Size(max=250)
    private String codeGrpNameKor;

    @NotBlank
    @Size(max=250)
    private String codeGrpNameEng;

    private String useYn;

    @Size(max=512)
    private String remark;
}
