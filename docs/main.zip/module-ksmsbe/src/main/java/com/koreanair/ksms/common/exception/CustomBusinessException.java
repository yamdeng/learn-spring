package com.koreanair.ksms.common.exception;

import com.koreanair.ksms.common.constants.ResponseHeaderCode;
import com.koreanair.ksms.common.constants.StatusCodeConstants;
import lombok.Getter;

public class CustomBusinessException extends RuntimeException {
    private final String message;
    @Getter
    private final String statusCode;
    @Getter
    private final Throwable throwable;
    @Getter
    private final ResponseHeaderCode headerCode;

    public CustomBusinessException(String message, String statusCode, ResponseHeaderCode headerCode) {
        this.message = message;
        this.statusCode = statusCode;
        this.throwable = null;
        this.headerCode = headerCode;
    }

    public CustomBusinessException(String message) {
        this(message, StatusCodeConstants.FAIL, ResponseHeaderCode.UNAVAILABLE_SERVICE);
    }

    public CustomBusinessException(String message, String statusCode) {
        this(message, statusCode, ResponseHeaderCode.UNAVAILABLE_SERVICE);
    }

    public CustomBusinessException(String message, ResponseHeaderCode headerCode) {
        this(message, StatusCodeConstants.FAIL, headerCode);
    }

    public CustomBusinessException(String message, Throwable throwable, ResponseHeaderCode headerCode) {
        this.message = message;
        this.headerCode = headerCode;
        this.statusCode = StatusCodeConstants.FAIL;
        this.throwable = throwable;
    }

    @Override
    public String getMessage() {
        return this.message;
    }

}