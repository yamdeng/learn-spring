package com.koreanair.ksms.common.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnAirports;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysUserCfgDto;
import com.koreanair.ksms.common.dto.TbTbAvnDisplayStatusDto;
import com.koreanair.ksms.common.service.AvnCommonService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 항공안전(AVN)공통 컨트롤러
 */
@Tag(name = "AvnCommon", description = "항공안전 공통 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn/common")
public class AvnCommonController {

    @Autowired
    AvnCommonService service;

    @Operation(summary = "보고서 단계별 상태구분 목록 조회", description = "보고서 단계별 상태구분 목록 조회")
    @GetMapping(value = "/page_code/{pageCode}/state")
    public ResponseEntity<?> getPageCodeList(@PathVariable(value="pageCode", required=true) String pageCode) {

        List<TbTbAvnDisplayStatusDto> resultList = service.selectPageCodeList(pageCode);
        return ResponseUtil.createSuccessResponse(resultList);
    }

//    @Parameter(description = "keyword")
    @Operation(summary = "공항 목록 조회", description = "공항 목록 조회")
    @GetMapping(value = "/airports")
    public ResponseEntity<?> getAirportList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String keyword) {

        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbAvnAirports> resultList = service.selectAirportList(keyword);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "개인별 환경설정 항목 조회", description = "개인별 환경설정 항목 조회 API")
    @GetMapping(value = "/user-cfg")
    public ResponseEntity<?> getUserCfg() {

        TbSysUserCfgDto result = service.selectUserCfg();

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "개인별 환경설정 항목 저장", description = "개인별 환경설정 항목 저장 API")
    @PostMapping(value = "/user-cfg")
    public ResponseEntity<?> saveUserCfg(@Valid @RequestBody TbSysUserCfgDto dto) {

        service.saveUserCfg(dto);

        return ResponseUtil.createSuccessResponse();
    }
}
