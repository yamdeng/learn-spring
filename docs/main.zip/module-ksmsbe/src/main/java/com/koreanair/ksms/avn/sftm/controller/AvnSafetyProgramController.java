package com.koreanair.ksms.avn.sftm.controller;

import com.koreanair.ksms.avn.sftm.service.AvnSafetyProgramService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전증진 - Safety Program
 */
@Tag(name = "AvnSafetyProgram", description = "안전증진 - Safety Program API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSafetyProgramController {

    @Autowired
    AvnSafetyProgramService service;

    /**
     * Excellence 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Excellence 목록 조회", description = "Excellence 목록 조회 API")
    @GetMapping(value = "/promotion/program/excellences")
    public ResponseEntity<?> getExcellenceList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Excellence 상세정보 조회", description = "Excellence 상세정보 조회 API")
    @GetMapping(value = "/promotion/program/excellences/{excellenceId}")
    public ResponseEntity<?> getExcellenceInfo(@PathVariable(value="excellenceId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * WorkShop 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "WorkShop 목록 조회", description = "WorkShop 목록 조회 API")
    @GetMapping(value = "/promotion/program/workshops")
    public ResponseEntity<?> getWorkShopList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "WorkShop 상세정보 조회", description = "WorkShop 상세정보 조회 API")
    @GetMapping(value = "/promotion/program/workshops/{workshopId}")
    public ResponseEntity<?> getWorkShopInfo(@PathVariable(value="reportLimitId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * Safety Day 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Safety Day 목록 조회", description = "Safety Day 목록 조회 API")
    @GetMapping(value = "/promotion/program/safety-days")
    public ResponseEntity<?> getSafetyDayList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Safety Day 상세정보 조회", description = "Safety Day 상세정보 조회 API")
    @GetMapping(value = "/promotion/program/safety-days/{safetyDayId}")
    public ResponseEntity<?> getSafetyDayInfo(@PathVariable(value="safetyDayId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * SPIP 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "SPIP 목록 조회", description = "SPIP 목록 조회 API")
    @GetMapping(value = "/promotion/program/spips")
    public ResponseEntity<?> getSpipList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "SPIP 상세정보 조회", description = "SPIP 상세정보 조회 API")
    @GetMapping(value = "/promotion/program/spips/{spipId}")
    public ResponseEntity<?> getSpipInfo(@PathVariable(value="spipId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
