package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.RiskAssessmentVo;

public interface AvnReportRiskAssessmentService {
    RiskAssessmentVo selectReportRiskAssessment(ReportInfoDto reportDetailDto);
}
