package com.koreanair.ksms.ocu.insp.service;

public interface OcuJointService {
}
