package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.ReceiptVo;
import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.SmReport;

public interface AvnReportReceiptService {

    SmReport selectReportDetail(int groupId);

    ReceiptVo selectReportReceipt(ReportInfoDto reportInfoDto);

    //접수 Insert
    Integer insertReceiptDetail(ReceiptVo parameter) throws Exception;

    //접수 Update
    void updateReceiptDetail(ReceiptVo parameter) throws Exception;

    void updateReceiptAt(int receiptId) throws Exception;

    //void editReceiptDetail (@Valid ReceiptDto.PATCH_Request parameter, @RequestAttribute("sessionInfo") JsonObject sessionInfo) throws Exception;
}
