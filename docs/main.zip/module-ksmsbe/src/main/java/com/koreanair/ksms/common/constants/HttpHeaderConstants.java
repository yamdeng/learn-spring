package com.koreanair.ksms.common.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class HttpHeaderConstants {

    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
    public static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
    public static final String ACCESS_CONTROL_ALLOW_HEADERS = "Access-Control-Allow-Headers";
    public static final String ACCEPT = "Accept";
    public static final String ORIGIN = "Origin";
    public static final String CONTENT_TYPE_KEY = "Content-Type";
    public static final String CONTENT_LENGTH = "Content-Length";
    public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    public static final String CHARSET_UTF8 = "charset=UTF-8";
    public static final String CONTENTS_TYPE_JSON = "application/json";
    public static final String CONTENTS_TYPE_MULTIPART = "multipart/form-data";

    public static final String X_SESSION_ID = "x-session-id";
    public static final String X_CORRELATION_ID = "x-correlation-id";

    public static final String SOAP_ACTION = "SOAPAction";
    public static final String X_FORWARDED_FOR = "X-Forwarded-For";
}