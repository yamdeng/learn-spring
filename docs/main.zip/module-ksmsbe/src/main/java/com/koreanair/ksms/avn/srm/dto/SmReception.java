package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "보고서 접수 입력 항목")
public class SmReception {
    @Schema(description = "ID")
    @NotNull
    private int id;

    @Schema(description = "GROUP ID")
    @NotNull
    private int groupId;

    @Schema(description = "REPORT ID")
    @NotNull
    private int reportId;

    @Schema(description = "사원ID")
    @NotNull
    private String empNo;

    @Schema(description = "ATA_adapter 유형")
    @NotNull
    private String ataAdapterType;

    @Schema(description = "Event Follow Up")
    private String eventFollowup;

    @Schema(description = "규제당국, code_group='Control Dept'")
    private String controlDeptType;

    @Schema(description = "Event Summary(영문)")
    private String eventSummary;

    @Schema(description = "보고항목 구분, code_group='Investigation Classification'")
    @NotNull
    private String classification;

    @Schema(description = "SPI 지표 포함 여부")
    private String isSpi;

    @Schema(description = "MSR - ASMR여부")
    private String isAsmr;

    @Schema(description = "제출시한일자")
    private String dueDate;

    @Schema(description = "추가 카테고리(CSR)")
    private String addCategory;

    @Schema(description = "지상사고 여부(GSR)")
    private String isGroundAccident;

    @Schema(description = "항공Hzd여부(HZD)")
    private String isAvnHzd;

    @Schema(description = "산업Hzd여부(HZD)")
    private String isOcuHzd;

    @Schema(description = "안전Hzd여부(HZD)")
    private String isSftyHzd ;

    private Timestamp deletedAt;

    private String timezone;

    private String reason;
}
