package com.koreanair.ksms.ocu.insp.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.insp.service.OcuWalkaroundService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전점검 - 작업장순회점검
 */
@Tag(name = "OcuWalkaround", description = "안전점검 - 작업장순회점검 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuWalkaroundController {

    @Autowired
    OcuWalkaroundService service;

    /**
     * 작업장순회점검 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "작업장순회점검 목록 조회", description = "작업장순회점검 목록 조회 API")
    @GetMapping(value = "/inspection/walk-arounds")
    public ResponseEntity<?> getWorkAroundList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "작업장순회점검 상세정보 조회", description = "작업장순회점검 상세정보 조회 API")
    @GetMapping(value = "/inspection/walk-arounds/{workAroundId}")
    public ResponseEntity<?> getWorkAroundInfo(@PathVariable(value="workAroundId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 작업장순회점검 등록", description = "신규 작업장순회점검 등록 API")
    @PostMapping(value = "/inspection/walk-arounds")
    public ResponseEntity<?> insertWorkAround(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 정보 수정", description = "작업장순회점검 정보 수정 API")
    @PutMapping(value = "/inspection/walk-arounds/{workAroundId}")
    public ResponseEntity<?> updateWorkAround(
            @PathVariable(value="workAroundId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 삭제", description = "작업장순회점검 삭제 API")
    @DeleteMapping(value = "/inspection/walk-arounds/{workAroundId}")
    public ResponseEntity<?> deleteWorkAround(@PathVariable(value="workAroundId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 작업장순회점검 결제처리
     *
     * @param key the key
     * @param dto the dto
     * @return the response entity
     * @throws Exception the exception
     */
    @Operation(summary = "작업장순회점검 결제처리", description = "작업장순회점검 결제처리 API")
    @PostMapping(value = "/inspection/walk-arounds/approval/{workAroundId}")
    public ResponseEntity<?> approvalWorkAround(
            @PathVariable(value="workAroundId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }
}
