package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_MSR")
public class TbAvnReportMsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드")
    @NotBlank
    private String reportDtlTypeCd;
    
    @Schema(description = "MSR유형코드")
    private String msrTypeCd;
    
    @Schema(description = "MSR이벤트유형코드")
    private String msrEventTypeCd;
    
    @Schema(description = "MSR카테고리코드")
    private String msrCategoryCd;
}
