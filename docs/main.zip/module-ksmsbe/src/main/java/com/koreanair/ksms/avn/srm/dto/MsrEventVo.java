package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "접수 - MSR정보")
public class MsrEventVo extends SmMsrEvent {
    private String title;

    private String descr;

    private String categoryNameKo;

    private String categoryNameEn;

    //private List<SmEventPart> eventParts;

    private String eventCodeNameKo;

    private String eventCodeNameEn;

    //private List<PoFileVo> attachment;

}
