package com.koreanair.ksms.ocu.insp.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.insp.dto.*;
import com.koreanair.ksms.ocu.insp.service.OcuInspectionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전점검 - 작업장/합동/반기/비정기 점검 및 개선 관리
 */
@Tag(name = "OcuInspection", description = "안전점검 - 작업장/합동/반기/비정기 점검 및 개선 관리")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuInspectionController {

    @Autowired
    private OcuInspectionService OcuInspectionService;

    @Operation(summary = "점검표 상세 조회", description = "점검표 상세 조회 API")
    @GetMapping("/inspection/checklist/{id}")
    public ResponseEntity<?> selectOcuChecklist(@PathVariable(value="id", required=false) int id) {

        OcuChecklistDto result = OcuInspectionService.selectOcuChecklist(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "점검표 목록 조회", description = "점검표 목록 조회 API")
    @GetMapping("/inspection/checklist")
    public ResponseEntity<?> getDeptList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuChecklistDto paramDto = new OcuChecklistDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuChecklistDto> pageList = OcuInspectionService.selectOcuChecklistList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "점검표 일괄 저장", description = "점검표 일괄 저장 API")
    @PostMapping("/inspection/checklist/bulk")
    public ResponseEntity<?> saveOcuChecklist(@RequestBody List<OcuChecklistDto> reqDtoList) {

        OcuInspectionService.saveOcuChecklist(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 등록", description = "점검표 등록 API")
    @PostMapping(value = "/inspection/checklist")
    public ResponseEntity<?> insertOcuChecklist(@Valid @RequestBody() OcuChecklistDto reqDto){

        OcuInspectionService.insertOcuChecklist(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 수정", description = "점검표 수정 API")
    @PutMapping(value = "/inspection/checklist")
    public ResponseEntity<?> updateOcuChecklist(@Valid @RequestBody(required=true) OcuChecklistDto reqDto){

        OcuInspectionService.updateOcuChecklist(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 삭제", description = "점검표 삭제 API")
    @DeleteMapping(value = "/inspection/checklist/{id}")
    public ResponseEntity<?> deleteOcuChecklist(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuChecklist(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 항목 상세 조회", description = "점검표 항목 상세 조회 API")
    @GetMapping("/inspection/checklist/item/{id}")
    public ResponseEntity<?> selectOcuChecklistItem(@PathVariable(value="id", required=true) int id) {

        OcuChecklistItemDto result = OcuInspectionService.selectOcuChecklistItem(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "점검표 항목 목록 조회", description = "점검표 항목 목록 조회 API")
    @GetMapping("/inspection/checklist/item")
    public ResponseEntity<?> selectOcuChecklistItemList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuChecklistItemDto paramDto = new OcuChecklistItemDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuChecklistItemDto> pageList = OcuInspectionService.selectOcuChecklistItemList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "점검표 항목 일괄 저장", description = "점검표 항목 일괄 저장 API")
    @PostMapping("/inspection/checklist/item/bulk")
    public ResponseEntity<?> saveOcuChecklistItem(@RequestBody List<OcuChecklistItemDto> reqDtoList) {

        OcuInspectionService.saveOcuChecklistItem(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 항목 등록", description = "점검표 항목 등록 API")
    @PostMapping(value = "/inspection/checklist/item")
    public ResponseEntity<?> insertOcuChecklistItem(@Valid @RequestBody(required=true) OcuChecklistItemDto reqDto){

        OcuInspectionService.insertOcuChecklistItem(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 항목 수정", description = "점검표 항목 수정 API")
    @PutMapping(value = "/inspection/checklist/item")
    public ResponseEntity<?> updateOcuChecklistItem(@Valid @RequestBody(required=true) OcuChecklistItemDto reqDto){

        OcuInspectionService.updateOcuChecklistItem(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 항목 삭제", description = "점검표 항목 삭제 API")
    @DeleteMapping(value = "/inspection/checklist/item/{id}")
    public ResponseEntity<?> deleteOcuChecklistItem(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuChecklistItem(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 사업장 상세 조회", description = "점검표 사업장 상세 조회 API")
    @GetMapping("/inspection/checklist/place/{id}")
    public ResponseEntity<?> selectOcuChecklistPlace(@PathVariable(value="id", required=true) int id) {

        OcuChecklistPlaceDto result = OcuInspectionService.selectOcuChecklistPlace(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "점검표 사업장 목록 조회", description = "점검표 사업장 목록 조회 API")
    @GetMapping("/inspection/checklist/place")
    public ResponseEntity<?> selectOcuChecklistPlaceList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuChecklistPlaceDto paramDto = new OcuChecklistPlaceDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuChecklistPlaceDto> pageList = OcuInspectionService.selectOcuChecklistPlaceList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "점검표 사업장 일괄 저장", description = "점검표 사업장 일괄 저장 API")
    @PostMapping("/inspection/checklist/place/bulk")
    public ResponseEntity<?> saveOcuChecklistPlace(@RequestBody List<OcuChecklistPlaceDto> reqDtoList) {

        OcuInspectionService.saveOcuChecklistPlace(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 사업장 등록", description = "점검표 사업장 등록 API")
    @PostMapping(value = "/inspection/checklist/place")
    public ResponseEntity<?> insertOcuChecklistPlace(@Valid @RequestBody(required=true) OcuChecklistPlaceDto reqDto){

        OcuInspectionService.insertOcuChecklistPlace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 사업장 수정", description = "점검표 사업장 수정 API")
    @PutMapping(value = "/inspection/checklist/place")
    public ResponseEntity<?> updateOcuChecklistPlace(@Valid @RequestBody(required=true) OcuChecklistPlaceDto reqDto){

        OcuInspectionService.updateOcuChecklistPlace(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검표 사업장 삭제", description = "점검표 사업장 삭제 API")
    @DeleteMapping(value = "/inspection/checklist/place/{id}")
    public ResponseEntity<?> deleteOcuChecklistPlace(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuChecklistPlace(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 상세 조회", description = "작업장순회점검 상세 조회 API")
    @GetMapping("/inspection/walkAround/{id}")
    public ResponseEntity<?> selectOcuWalkaround(@PathVariable(value="id", required=true) int id) {

        OcuWalkaroundDto result = OcuInspectionService.selectOcuWalkaround(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "작업장순회점검 목록 조회", description = "작업장순회점검 목록 조회 API")
    @GetMapping("/inspection/walkAround")
    public ResponseEntity<?> selectOcuWalkaroundList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuWalkaroundDto paramDto = new OcuWalkaroundDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuWalkaroundDto> pageList = OcuInspectionService.selectOcuWalkaroundList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "작업장순회점검 일괄 저장", description = "작업장순회점검 일괄 저장 API")
    @PostMapping("/inspection/walkAround/bulk")
    public ResponseEntity<?> saveOcuWalkaround(@RequestBody List<OcuWalkaroundDto> reqDtoList) {

        OcuInspectionService.saveOcuWalkaround(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 등록", description = "작업장순회점검 등록 API")
    @PostMapping(value = "/inspection/walkAround")
    public ResponseEntity<?> insertOcuWalkaround(@Valid @RequestBody(required=true) OcuWalkaroundDto reqDto){

        OcuInspectionService.insertOcuWalkaround(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 수정", description = "작업장순회점검 수정 API")
    @PutMapping(value = "/inspection/walkAround")
    public ResponseEntity<?> updateOcuWalkaround(@Valid @RequestBody(required=true) OcuWalkaroundDto reqDto){

        OcuInspectionService.updateOcuWalkaround(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 삭제", description = "작업장순회점검 삭제 API")
    @DeleteMapping(value = "/inspection/walkAround/{id}")
    public ResponseEntity<?> deleteOcuWalkaround(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuWalkaround(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검_내용 상세 조회", description = "작업장순회점검_내용 상세 조회 API")
    @GetMapping("/inspection/walkAround/content/{id}")
    public ResponseEntity<?> selectOcuWalkaroundCont(@PathVariable(value="id", required=true) int id) {

        OcuWalkaroundContDto result = OcuInspectionService.selectOcuWalkaroundCont(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "작업장순회점검_내용 목록 조회", description = "작업장순회점검_내용 목록 조회 API")
    @GetMapping("/inspection/walkAround/content")
    public ResponseEntity<?> selectOcuWalkaroundContList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuWalkaroundContDto paramDto = new OcuWalkaroundContDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuWalkaroundContDto> pageList = OcuInspectionService.selectOcuWalkaroundContList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "작업장순회점검_내용 일괄 저장", description = "작업장순회점검_내용 일괄 저장 API")
    @PostMapping("/inspection/walkAround/content/bulk")
    public ResponseEntity<?> saveOcuWalkaroundCont(@RequestBody List<OcuWalkaroundContDto> reqDtoList) {

        OcuInspectionService.saveOcuWalkaroundCont(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검_내용 등록", description = "작업장순회점검_내용 등록 API")
    @PostMapping(value = "/inspection/walkAround/content")
    public ResponseEntity<?> insertOcuWalkaroundCont(@Valid @RequestBody(required=true) OcuWalkaroundContDto reqDto){

        OcuInspectionService.insertOcuWalkaroundCont(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검_내용 수정", description = "작업장순회점검_내용 수정 API")
    @PutMapping(value = "/inspection/walkAround/content")
    public ResponseEntity<?> updateOcuWalkaroundCont(@Valid @RequestBody(required=true) OcuWalkaroundContDto reqDto){

        OcuInspectionService.updateOcuWalkaroundCont(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검_내용 삭제", description = "작업장순회점검_내용 삭제 API")
    @DeleteMapping(value = "/inspection/walkAround/content/{id}")
    public ResponseEntity<?> deleteOcuWalkaroundCont(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuWalkaroundCont(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 대상 상세 조회", description = "작업장순회점검 대상 상세 조회 API")
    @GetMapping("/inspection/walkAround/target/{id}")
    public ResponseEntity<?> selectOcuWalkaroundCheck(@PathVariable(value="id", required=true) int id) {

        OcuWalkaroundCheckDto result = OcuInspectionService.selectOcuWalkaroundCheck(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "작업장순회점검 대상 목록 조회", description = "작업장순회점검 대상 목록 조회 API")
    @GetMapping("/inspection/walkAround/target")
    public ResponseEntity<?> selectOcuWalkaroundCheckList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuWalkaroundCheckDto paramDto = new OcuWalkaroundCheckDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuWalkaroundCheckDto> pageList = OcuInspectionService.selectOcuWalkaroundCheckList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "작업장순회점검 대상 일괄 저장", description = "작업장순회점검 대상 일괄 저장 API")
    @PostMapping("/inspection/walkAround/target/bulk")
    public ResponseEntity<?> saveOcuWalkaroundCheck(@RequestBody List<OcuWalkaroundCheckDto> reqDtoList) {

        OcuInspectionService.saveOcuWalkaroundCheck(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 대상 등록", description = "작업장순회점검 대상 등록 API")
    @PostMapping(value = "/inspection/walkAround/target")
    public ResponseEntity<?> insertOcuWalkaroundCheck(@Valid @RequestBody(required=true) OcuWalkaroundCheckDto reqDto){

        OcuInspectionService.insertOcuWalkaroundCheck(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 대상 수정", description = "작업장순회점검 대상 수정 API")
    @PutMapping(value = "/inspection/walkAround/target")
    public ResponseEntity<?> updateOcuWalkaroundCheck(@Valid @RequestBody(required=true) OcuWalkaroundCheckDto reqDto){

        OcuInspectionService.updateOcuWalkaroundCheck(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "작업장순회점검 대상 삭제", description = "작업장순회점검 대상 삭제 API")
    @DeleteMapping(value = "/inspection/walkAround/target/{id}")
    public ResponseEntity<?> deleteOcuWalkaroundCheck(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuWalkaroundCheck(id);
        return ResponseUtil.createSuccessResponse();
    }


    @Operation(summary = "점검 상세 조회", description = "점검 상세 조회 API")
    @GetMapping("/inspection/periodic/{id}")
    public ResponseEntity<?> selectOcuPeriodic(@PathVariable(value="id", required=true) int id) {

        OcuPeriodicDto result = OcuInspectionService.selectOcuPeriodic(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "점검 목록 조회", description = "점검 목록 조회 API")
    @GetMapping("/inspection/periodic")
    public ResponseEntity<?> selectOcuPeriodicList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuPeriodicDto paramDto = new OcuPeriodicDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuPeriodicDto> pageList = OcuInspectionService.selectOcuPeriodicList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "점검 일괄 저장", description = "점검 일괄 저장 API")
    @PostMapping("/inspection/periodic/bulk")
    public ResponseEntity<?> saveOcuPeriodic(@RequestBody List<OcuPeriodicDto> reqDtoList) {

        OcuInspectionService.saveOcuPeriodic(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검 등록", description = "점검 등록 API")
    @PostMapping(value = "/inspection/periodic")
    public ResponseEntity<?> insertOcuPeriodic(@Valid @RequestBody(required=true) OcuPeriodicDto reqDto){

        OcuInspectionService.insertOcuPeriodic(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검 수정", description = "점검 수정 API")
    @PutMapping(value = "/inspection/periodic")
    public ResponseEntity<?> updateOcuPeriodic(@Valid @RequestBody(required=true) OcuPeriodicDto reqDto){

        OcuInspectionService.updateOcuPeriodic(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검 삭제", description = "점검 삭제 API")
    @DeleteMapping(value = "/inspection/periodic/{id}")
    public ResponseEntity<?> deleteOcuPeriodic(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuPeriodic(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검_내용 상세 조회", description = "점검_내용 상세 조회 API")
    @GetMapping("/inspection/periodic/content/{id}")
    public ResponseEntity<?> selectOcuPeriodicCont(@PathVariable(value="id", required=true) int id) {

        OcuPeriodicContDto result = OcuInspectionService.selectOcuPeriodicCont(id);
        return ResponseUtil.createSuccessResponse(result);

    }

    @Operation(summary = "점검_내용 목록 조회", description = "점검_내용 목록 조회 API")
    @GetMapping("/inspection/periodic/content")
    public ResponseEntity<?> selectOcuPeriodicContList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuPeriodicContDto paramDto = new OcuPeriodicContDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuPeriodicContDto> pageList = OcuInspectionService.selectOcuPeriodicContList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "점검_내용 일괄 저장", description = "점검_내용 일괄 저장 API")
    @PostMapping("/inspection/periodic/content/bulk")
    public ResponseEntity<?> saveOcuPeriodicCont(@RequestBody List<OcuPeriodicContDto> reqDtoList) {

        OcuInspectionService.saveOcuPeriodicCont(reqDtoList);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검_내용 등록", description = "점검_내용 등록 API")
    @PostMapping(value = "/inspection/periodic/content")
    public ResponseEntity<?> insertOcuPeriodicCont(@Valid @RequestBody(required=true) OcuPeriodicContDto reqDto){

        OcuInspectionService.insertOcuPeriodicCont(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검_내용 수정", description = "점검_내용 수정 API")
    @PutMapping(value = "/inspection/periodic/content")
    public ResponseEntity<?> updateOcuPeriodicCont(@Valid @RequestBody(required=true) OcuPeriodicContDto reqDto){

        OcuInspectionService.updateOcuPeriodicCont(reqDto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "점검_내용 삭제", description = "점검_내용 삭제 API")
    @DeleteMapping(value = "/inspection/periodic/content/{id}")
    public ResponseEntity<?> deleteOcuPeriodicCont(@PathVariable(value="id", required=true) int id){
        OcuInspectionService.deleteOcuPeriodicCont(id);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "통합개선 목록 조회", description = "통합개선 목록 조회 API")
    @GetMapping("/inspection/correction")
    public ResponseEntity<?> selectOcuCorrectionList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize){

        OcuCorrectionDto paramDto = new OcuCorrectionDto();

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<OcuCorrectionDto> pageList = OcuInspectionService.selectOcuCorrectionList(paramDto);
        return ResponseUtil.createSuccessResponse(pageList);
    }
}
