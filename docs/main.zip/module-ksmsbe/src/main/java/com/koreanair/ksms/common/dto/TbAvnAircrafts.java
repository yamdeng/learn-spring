package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString

public class TbAvnAircrafts{

    @Schema(description = "ID")
    private int id;

    @Schema(description = "공항코드, 대문자")
    private String fleetCode;

    @Schema(description = "Aircraft Type")
    private String aircraftType;

    @Schema(description = "표시순서, -1은 표시하지 않음. 0부터 시작")
    private String viewOrder;

    @Schema(description = "활성/비활성화 상태")
    private int state;

}



