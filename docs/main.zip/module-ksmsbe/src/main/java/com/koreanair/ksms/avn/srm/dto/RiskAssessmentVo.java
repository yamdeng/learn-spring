package com.koreanair.ksms.avn.srm.dto;

import lombok.*;

import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class RiskAssessmentVo extends SmReport {
    private String linkUrl;
    private List<SmReportHazardVo> reportHazardList;
    private List<SmReportHazardVo> deleteList;
    private boolean isLeader;

    private boolean visibleNote = true;

    private List<PoFileVo> attachment;
    private String earNo;
    private String isHf;

}