package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class AvnSafetyInvestigationDto {

    @Schema(description = "ID")
    private String id;

    @Schema(description = "")
    private String reportNo;

    @Schema(description = "")
    private String reportTitle;

    @Schema(description = "")
    private String departureAt;

    @Schema(description = "")
    private String flightNo;

    @Schema(description = "")
    private String aircraftTypeText;

    @Schema(description = "")
    private String fromAirport;

    @Schema(description = "")
    private String toAirport;

    @Schema(description = "")
    private String registrationNo;

    @Schema(description = "")
    private String supply;

    @Schema(description = "")
    private String checkIn;

    @Schema(description = "")
    private String locationText;

    @Schema(description = "")
    private String airport;

    @Schema(description = "")
    private String flightPhase;

    @Schema(description = "")
    private String empNo;

    @Schema(description = "")
    private String eventAt;

    @Schema(description = "")
    private String eventAtTz;

    @Schema(description = "")
    private String operationType;

    @Schema(description = "")
    private String investigationType;

    @Schema(description = "")
    private String isSpi;

    @Schema(description = "")
    private String classification;

    @Schema(description = "")
    private String regDttm;

    @Schema(description = "")
    private String updDttm;

    @Schema(description = "")
    private String deletedAt;

    @Schema(description = "")
    private String weatherText;

    @Schema(description = "")
    private String divertAirport;

    @Schema(description = "")
    private String isSubmitted;

    @Schema(description = "")
    private String submittedAt;

    @Schema(description = "")
    private String investigateBy;

    @Schema(description = "")
    private String submittedBy;

    @Schema(description = "")
    private String approvedId;

    @Schema(description = "")
    private String flightPhaseTextKo;

    @Schema(description = "")
    private String flightPhaseTextEn;

    @Schema(description = "")
    private String operationTypeTextKo;

    @Schema(description = "")
    private String operationTypeTextEn;

    @Schema(description = "")
    private String investigationTypeTextKo;

    @Schema(description = "")
    private String investigationTypeTextEn;

    @Schema(description = "")
    private String classificationTextKo;

    @Schema(description = "")
    private String classificationTextEn;

    @Schema(description = "")
    private String submittedByTextKo;

    @Schema(description = "")
    private String submittedByTextEn;

    @Schema(description = "")
    private String phase;

    @Schema(description = "")
    private String stepCode;

    @Schema(description = "")
    private String statusKo;

    @Schema(description = "")
    private String statusEn;

    @Schema(description = "")
    private String reason;

    @Schema(description = "")
    private String caApprovedBy;

    @Schema(description = "")
    private String closedAt;

    @Schema(description = "")
    private String caListCount;

    @Schema(description = "")
    private String caSafetyListCount;

    @Schema(description = "")
    private String eventId;

    @Schema(description = "")
    private String eventName;


}
