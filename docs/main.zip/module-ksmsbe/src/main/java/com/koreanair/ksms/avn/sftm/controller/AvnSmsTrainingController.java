package com.koreanair.ksms.avn.sftm.controller;

import com.koreanair.ksms.avn.sftm.service.AvnSmsTrainingService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전증진 - SMS교육
 */
@Tag(name = "AvnSmsTraining", description = "안전증진 - SMS교육 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnSmsTrainingController {

    @Autowired
    AvnSmsTrainingService service;

    /**
     * 자료실 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "자료실 목록 조회", description = "자료실 목록 조회 API")
    @GetMapping(value = "/promotion/sms/bulletins")
    public ResponseEntity<?> getBulletinList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "자료실 상세정보 조회", description = "자료실 상세정보 조회 API")
    @GetMapping(value = "/promotion/sms/bulletins/{bulletinId}")
    public ResponseEntity<?> getBulletinInfo(@PathVariable(value="bulletinId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    /**
     * 강사현황 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "강사현황 목록 조회", description = "강사현황 목록 조회 API")
    @GetMapping(value = "/promotion/sms/instructors")
    public ResponseEntity<?> getInstructorList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "강사현황 상세정보 조회", description = "강사현황 상세정보 조회 API")
    @GetMapping(value = "/promotion/sms/instructors/{instructorId}")
    public ResponseEntity<?> getInstructorInfo(@PathVariable(value="instructorId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }
}
