package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartner2ndInfoDto;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerPlaceDto;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuPartnerDto;

@Service
public class OcuPartnerServiceImpl extends AbstractBaseService implements OcuPartnerService {

    public OcuPartnerDto selectOcuPartner(int id) {
        return commonSql.selectOne("OcuPartner.selectOcuPartner", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuPartnerDto> selectOcuPartnerList(OcuPartnerDto dto) {
        List<OcuPartnerDto> resultList = commonSql.selectList("OcuPartner.selectOcuPartnerList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuPartner(OcuPartnerDto dto) {
        commonSql.insert("OcuPartner.insertOcuPartner", dto);
    }

    @Override
    public void updateOcuPartner(OcuPartnerDto dto) {
        commonSql.update("OcuPartner.updateOcuPartner", dto);
    }

    @Override
    public void deleteOcuPartner(int id) {
        commonSql.delete("OcuPartner.deleteOcuPartner", id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuPartner(List<OcuPartnerDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuPartner", mapList);
    }

    public OcuPartnerPlaceDto selectOcuPartnerPlace(int id) {
        return commonSql.selectOne("OcuPartner.selectOcuPartnerPlace", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuPartnerPlaceDto> selectOcuPartnerPlaceList(OcuPartnerPlaceDto dto) {
        List<OcuPartnerPlaceDto> resultList = commonSql.selectList("OcuPartner.selectOcuPartnerPlaceList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuPartnerPlace(OcuPartnerPlaceDto dto) {
        commonSql.insert("OcuPartner.insertOcuPartnerPlace", dto);
    }

    @Override
    public void updateOcuPartnerPlace(OcuPartnerPlaceDto dto) {
        commonSql.update("OcuPartner.updateOcuPartnerPlace", dto);
    }

    @Override
    public void deleteOcuPartnerPlace(int id) {
        commonSql.delete("OcuPartner.deleteOcuPartnerPlace", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuPartnerPlace(List<OcuPartnerPlaceDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuPartnerPlace", mapList);
    }

    public OcuPartner2ndInfoDto selectOcuPartner2ndInfo(int id) {
        return commonSql.selectOne("OcuPartner.selectOcuPartner2ndInfo", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuPartner2ndInfoDto> selectOcuPartner2ndInfoList(OcuPartner2ndInfoDto dto) {
        List<OcuPartner2ndInfoDto> resultList = commonSql.selectList("OcuPartner.selectOcuPartner2ndInfoList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuPartner2ndInfo(OcuPartner2ndInfoDto dto) {
        commonSql.insert("OcuPartner.insertOcuPartner2ndInfo", dto);
    }

    @Override
    public void updateOcuPartner2ndInfo(OcuPartner2ndInfoDto dto) {
        commonSql.update("OcuPartner.updateOcuPartner2ndInfo", dto);
    }

    @Override
    public void deleteOcuPartner2ndInfo(int id) {
        commonSql.delete("OcuPartner.deleteOcuPartner2ndInfo", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuPartner2ndInfo(List<OcuPartner2ndInfoDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuPartner2ndInfo", mapList);
    }
}
