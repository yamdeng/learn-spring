package com.koreanair.ksms.ocu.gen.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuNoticeDto;

import jakarta.validation.Valid;

/**
 * 공지사항 Service 
 */
public interface OcuNoticeService {

	/**
	 * 공지사항 목록 조회
	 * @param dto
	 * @return
	 */
	public PageInfo<OcuNoticeDto> selectGetNoticeList(OcuNoticeDto dto);

	/**
	 * 공지사항 상세 조회
	 * @param noticeId
	 * @return
	 */
	public OcuNoticeDto getNoticeInfo(int noticeId);

	/**
	 * 공지사항 입력
	 * @param dto
	 */
	public void insertNotice(@Valid OcuNoticeDto dto);

	/**
	 * 공지사항 수정
	 * @param dto
	 */
	public void updateNotice(@Valid OcuNoticeDto dto);

	/**
	 * 공지사항 삭제
	 * @param noticeId
	 */
	public void deleteNotice(int noticeId);
}
