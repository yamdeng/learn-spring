package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_CSR_상세정보")
public class TbAvnReportCsrDtlInfoDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "ID")
    @NotBlank
    private int id;
    
    @Schema(description = "레포트상세정보유형코드")
    private String reportDtlInfoTypeCd;
    
    @Schema(description = "사원번호")
    private String empNo;
    
    @Schema(description = "관련자코드")
    private String involveCd;
    
    @Schema(description = "승객명")
    private String paxNm;
    
    @Schema(description = "성별코드")
    private String genderCd;
    
    @Schema(description = "나이수")
    private int ageCo;
    
    @Schema(description = "국가코드")
    private String nationCd;
    
    @Schema(description = "좌석명")
    private String seatNm;
    
    @Schema(description = "은닉발견좌석코드")
    private String hiddenFindSeatCd;
    
    @Schema(description = "은닉발견장소코드")
    private String hiddenFindPlaceCd;



    @Builder
    public TbAvnReportCsrDtlInfoDto(

            Integer reportId,
            Integer id,
            String reportDtlInfoTypeCd,
            String empNo,
            String involveCd,
            String paxNm,
            String genderCd,
            Integer ageCo,
            String nationCd,
            String seatNm,
            String hiddenFindSeatCd,
            String hiddenFindPlaceCd



            ) {
        this.reportId = reportId == null ? 0 : reportId;
        this.id = id == null ? 0 : id;
        this.reportDtlInfoTypeCd = reportDtlInfoTypeCd;
        this.empNo = empNo;
        this.involveCd = involveCd;
        this.paxNm = paxNm;
        this.genderCd = genderCd;
        this.ageCo = ageCo == null ? 0 : ageCo;
        this.nationCd = nationCd;
        this.seatNm = seatNm;
        this.hiddenFindSeatCd = hiddenFindSeatCd;
        this.hiddenFindPlaceCd = hiddenFindPlaceCd;
    }

}
