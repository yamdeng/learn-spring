package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트_GSR")
public class TbAvnReportGsrDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "레포트상세유형코드")
    @NotBlank
    private String reportDtlTypeCd;
    
    @Schema(description = "발견신고코드")
    private String findNotifyCd;
    
    @Schema(description = "발견유형코드")
    private String findTypeCd;
    
    @Schema(description = "발생위치코드")
    private String occurLocationCd;
    
    @Schema(description = "운영단계코드")
    private String operationPhaseCd;
    
    @Schema(description = "램프조작코드")
    private String rampHandlingCd;
    
    @Schema(description = "항공기손상원인코드")
    private String aircraftDamageCauseCd;
    
    @Schema(description = "램프상태코드")
    private String rampStatusCd;
    
    @Schema(description = "날씨코드배열")
    private String weatherCdarr;
    
    @Schema(description = "부상여부")
    @NotBlank
    private String injuryYn;
    
    @Schema(description = "부상내용")
    private String injuryCn;
    
    @Schema(description = "조치사항내용")
    private String carCn;
    
    @Schema(description = "점검종류코드")
    private String checkKindCd;
    
    @Schema(description = "규제기관코드")
    private String controlAuthorityCd;
    
    @Schema(description = "관련부서코드")
    private String reldeptCd;
    
    @Schema(description = "수검지역코드")
    private String inspectionAreaCd;
    
    @Schema(description = "수검결과코드")
    private String inspectionResultCd;
    
    @Schema(description = "기타내용")
    private String etcCn;
    
    @Schema(description = "IRRE유형코드")
    private String irreTypeCd;
    
    @Schema(description = "CGO여부")
    @NotBlank
    private String cgoYn;
    
    @Schema(description = "AWB_NBR명")
    private String awbNbrNm;
    
    @Schema(description = "PC_SWT명")
    private String pcSwtNm;
    
    @Schema(description = "COMMONDITY명")
    private String commondityNm;
    
    @Schema(description = "DIMENSION명")
    private String dimensionNm;
    
    @Schema(description = "ORGSTN명")
    private String orgstnNm;
    
    @Schema(description = "DESTINATION명")
    private String destinationNm;
    
    @Schema(description = "IMPCODE명")
    private String impCodeNm;
    
    @Schema(description = "UNID_NBR명")
    private String unidNbrNm;
    
    @Schema(description = "PSN명")
    private String psnNm;
    
    @Schema(description = "발생클래스명")
    private String occurClsNm;
    
    @Schema(description = "ULD_NBR명")
    private String uldNbrNm;
    
    @Schema(description = "LOADING POS 명")
    private String loadingPosNm;
    
    @Schema(description = "SELFT AUTH여부")
    @NotBlank
    private String selftAuthYn;
}
