package com.koreanair.ksms.avn.sfta.service;

public interface AvnSmsMaturityService {
}
