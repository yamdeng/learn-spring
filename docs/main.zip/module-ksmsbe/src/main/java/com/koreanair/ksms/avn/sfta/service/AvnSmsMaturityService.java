package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import com.koreanair.ksms.avn.sfta.dto.DashboardDto;

public interface AvnSmsMaturityService {
    //안전보증 > SMS 성숙도점검 > 대시보드
    List<DashboardDto> selectSMSDashboardList1(String param);
    List<DashboardDto> selectSMSDashboardList2(String param);


}
