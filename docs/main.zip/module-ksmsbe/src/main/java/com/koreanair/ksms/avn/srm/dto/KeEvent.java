package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "보고서 Event")
public class KeEvent {

    @NotNull
    private int id;

    @NotNull
    private String empNo;

    @NotNull
    private String reportType;

    @NotNull
    private String nameKo;

    private String nameEn;

    @NotNull
    private String newEventName;

    @NotNull
    private int viewOrder;

    private String state;

    //@NotNull
    //private Timestamp createdAt;

    private Timestamp deletedAt;

}

