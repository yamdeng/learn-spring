package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "협력업체 사업장")
public class OcuPartnerPlaceDto extends CommonDto {
    
    @Schema(description = "사업장_ID")
    @NotBlank
    private String bizPlaceId;
    
    @Schema(description = "협력업체_ID")
    @NotBlank
    private String prtnrId;
    
    @Schema(description = "사업장_분류_코드")
    @NotBlank
    private String bizPlaceClsCd;
    
    @Schema(description = "사용부문_코드")
    @NotBlank
    private String useSectCd;
    
    @Schema(description = "관리부서_코드")
    @NotBlank
    private String mgntDeptCd;
    
    @Schema(description = "담당자_명1")
    @NotBlank
    private String staffNm1;
    
    @Schema(description = "담당자_연락처1")
    @NotBlank
    private String staffContactNo1;
    
    @Schema(description = "담당자_이메일1")
    @NotBlank
    private String staffEmail1;
    
    @Schema(description = "담당자_업무1")
    @NotBlank
    private String staffWork1;
    
    @Schema(description = "담당자_명2")
    private String staffNm2;
    
    @Schema(description = "담당자_연락처2")
    private String staffContactNo2;
    
    @Schema(description = "담당자_이메일2")
    private String staffEmail2;
    
    @Schema(description = "담당자_업무2")
    private String staffWork2;
    
    @Schema(description = "안전관리")
    private String sftyMgnt;
    
    @Schema(description = "보건관리")
    private String hlthMgnt;
    
    @Schema(description = "주요업무")
    @NotBlank
    private String majorWorkCn;
    
    @Schema(description = "등록_일시")
    @NotBlank
    private String majorWorkContent;
}
