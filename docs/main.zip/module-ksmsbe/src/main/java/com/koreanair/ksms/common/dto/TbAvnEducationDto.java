package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS 교육")
public class TbAvnEducationDto extends CommonDto {
    
    @Schema(description = "교육ID")
    @NotBlank
    private String educationId;
    
    @Schema(description = "교육일자")
    private String educationDt;
    
    @Schema(description = "교육구분")
    private String educationType;
    
    @Schema(description = "제목")
    private String subject;
    
    @Schema(description = "내용")
    private String notes;
    
    @Schema(description = "링크ID")
    private String linkGroupSeq;
    
    @Schema(description = "첨부파일")
    private String fileGroupSeq;
}
