package com.koreanair.ksms.ocu.edu.controller;

import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.edu.service.OcuMsdsService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전교육 - MSDS교육
 */
@Tag(name = "OcuMsds", description = "안전교육 - MSDS교육 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuMsdsController {

    @Autowired
    OcuMsdsService service;

    /**
     * MSDS교육 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "MSDS교육 목록 조회", description = "MSDS교육 목록 조회 API")
    @GetMapping(value = "/education/msds")
    public ResponseEntity<?> getMsdsList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "MSDS교육 상세정보 조회", description = "MSDS교육 상세정보 조회 API")
    @GetMapping(value = "/education/msds/{msdsId}")
    public ResponseEntity<?> getMsdsInfo(@PathVariable(value="msdsId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 MSDS교육 등록", description = "신규 MSDS교육 등록 API")
    @PostMapping(value = "/education/msds")
    public ResponseEntity<?> insertMsds(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "MSDS교육 정보 수정", description = "MSDS교육 정보 수정 API")
    @PutMapping(value = "/education/msds/{msdsId}")
    public ResponseEntity<?> updateMsds(
            @PathVariable(value="msdsId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "MSDS교육 삭제", description = "MSDS교육 삭제 API")
    @DeleteMapping(value = "/education/msds/{msdsId}")
    public ResponseEntity<?> deleteMsds(@PathVariable(value="msdsId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
