package com.koreanair.ksms.avn.sfta.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SmsComprehensiveHzdTopRiskDto {
    
    @Schema(description = "연도")
    private String year;
    
    @Schema(description = "구분")
    private String gubun;
    
    @Schema(description = "순번")
    private int num;

    @Schema(description = "01")
    private String col01;
    
    @Schema(description = "02")
    private String col02;
    
    @Schema(description = "03")
    private String col03;
    
    @Schema(description = "04")
    private String col04;
    
    @Schema(description = "05")
    private String col05;
    
    @Schema(description = "06")
    private String col06;
    
    @Schema(description = "07")
    private String col07;
    
    @Schema(description = "08")
    private String col08;
    
    @Schema(description = "09")
    private String col09;
    
    @Schema(description = "10")
    private String col10;
    
    @Schema(description = "11")
    private String col11;
    
    @Schema(description = "12")
    private String col12;
    
    @Schema(description = "TTL")
    private String colTotal;
}
