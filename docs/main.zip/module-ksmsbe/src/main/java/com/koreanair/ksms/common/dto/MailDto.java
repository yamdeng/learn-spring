package com.koreanair.ksms.common.dto;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString
@EqualsAndHashCode
public class MailDto {

	private String rcvEmail;
	private String rcvName;
	private String rcvEmpNo;
	private String title;
	private String msg;
	private String strSemail;
	private String strSname;
	
	public MailDto(
			String rcvEmail, 
			String rcvName, 
			String title, 
			String msg, 
			String strSemail, 
			String strSname
	) {
		this.rcvEmail = rcvEmail;
		this.rcvName = rcvName;
		this.title = title;
		this.msg = msg;
		this.strSemail = strSemail;
		this.strSname = strSname;
	}
	
	
	
}
