package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "보고서 - 그룹관리")
public class TbAvnSmGroup extends CommonDto {

    @Schema(description = "ID")
    @NotBlank
    private Integer id;

    @Schema(description = "리포트 유형, code_group=Report Type")
    @NotBlank
    private String reportType;

    @Schema(description = "리포트 단계, code_group=Report Phase")
    @NotBlank
    private String phase;

    @Schema(description = "리포트 상태, code_group=Report State")
    @NotBlank
    private String stateType;

    @Schema(description = "위험도 평가 메모")
    private String assessmentNotes;

    @Schema(description = "Statistics Only 여부")
    private String isStatisticsOnly;

    @Schema(description = "MSR 보고서 - ear_no")
    private String earNo;

    @Schema(description = "MSR 보고서 - is_hf")
    private String isHf;

    @Schema(description = "HZD 보고서 - 항공 여부")
    private String isAvnHzd;

    @Schema(description = "HZD 보고서 - 산업 여부")
    private String isOcuHzd;

    @Schema(description = "HZD 보고서 - 보안 여부")
    private String isSftyHzd;

    @Schema(description = "tb_avn_sm_report id")
    private Integer reportId;
}
