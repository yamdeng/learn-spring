package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.TbAvnAirports;
import com.koreanair.ksms.common.dto.TbSysCodeDto;
import com.koreanair.ksms.common.dto.TbSysUserCfgDto;
import com.koreanair.ksms.common.dto.TbTbAvnDisplayStatusDto;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageInfo;

import java.util.LinkedHashMap;
import java.util.List;

@Service
public class AvnCommonServiceImpl extends AbstractBaseService implements AvnCommonService {

    @Override
    public List<TbTbAvnDisplayStatusDto> selectPageCodeList(String pageCode) {

        return commonSql.selectList("AvnCommon.selectPageCodeList", pageCode);
    }

    @Override
    public PageInfo<TbAvnAirports> selectAirportList(String keyword){
        List<TbAvnAirports> resultList = commonSql.selectList("AvnCommon.selectAirportList", keyword);
        return PageInfo.of(resultList);
    }

    @Override
    public TbSysUserCfgDto selectUserCfg() {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();
        TbSysUserCfgDto result = commonSql.selectOne("AvnCommon.selectUserCfg", userId);

        String reportsLang = result.getReportsLang();

        JSONParser parser = new JSONParser(reportsLang);
        LinkedHashMap<String, Object> jsonObject = null;
        try {
            jsonObject = (LinkedHashMap) parser.parse();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        result.setIndividualReportsLang(jsonObject.get("individualReportsLang")+"");
        result.setASR((String) jsonObject.get("ASR"));
        result.setCSR((String) jsonObject.get("CSR"));
        result.setMSR((String) jsonObject.get("MSR"));
        result.setGSR((String) jsonObject.get("GSR"));
        result.setHZR((String) jsonObject.get("HZR"));
        result.setDSR((String) jsonObject.get("DSR"));
        result.setRSR((String) jsonObject.get("RSR"));
        result.setFOQA((String) jsonObject.get("FOQA"));

        return result;
    }

    @Override
    public void saveUserCfg(TbSysUserCfgDto dto) {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();
        dto.setUserId(userId);

        String reportsLang = "{\"";
        reportsLang += "ASR\":\""  + dto.getASR()   + "\",\"";
        reportsLang += "CSR\":\""  + dto.getCSR()   + "\",\"";
        reportsLang += "MSR\":\""  + dto.getMSR()   + "\",\"";
        reportsLang += "GSR\":\""  + dto.getGSR()   + "\",\"";
        reportsLang += "HZR\":\""  + dto.getHZR()   + "\",\"";
        reportsLang += "DSR\":\""  + dto.getDSR()   + "\",\"";
        reportsLang += "RSR\":\""  + dto.getRSR()   + "\",\"";
        reportsLang += "FOQA\":\"" + dto.getFOQA()  + "\",\"";
        reportsLang += "individualReportsLang\":" + dto.getIndividualReportsLang() + "}";
        dto.setReportsLang(reportsLang);

        commonSql.insert("AvnCommon.saveUserCfg", dto);
    }

}
