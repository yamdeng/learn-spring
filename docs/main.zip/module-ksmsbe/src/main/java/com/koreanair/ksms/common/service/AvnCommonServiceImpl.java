package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.dto.*;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import io.vertx.core.json.JsonObject;
import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import com.github.pagehelper.PageInfo;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class AvnCommonServiceImpl extends AbstractBaseService implements AvnCommonService {

    @Override
    public List<TbTbAvnDisplayStatusDto> selectPageCodeList(String pageCode) {

        return commonSql.selectList("AvnCommon.selectPageCodeList", pageCode);
    }

    @Override
    public PageInfo<TbAvnAirports> selectAirportList(String keyword){
        List<TbAvnAirports> resultList = commonSql.selectList("AvnCommon.selectAirportList", keyword);
        return PageInfo.of(resultList);
    }

    //항공기 목록 조회
    @Override
    public PageInfo<TbAvnAircrafts> selectAircraftList(String keyword){
        List<TbAvnAircrafts> resultList = commonSql.selectList("AvnCommon.selectAircraftList", keyword);
        return PageInfo.of(resultList);
    }

    @Override
    public TbSysUserCfgDto selectUserCfg() {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();
        TbSysUserCfgDto result = commonSql.selectOne("AvnCommon.selectUserCfg", userId);

        String reportsLang = result.getReportsLang();

        JSONParser parser = new JSONParser(reportsLang);
        LinkedHashMap<String, Object> jsonObject = null;
        try {
            jsonObject = (LinkedHashMap) parser.parse();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        result.setIndividualReportsLang(jsonObject.get("individualReportsLang")+"");
        result.setASR((String) jsonObject.get("ASR"));
        result.setCSR((String) jsonObject.get("CSR"));
        result.setMSR((String) jsonObject.get("MSR"));
        result.setGSR((String) jsonObject.get("GSR"));
        result.setHZR((String) jsonObject.get("HZR"));
        result.setDSR((String) jsonObject.get("DSR"));
        result.setRSR((String) jsonObject.get("RSR"));
        result.setFOQA((String) jsonObject.get("FOQA"));

        return result;
    }

    @Override
    public void saveUserCfg(TbSysUserCfgDto dto) {

        String userId = SecurityContextHolder.getContext().getAuthentication().getName();
        dto.setUserId(userId);

        String reportsLang = "{\"";
        reportsLang += "ASR\":\""  + dto.getASR()   + "\",\"";
        reportsLang += "CSR\":\""  + dto.getCSR()   + "\",\"";
        reportsLang += "MSR\":\""  + dto.getMSR()   + "\",\"";
        reportsLang += "GSR\":\""  + dto.getGSR()   + "\",\"";
        reportsLang += "HZR\":\""  + dto.getHZR()   + "\",\"";
        reportsLang += "DSR\":\""  + dto.getDSR()   + "\",\"";
        reportsLang += "RSR\":\""  + dto.getRSR()   + "\",\"";
        reportsLang += "FOQA\":\"" + dto.getFOQA()  + "\",\"";
        reportsLang += "individualReportsLang\":" + dto.getIndividualReportsLang() + "}";
        dto.setReportsLang(reportsLang);

        commonSql.insert("AvnCommon.saveUserCfg", dto);
    }

    /**
     * 업무(권한)에 맞는 보고서 리스트 조회
     *
     * @param authList 업무 리스트(code_grp_id = 'CODE_GRP_RESOURCE')
     *                 authList :  reporting, report_acceptance, risk_assessment, ssc_review
     *                 , mitigation, 2nd_risk_assessment, 2nd_ssc_review, approval, view_list, risk_register
     *                 , dashboard, report_popsearch, effectiveness, hazard_mgmt
     * @return the list(asr, csr, hzd, gsr ...)
     * @throws Exception the exception
     */
    @Override
    public List<String> getAuthReportList(List<String> authList) {
        try {

            List<DBObject> resourceList = commonSql.selectList("AvnCommon.selectResourceList", this.selectRoleList());

            Map<String, List<DBObject>> resourceMap = resourceList.stream()
                    .collect(Collectors.groupingBy(dbo -> dbo.get("RESOURCE_TYPE").toString()));

            DBObject resByType = new BasicDBObject();
            for (Map.Entry<String, List<DBObject>> entry : resourceMap.entrySet()) {
                Map<String, Set<String>> resEntryMap = new HashMap<String, Set<String>>();
                for(DBObject e : entry.getValue()) {
                    resEntryMap.computeIfAbsent(e.get("RESOURCE_NAME").toString(), k -> new HashSet<>())
                            .add(e.get("DETAIL_TYPE").toString());
                }
                resByType.put(entry.getKey(), resEntryMap);
            }
            JsonObject resourceAuth = new JsonObject(resByType.toMap());
            JsonObject reportAuthority = resourceAuth.getJsonObject("report_authority");

            ArrayList<String> resultList =  new ArrayList<>();
            for(String auth : authList) {
                ArrayList<String> authInfo =  new ArrayList<>((HashSet)reportAuthority.getValue(auth));
                for(String info : authInfo) {
                    if (!resultList.contains(info)) {
                        resultList.add(info);
                    }
                }
            }
            if(reportAuthority.containsKey("all_report")) {
                return Collections.emptyList();
            }
            return resultList;

        }catch(Exception e) {
            return null;
        }
    }

    /**
     * 업무(권한)에 맞는 보고서 리스트 조회
     *
     * @param authList 업무 리스트(code_grp_id = 'CODE_GRP_RESOURCE')
     *                 authList :  reporting, report_acceptance, risk_assessment, ssc_review
     *                 , mitigation, 2nd_risk_assessment, 2nd_ssc_review, approval, view_list, risk_register
     *                 , dashboard, report_popsearch, effectiveness, hazard_mgmt
     * @return the list
     * @throws Exception the exception
     */
    public List<String> getReportAuthListDB(List<String> authList) {
        try {

            List<DBObject> resourceList = commonSql.selectList("AvnReportAnalysis.selectResourceList", this.selectRoleList());

            Map<String, List<DBObject>> resourceMap = resourceList.stream()
                    .collect(Collectors.groupingBy(dbo -> dbo.get("RESOURCE_TYPE").toString()));

            DBObject resByType = new BasicDBObject();
            DBObject typeByRes = new BasicDBObject();
            for (Map.Entry<String, List<DBObject>> entry : resourceMap.entrySet()) {
                Map<String, Set<String>> resEntryMap = new HashMap<String, Set<String>>();
                Map<String, Set<String>> typeEntryeMap = new HashMap<String, Set<String>>();
                for(DBObject e : entry.getValue()) {
                    resEntryMap.computeIfAbsent(e.get("RESOURCE_NAME").toString(), k -> new HashSet<>())
                            .add(e.get("DETAIL_TYPE").toString());
                    typeEntryeMap.computeIfAbsent(e.get("DETAIL_TYPE").toString(), k -> new HashSet<>())
                            .add(e.get("RESOURCE_NAME").toString());
                }
                resByType.put(entry.getKey(), resEntryMap);
                typeByRes.put(entry.getKey(), typeEntryeMap);
            }
            JsonObject resourceAuth = new JsonObject(resByType.toMap());
            JsonObject reportAuthority = resourceAuth.getJsonObject("report_authority");

            ArrayList<String> resultList =  new ArrayList<>();
            for(String auth : authList) {
                ArrayList<String> authInfo =  new ArrayList<>((HashSet)reportAuthority.getValue(auth));
                for(String info : authInfo) {
                    if (!resultList.contains(info)) {
                        resultList.add(info);
                    }
                }
            }
            if(reportAuthority.containsKey("all_report")) {
                return Collections.emptyList();
            }
            return resultList;

        }catch(Exception e) {
            return null;
        }
    }

    @Override
    public List<String> selectRoleList () {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        List<String> roleList = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
        return roleList;
    }

    @Override
    public PageInfo<TbAvnSysUserDto> selectUserListPage(String searchWord) {

        List<TbAvnSysUserDto> resultList = commonSql.selectList("AvnCommon.selectUserList", searchWord);
        return PageInfo.of(resultList);
    }
}
