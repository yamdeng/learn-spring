package com.koreanair.ksms.avn.sfta.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveHzdTopRiskDto;
import com.koreanair.ksms.avn.sfta.dto.SmsComprehensiveSearchDto;
import com.koreanair.ksms.common.service.AbstractBaseService;

@Service
public class AvnSmsComprehensiveServiceImpl extends AbstractBaseService implements AvnSmsComprehensiveService {

    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList1(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveHzdList1", param);
        return resultList;
    }

    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList2(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveHzdList2", param);
        return resultList;
    }

    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveHzdList3(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveHzdList3", param);
        return resultList;
    }
    
    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList1(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveEventList1", param);
        return resultList;
    }

    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList2(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveEventList2", param);
        return resultList;
    }

    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList3(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveEventList3", param);
        return resultList;
    }
    
    @Override
    public List<SmsComprehensiveHzdTopRiskDto> selectSMSComprehensiveEventList4(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectSMSComprehensiveEventList4", param);
        return resultList;
    }

    @Override
    public PageInfo<SmsComprehensiveHzdTopRiskDto> selectReportDetailList(SmsComprehensiveSearchDto param) {
        List<SmsComprehensiveHzdTopRiskDto> resultList = commonSql.selectList("AvnSmsComprehensive.selectReportDetailList", param);
        return PageInfo.of(resultList);
    }
}
