package com.koreanair.ksms.ocu.mgmt.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "밀폐공간 현황")
public class OcuSpaceDto extends CommonDto {
    
    @Schema(description = "밀폐공간현황_ID")
    private String sldSpaceStatId;
    
    @Schema(description = "부문_코드")
    private String sectCd;
    
    @Schema(description = "부서_코드")
    private String deptCd;
    
    @Schema(description = "권역_코드")
    private String areaCd;
    
    @Schema(description = "사업장")
    private String bizPlace;
    
    @Schema(description = "위치분류1")
    private String positionCls1;
    
    @Schema(description = "위치분류2")
    private String positionCls2;
    
    @Schema(description = "취급화학물질")
    private String hndChmcl;
    
    @Schema(description = "유해인자")
    private String hzdFactor;
    
    @Schema(description = "기준규칙_코드")
    private String stdRuleCd;
    
    @Schema(description = "작업_업체_명")
    private String wrkCompanyNm;
    
    @Schema(description = "출입_주기")
    private String entExtIntrv;
    
    @Schema(description = "작업_내용")
    private String wrkContent;
    
    @Schema(description = "첨부_사진_ID1")
    private String pohtoId1;
    
    @Schema(description = "첨부_사진_ID2")
    private String pohtoId2;
}
