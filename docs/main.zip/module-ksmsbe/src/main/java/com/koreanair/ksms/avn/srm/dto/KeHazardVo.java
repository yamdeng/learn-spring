package com.koreanair.ksms.avn.srm.dto;


import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class KeHazardVo {

    private int lv3Id;

    private String lv3Name;

    private String lv3Notes;

    private int lv3ViewOrder;

    private String lv3EmpNo;

    private String lv3Timezone;

    private Timestamp lv3CreatedAt;

    private int lv2Id;

    private String lv2Name;

    private String lv2Notes;

    private int lv2ViewOrder;

    private String lv2EmpNo;

    private String lv2Timezone;

    private Timestamp lv2CreatedAt;

    private int lv1Id;

    private String lv1Name;

    private String lv1Notes;

    private int lv1ViewOrder;

    private String lv1EmpNo;

    private String lv1Timezone;

    private Timestamp lv1CreatedAt;

}