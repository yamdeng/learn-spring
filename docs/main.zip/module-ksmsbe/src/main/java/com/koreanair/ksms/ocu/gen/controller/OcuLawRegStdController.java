package com.koreanair.ksms.ocu.gen.controller;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegStdDto;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;
import com.koreanair.ksms.ocu.gen.dto.OcuZeroHzdGoalDto;
import com.koreanair.ksms.ocu.gen.service.OcuLawRegStdService;
import com.koreanair.ksms.ocu.gen.service.OcuZeroHzdGoalService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;


/**
 *  법규등록대장 기준 정보 Controller
 */
@Tag(name = "법규등록대장 기준 정보", description = "법규등록대장 기준 정보 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuLawRegStdController {


    @Autowired
    private OcuLawRegStdService service;
    

    @Autowired
    private OcuZeroHzdGoalService ocuzerohzdgoalService;
    
	/**
	 * 법 OPEN API KEY 
	 */
	@Value("${law.key}") 
	String key;	
    
    /**
     * 법규등록대장 기준 정보 목록 조회
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "법규등록대장 기준 정보 목록 조회", description = "법규등록대장 기준 정보 목록 조회 API")
    @GetMapping(value = "/general/lawRegStd")
    public ResponseEntity<?> getPageList(		
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageneralum
           ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
           ,@RequestParam(value="lawNm", required=false) String lawNm 
           ,@RequestParam(value="subjectDeptCd", required=false) String subjectDeptCd) {

	  PageHelper.startPage(pageneralum, pageSize);
	  
	  OcuLawRegStdDto dto = new OcuLawRegStdDto();
	  
	  dto.setLawNm(lawNm);
	  dto.setSubjectDeptCd(subjectDeptCd);

	  PageInfo<OcuLawRegStdDto> pageList = service.selectOcuLawRegStdList(dto);
      return ResponseUtil.createSuccessResponse(pageList);
    }
    
    /**
     * 법규등록대장 기준 정보 상세 조회
     * @param lawSeq
     * @return
     */
    @Operation(summary = "법규등록대장 기준 정보 상세 조회", description = "법규등록대장 기준 정보 상세 조회 API")
    @GetMapping("/general/lawRegStd/{lawSeq}")
    public ResponseEntity<?> selectOcuLawRegStd(@PathVariable(value="lawId") String lawId) {
    	
    	OcuLawRegStdDto result = service.selectOcuLawRegStd(lawId);
    	return ResponseUtil.createSuccessResponse(result);
    }

    /**
     * 법규등록대장 기준 정보 등록
     * @param dto
     * @return
     */
    @Operation(summary = "법규등록대장 기준 정보 등록", description = "법규등록대장 기준 정보 등록 API")
    @PostMapping(value = "/general/lawRegStd")
    public ResponseEntity<?> insertOcuLawRegStd(@Valid @RequestBody() OcuLawRegStdDto dto) {

        service.insertOcuLawRegStd(dto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 법규등록대장 기준 정보 수정
     * @param lawSeq
     * @param dto
     * @return
     */
    @Operation(summary = "법규등록대장 기준 정보 수정", description = "법규등록대장 기준 정보 수정 API")
    @PutMapping(value = "/general/lawRegStd")
    public ResponseEntity<?> updateOcuLawRegStd( @PathVariable(value="lawId") String lawId,
            @Valid @RequestBody() OcuLawRegStdDto dto) {
        
    	dto.setLawId(lawId);
        service.updateOcuLawRegStd(dto);
        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 법규등록대장 기준 정보 삭제
     * @param lawSeq
     * @return
     */
    @Operation(summary = "법규등록대장 기준 정보 삭제", description = "법규등록대장 기준 정보 삭제 API")
    @DeleteMapping(value = "/general/lawRegStd/{lawId}")
    public ResponseEntity<?> deleteOcuLawRegStd(@PathVariable(value="lawId") String lawId) {
        service.deleteOcuLawRegStd(lawId);
        return ResponseUtil.createSuccessResponse();
    }
    
    /**
     * 법규등록대장 존재 여부 체크
     * @param lawId
     * @return
     */
    @Operation(summary = "법규등록대장 존재 여부 체크", description = "법규등록대장 존재 여부 체크 API")
    @GetMapping(value = "/general/selectOcuLawRegInfoChk")
    public ResponseEntity<?> selectOcuLawRegInfoChk( @RequestParam(value="lawId", required=false) String lawId) {

        int result = service.selectOcuLawRegInfoChk(lawId);
        
        return ResponseUtil.createSuccessResponse(result);
    }
    
    /**
     * 법령정보 OPEN API 조회
     * @return
     */
    @Operation(summary = "법령정보 OPEN API 조회", description = "법령정보 OPEN API 조회")
    @PostMapping(value = "/general/selectLawOpenApi")
    public ResponseEntity<?> searchLawOpenapi( @Valid @RequestBody() OcuLawRegStdDto reqDto) {
    	
    	if(StringUtils.isEmpty(reqDto.getLawNm())) {
    		reqDto.setLawNm("");
    	}
    	
        RestClient restClient = RestClient.create();
        String result = restClient.get()
                .uri("https://www.law.go.kr/DRF/lawSearch.do?OC="+key+"&target=law&type=XML&display=10000" + "&query="+ reqDto.getLawNm())
                .retrieve()
                .body(String.class);
        
 
        List<OcuLawRegStdDto> lawNames = parseAndSortXmlString(result);
        return ResponseUtil.createSuccessResponse(lawNames);
    }
    
    /**
     * xml 파싱
     * @param xmlString
     * @return
     */
    private static List<OcuLawRegStdDto> parseAndSortXmlString(String xmlString) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(new InputSource(new StringReader(xmlString)));
            doc.getDocumentElement().normalize();

            NodeList lawNodes = doc.getElementsByTagName("law");
            
            List<OcuLawRegStdDto> dtoList = new ArrayList<OcuLawRegStdDto>();
            
            for (int i = 0; i < lawNodes.getLength(); i++) {
                Node node = lawNodes.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                	OcuLawRegStdDto dto = new OcuLawRegStdDto();
                    Element element = (Element) node;
                    dto.setNum(i+1);
                    dto.setLawSeq(element.getElementsByTagName("법령일련번호").item(0).getTextContent());
                    dto.setLawId(element.getElementsByTagName("법령ID").item(0).getTextContent());
                    dto.setLawNm(element.getElementsByTagName("법령명한글").item(0).getTextContent());
                    dto.setLawKind(element.getElementsByTagName("법령구분명").item(0).getTextContent());
                    dto.setFearDt(element.getElementsByTagName("공포일자").item(0).getTextContent());
                    dto.setImplDt(element.getElementsByTagName("시행일자").item(0).getTextContent());
                    dto.setLgsltKind(element.getElementsByTagName("제개정구분명").item(0).getTextContent());
                    dto.setRespMinistryNm(element.getElementsByTagName("소관부처명").item(0).getTextContent());
                    dto.setLawDtlLink(element.getElementsByTagName("법령상세링크").item(0).getTextContent());
                    dtoList.add(dto);
                }
            }
            return dtoList;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}


