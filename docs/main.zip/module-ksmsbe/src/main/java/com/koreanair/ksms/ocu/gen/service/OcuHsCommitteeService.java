package com.koreanair.ksms.ocu.gen.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.gen.dto.OcuHsCommitteeDto;

import jakarta.validation.Valid;

/**
 * 안전보건협의체 Service
 */
public interface OcuHsCommitteeService {

	/**
	 * 안전보건협의체 목록 조회
	 * @param dto
	 * @return
	 */
	public PageInfo<OcuHsCommitteeDto> selectHsCommitteeList(OcuHsCommitteeDto dto);

	/**
	 * 안전보건협의체 상세정보 조회
	 * @param advCmitId
	 * @return
	 */
	public OcuHsCommitteeDto getHsCommitteeInfo(int advCmitId);

	/**
	 * 신규 안전보건협의체 등록
	 * @param dto
	 */
	public void insertHsCommittee(@Valid OcuHsCommitteeDto dto);

	/**
	 * 안전보건협의체 정보 수정
	 * @param dto
	 */
	public void updateHsCommittee(@Valid OcuHsCommitteeDto dto);

	/**
	 * 안전보건협의체 삭제
	 * @param advCmitId
	 */
	public void deleteHsCommittee(int advCmitId);
}
