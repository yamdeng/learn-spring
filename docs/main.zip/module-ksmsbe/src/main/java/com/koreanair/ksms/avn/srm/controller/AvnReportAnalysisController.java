package com.koreanair.ksms.avn.srm.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.avn.srm.service.AvnReportAnalysisService;
import com.koreanair.ksms.avn.srm.service.AvnReportProcessService;
import com.koreanair.ksms.avn.srm.service.AvnReportReceiptService;
import com.koreanair.ksms.common.aspect.annotations.EnableAuth;
import com.koreanair.ksms.common.constants.AvnStatusCode;
import com.koreanair.ksms.common.constants.AvnStatusCode.StepType;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.utils.KeUtils;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 안전위험관리 - 보고서분석
 */
@Tag(name = "AvnReportAnalysis", description = "안전위험관리 - 보고서분석 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnReportAnalysisController {

    @Autowired
    AvnReportAnalysisService serviceAnalysis;

    @Autowired
    AvnReportReceiptService serviceReceipt;

    @Autowired
    AvnReportProcessService serviceProcess;

    /**
     * 보고서 분석 목록 조회
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param subject the subject
     * @param reportedBy the reportedBy
     * @param dateType the dateType
     * @param startDate the startDate
     * @param endDate the endDate
     * @param fleet the fleet
     * @param regNo the regNo
     * @param sector the sector
     * @param phase the use state
     * @param phase the stepCode
     * @param phase the myTurn
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 목록 조회", description = "보고서 분석 목록 조회 API")
    @GetMapping(value = "/srm/analysis")
    //@EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG","LSC" })
    public ResponseEntity<?> getAnalysisList(
            @RequestParam(value="pageNum", required=true, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=true, defaultValue="10") int pageSize
            ,@RequestParam(value="p_subject", required=false) String subject
            ,@RequestParam(value="p_reportedBy", required=false) String reportedBy
            ,@RequestParam(value="p_dateType", required=true) String dateType
            ,@RequestParam(value="p_startDate", required=false) String startDate
            ,@RequestParam(value="p_endDate", required=false) String endDate
            ,@RequestParam(value="p_fleet", required=false) String fleet
            ,@RequestParam(value="p_regNo", required=false) String regNo
            ,@RequestParam(value="p_sector", required=false) String sector
            ,@RequestParam(value="p_phase", required=false) String phase
            ,@RequestParam(value="p_stepCode", required=false) String stepCode
            ,@RequestParam(value="p_myTurn", required=false) String myTurn
    ) {
        ReportViewlistDto reportViewlistDto = new ReportViewlistDto();
        reportViewlistDto.setP_subject(subject);
        reportViewlistDto.setP_reportedBy(reportedBy);
        reportViewlistDto.setP_dateType(dateType);
        reportViewlistDto.setP_fleet(fleet);
        reportViewlistDto.setP_regNo(regNo);
        reportViewlistDto.setP_sector(sector);
        reportViewlistDto.setP_phase(phase);
        reportViewlistDto.setP_stepCode(stepCode);
        reportViewlistDto.setP_myTurn(myTurn);

        java.sql.Date p_startDate = java.sql.Date.valueOf(startDate);
        java.sql.Date p_endDate = java.sql.Date.valueOf(endDate);

        reportViewlistDto.setP_startDate(p_startDate);
        reportViewlistDto.setP_endDate(p_endDate);

        reportViewlistDto.setS_startDate(startDate);
        reportViewlistDto.setS_endDate(endDate);

        if (KeUtils.validatePeriodByYear(p_startDate, p_endDate, 5)) {

            serviceAnalysis.getAuthSetting(reportViewlistDto);

            PageHelper.startPage(pageNum, pageSize);
            //보고접수 and 1차위험도평가
            PageInfo<ReportViewlistVo> pageList = serviceAnalysis.getAnalysisList(reportViewlistDto);

            return ResponseUtil.createSuccessResponse(pageList);
        }
        throw new CustomBusinessException("보고서 조회가 실패하였습니다.");
    }

    /**
     * 보고서 분석 - 보고서 묶기(Group) 처리
     *
     * @param groupReportList the groupReportList
     * @return
     * @throws CustomBusinessException the exception
     */
    @Operation(summary = "보고서 분석 - 보고서 묶기(Group) 처리", description = "보고서 분석 보고서 묶기(Group) 처리 API")
    @PostMapping(value = "/srm/analysis/group")
    @EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG" })
    public ResponseEntity<?> insertAnalysisGroup(
            @Valid @RequestBody(required=true) List<Integer> groupReportList
    )
    {
        //보고서 리스트 중 이미 묶여있는 보고서 체크 && 보고서 상태 체크(접수대기인지)
        for (Integer groupId : groupReportList) {
            boolean isChked = serviceProcess.getIsValidateGroupReport(groupId);
            if (!isChked) {
                throw new CustomBusinessException("보고서 묶음 처리가 실패하였습니다.");
            }
        }
        //보고서 묶음 처리
        serviceProcess.insertMergeGroupReport(groupReportList);

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * 보고서 분석 - 전체 상세정보 조회 : 접수 ~ 1차위험평가(LSC)
     *
     * @param groupId the group id
     * @param id the id(Hazard list id)
     * @param stateType the step(9단계)
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 전체 상세정보 조회 : 접수 ~ 1차위험평가(LSC)", description = "보고서 분석 전체 상세정보 조회 API : 접수 ~ 1차위험평가(LSC)")
    @GetMapping(value = "/srm/analysis/edit/{reportType}/{step}/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> getAnalysisWithOutHazardInfo(
              @PathVariable(value="reportType", required=true) String reportType
            , @PathVariable(value="step", required=true) Integer step
            , @PathVariable(value="groupId", required=true) Integer groupId
    )
    {
        ReportInfoDto reportInfoDto = new ReportInfoDto();
        reportInfoDto.setP_groupId(groupId);
        reportInfoDto.setP_hazardId(null);
        reportInfoDto.setP_reportType(reportType);
        reportInfoDto.setP_step(step);

        ReportInfoDto resultInfo = serviceAnalysis.getAnalysisInfo(reportInfoDto);
        return ResponseUtil.createSuccessResponse(resultInfo);
    }

    /**
     * 보고서 분석 - 전체 상세정보 조회 : 1차위험평가(SRC) ~ 종결
     *
     * @param groupId the group id
     * @param id the id(Hazard list id)
     * @param stateType the step(9단계)
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "보고서 분석 - 전체 상세정보 조회 : 1차위험평가(SRC) ~ 종결", description = "보고서 분석 전체 상세정보 조회 API : 1차위험평가(SRC) ~ 종결")
    @GetMapping(value = "/srm/analysis/edit/{reportType}/{step}/{groupId}/{hazardId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG","MIT"})
    public ResponseEntity<?> getAnalysisWithHazardInfo(
            @PathVariable(value="reportType", required=true) String reportType
            , @PathVariable(value="step", required=true) Integer step
            , @PathVariable(value="groupId", required=true) Integer groupId
            , @PathVariable(value="hazardId", required=true) Integer hazardId
        )
    {
        ReportInfoDto reportInfoDto = new ReportInfoDto();
        reportInfoDto.setP_groupId(groupId);
        reportInfoDto.setP_hazardId(hazardId);
        reportInfoDto.setP_reportType(reportType);
        reportInfoDto.setP_step(step);

        ReportInfoDto resultInfo = serviceAnalysis.getAnalysisInfo(reportInfoDto);
        return ResponseUtil.createSuccessResponse(resultInfo);
    }

    @Operation(summary = "보고서 분석 - 접수 Insert", description = "보고서 분석 - 접수 Insert API")
    @PostMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> insertReceiptInfo(@Valid @RequestBody(required=true) ReceiptVo receiptVo
                                             , @RequestParam(required = true) boolean submit
    ) {
        try {

            // 보고서 정보를 가져오기위해 report 정보를 select 한다.
            ReceiptVo vo = receiptVo;

            // 보고서 empNo, smReport 세팅 및 reportId리턴
            // 보고서가 현재 처리가 가능한 step인지 확인한다.
            int reportId = this.preProcessing(vo, true);

            // STEP 2 Insert Data
            vo.setTimezone("Asia/Seoul");
            int receiptId = serviceReceipt.insertReceiptDetail(vo);
            vo.setId(receiptId);

            // STEP 3. update status
            String empNo = SecurityContextHolder.getContext().getAuthentication().getName();
            if (submit) {
                ReportProcessVo proccessVo = new ReportProcessVo(reportId, empNo, StepType.APPROVE);
                boolean success = serviceProcess.smsReportProcess(proccessVo);
                if (success) {
                    // STEP 4. 성공한 경우 Receipt at 정보를 update 시킨다.
                    serviceReceipt.updateReceiptAt(receiptId);
                }
            } else {
                ReportProcessVo proccessVo = new ReportProcessVo(reportId, empNo, StepType.SAVE);
                serviceProcess.smsReportProcess(proccessVo);
            }
            //todo khw. 생각해볼 필요... 저장 이후 화면으로 VO 데이터를 전달해야 하는지????
            /*
            ReceiptDto.POST_Response data = new ReceiptDto.POST_Response(vo);
            GetResponseDetail<ReceiptDto.POST_Response> response = new GetResponseDetail<ReceiptDto.POST_Response>();
            response.setData(data);

            return ResponseEntity.ok(response);
            */


            return ResponseUtil.createSuccessResponse();

        } catch (Exception e) {
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
            throw new CustomBusinessException("System Error", "2");
        }
    }

    @Operation(summary = "보고서 분석 - 접수 Update", description = "보고서 분석 - 접수 Update API")
    @PutMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> updateReceiptInfo(
              @Valid @RequestBody(required=true) ReceiptVo receiptVo
            , @RequestParam(required = true) boolean submit
    ) {
        try {

            // 보고서 정보를 가져오기위해 report 정보를 select 한다.
            ReceiptVo vo = receiptVo;

            // 보고서 empNo, smReport 세팅 및 reportId리턴
            // 보고서가 현재 처리가 가능한 step인지 확인한다.
            int reportId = this.preProcessing(vo, true);

            // STEP 2 Insert Data
            vo.setTimezone("Asia/Seoul");
            serviceReceipt.updateReceiptDetail(vo);

            // STEP 3. update status
            String empNo = SecurityContextHolder.getContext().getAuthentication().getName();
            if (submit) {
                ReportProcessVo proccessVo = new ReportProcessVo(reportId, empNo, StepType.APPROVE);
                boolean success = serviceProcess.smsReportProcess(proccessVo);
                if (success) {
                    // STEP 4. 성공한 경우 Receipt at 정보를 update 시킨다.
                    int receiptId = vo.getId();
                    serviceReceipt.updateReceiptAt(receiptId);
                }
            } else {
                ReportProcessVo proccessVo = new ReportProcessVo(reportId, empNo, StepType.SAVE);
                serviceProcess.smsReportProcess(proccessVo);
            }
            //todo khw. 생각해볼 필요... 저장 이후 화면으로 VO 데이터를 전달해야 하는지????
            /*
            ReceiptDto.POST_Response data = new ReceiptDto.POST_Response(vo);
            GetResponseDetail<ReceiptDto.POST_Response> response = new GetResponseDetail<ReceiptDto.POST_Response>();
            response.setData(data);

            return ResponseEntity.ok(response);
            */


            return ResponseUtil.createSuccessResponse();

        } catch (Exception e) {
            //throw new MicroServiceException(HttpStatus.INTERNAL_SERVER_ERROR, 500, "System Error");
            throw new CustomBusinessException("System Error", "2");
        }
    }

    @Operation(summary = "보고서 분석 - 접수 반려", description = "보고서 분석 - 접수 반려 API")
    @DeleteMapping(value = "/srm/analysis/{groupId}")
    //@EnableAuth(role = {"SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG"})
    public ResponseEntity<?> rejectReceiptInfo(
              @PathVariable(value="groupId", required=true) Integer groupId
            , @Valid @RequestBody(required=true) ReceiptVo receiptVo
    )
    {
        try {
            // TODO method put으로통합 delete는 데이터 삭제에 가까움
            String empNo = SecurityContextHolder.getContext().getAuthentication().getName();
            String reason = receiptVo.getReason();
            ReportProcessVo proccessVo = new ReportProcessVo(groupId, empNo, StepType.REJECT);
            proccessVo.setReason(reason);
            serviceProcess.smsReportProcess(proccessVo);

            /*
            ReceiptDto.DELETE_Response data = new ReceiptDto.DELETE_Response();
            GetResponseDetail<ReceiptDto.DELETE_Response> response = new GetResponseDetail<ReceiptDto.DELETE_Response>();
            response.setData(data);

            return ResponseEntity.ok(response);
            */

            return ResponseUtil.createSuccessResponse();
        } catch (Exception e) {
            throw new CustomBusinessException("System Error", "2");
        }
    }



    private int preProcessing(ReceiptVo vo, boolean isCreate) throws Exception {
        String empNo = SecurityContextHolder.getContext().getAuthentication().getName();

        int groupId = vo.getGroupId();

        SmReport report = serviceReceipt.selectReportDetail(groupId);
        String phase = report.getReportPhase();
        // 보고접수 or 리포트 작성완료 ||
        if (!(AvnStatusCode.Phase.RECEPTION.getCode().equals(phase)
                || AvnStatusCode.Phase.REPORTING.getCode().equals(phase)
                || AvnStatusCode.Phase.REPORT_CLOSE.getCode().equals(phase))) {
            throw new Exception();
        }
        vo.setEmpNo(empNo);
        vo.setSmReport(report);
        vo.setCreate(isCreate);

        return groupId;
    }


    /**
     * 보고서 분석 목록 조회_삭제예정
     *
     * @param pageNum the page number
     * @param pageSize the page size
     * @param subject the job type
     * @param reportedBy the manual name
     * @param dateType the language type
     * @param startDate the use state
     * @param startDate the use state
     * @param endDate the use state
     * @param fleet the use state
     * @param regNo the use state
     * @param sector the use state
     * @param phase the use state
     * @return the list
     * @throws Exception the exception
     */
    //@Operation(summary = "보고서 분석 목록 조회", description = "보고서 분석 목록 조회 API")
    //@GetMapping(value = "/srm/analysis")
    //@EnableAuth(role = { "SA","MMG","CMG","GMG","DMG","AMG","HMG","FMG","LSC" })
    public ResponseEntity<?> getAnalysisList_삭제예정(
            @RequestParam(value="pageNum", required=true, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=true, defaultValue="10") int pageSize
            ,@RequestParam(value="p_subject", required=false) String subject
            ,@RequestParam(value="p_reportedBy", required=false) String reportedBy
            ,@RequestParam(value="p_dateType", required=true) String dateType
            ,@RequestParam(value="p_startDate", required=true) String startDate
            ,@RequestParam(value="p_endDate", required=true) String endDate
            ,@RequestParam(value="p_fleet", required=false) String fleet
            ,@RequestParam(value="p_regNo", required=false) String regNo
            ,@RequestParam(value="p_sector", required=false) String sector
            ,@RequestParam(value="p_phase", required=true) String phase
        ) {

        ReportViewlistDto reportViewlistDto = new ReportViewlistDto();
        reportViewlistDto.setP_subject(subject);
        reportViewlistDto.setP_reportedBy(reportedBy);
        reportViewlistDto.setP_dateType(dateType);
        reportViewlistDto.setP_fleet(fleet);
        reportViewlistDto.setP_regNo(regNo);
        reportViewlistDto.setP_sector(sector);
        reportViewlistDto.setP_phase(phase);

        java.sql.Date p_startDate = java.sql.Date.valueOf(startDate);
        java.sql.Date p_endDate = java.sql.Date.valueOf(endDate);

        reportViewlistDto.setP_startDate(p_startDate);
        reportViewlistDto.setP_endDate(p_endDate);

        if (KeUtils.validatePeriodByYear(p_startDate, p_endDate, 5)) {

            //TODO session 처리 필요
            //SmsAuthDto authParam = new SmsAuthDto(sessionInfo);
            //String empNo = sessionInfo.getString("EMP_NO");

            Map<Object, String> authParam = new HashMap<>();

            String empNo = "1";
            // report status filter 생성
            String actionPhase = reportViewlistDto.getP_phase();
            if ("1stRiskAssessment".equals(actionPhase)) {
                actionPhase ="1st_risk";
                //authParam.setReportType("risk_assessment");
                authParam.put("reportType", "1sk_risk_assessment");
            } else if ("2stRiskAssessment".equals(actionPhase)) {

            } else if ("2stRiskAssessment".equals(actionPhase)) {

            } else {
                //authParam.setReportType("report_acceptance");
                authParam.put("reportType", "report_acceptance");
            }

            //List<String> reportList = this.getReportAuthList(authParam);
            List<String> reportList = new ArrayList<>();
            reportList.add(0, "asr");
            reportList.add(1, "foqa");
            reportList.add(2, "hzr");
            // size가 0인경우는 allList
            if (reportList.size() > 0) {
                if (reportList.contains("assigned_report")) {
                    reportViewlistDto.setP_assignEmpNo(empNo);
                }
                reportViewlistDto.setP_reportList(reportList);
            }
            //LSC 맴버확인용 empNo;
            reportViewlistDto.setP_empNo(empNo);

            PageHelper.startPage(pageNum, pageSize);


            //보고접수 and 1차위험도평가
            PageInfo<ReportViewlistVo> pageList = serviceAnalysis.getAnalysisList(reportViewlistDto);

            return ResponseUtil.createSuccessResponse(pageList);
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(null);
    }
}
