package com.koreanair.ksms.ocu.insp.dto;

import com.koreanair.ksms.common.dto.CommonDto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "점검표 항목")
public class OcuChecklistItemDto extends CommonDto {
    
    @Schema(description = "점검항목_ID")
    @NotBlank
    private String chkItemId;
    
    @Schema(description = "점검표_ID")
    @NotBlank
    private String chkListId;
    
    @Schema(description = "부모_점검항목_ID")
    @NotBlank
    private String parntsChkItemId;
    
    @Schema(description = "점검항목_명")
    @NotBlank
    private String chkItemNm;
}
