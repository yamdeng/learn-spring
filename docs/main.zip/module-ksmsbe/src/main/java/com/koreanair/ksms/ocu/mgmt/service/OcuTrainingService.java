package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.ocu.mgmt.dto.OcuTrainingDto;

public interface OcuTrainingService {

    OcuTrainingDto selectOcuTraining(int id);
    PageInfo<OcuTrainingDto> selectOcuTrainingList(OcuTrainingDto paramDto);
    
    void insertOcuTraining(OcuTrainingDto dto);
    void updateOcuTraining(OcuTrainingDto dto);
    void deleteOcuTraining(int id);
    void saveOcuTraining(List<OcuTrainingDto> dataList);
    
}
