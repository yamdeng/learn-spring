package com.koreanair.ksms.common.service;

import com.koreanair.ksms.common.constants.StatusCodeConstants;
import com.koreanair.ksms.common.dto.CustomUserInfoDto;
import com.koreanair.ksms.common.dto.LoginRequestDto;
import com.koreanair.ksms.common.exception.CustomBusinessException;
import com.koreanair.ksms.common.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class CommonLoginServiceImpl extends AbstractBaseService implements CommonLoginService {

    private final JwtUtil jwtUtil;

    @Override
    public Map<String, Object> login(LoginRequestDto dto) {

        String empNo = dto.getEmpNo();
        CustomUserInfoDto userInfo = commonSql.selectOne("CommonLogin.selectUserInfo", empNo);

        if(userInfo == null) {
            throw new CustomBusinessException("사번이 존재하지 않습니다.", StatusCodeConstants.UNAUTHORIZED_ACCESS);
        }

        String accessToken = jwtUtil.createAccessToken(userInfo);
        String refreshToken = jwtUtil.createRefreshToken(userInfo);

        Map<String, Object> tokens = new HashMap<String, Object>();
        tokens.put("accessToken", accessToken);
        tokens.put("refreshToken", refreshToken);

        return tokens;
    }

    @Override
    public CustomUserInfoDto loadUserByUserId(String userId) {

        return commonSql.selectOne("CommonLogin.loadUserByUserId", userId);
    }
}
