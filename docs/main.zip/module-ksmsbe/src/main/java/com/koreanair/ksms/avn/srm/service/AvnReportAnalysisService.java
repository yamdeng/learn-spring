package com.koreanair.ksms.avn.srm.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.srm.dto.ReportInfoDto;
import com.koreanair.ksms.avn.srm.dto.ReportViewlistDto;
import com.koreanair.ksms.avn.srm.dto.ReportViewlistVo;

import java.util.List;

public interface AvnReportAnalysisService {
    
    //목록 > 보고서 리스트(권한)조회
    void getAuthSetting(ReportViewlistDto reportViewlistDto);

    //목록 조회
    PageInfo<ReportViewlistVo> getAnalysisList(ReportViewlistDto reportViewlistDto);

    //상세
    ReportInfoDto getAnalysisInfo(ReportInfoDto reportInfoDto);

}
