package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.dto.*;
import com.koreanair.ksms.avn.audit.service.AvnAuditChecklistService;
import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * AUDIT - 점검표(Checklist)
 */
@Tag(name = "AvnAuditChecklist", description = "AUDIT - 점검표(Checklist) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditChecklistController {

    @Autowired
    AvnAuditChecklistService service;

    /**
     * Checklist 목록 조회 (with Chapter)
     * @param division the page num
     * @param origId the page num
     * @param revision the page size
     * @param langCode the page size
     * @return the list
     * @throws Exception the exception
     */
    @Parameters({
            @Parameter(name = "division", description = "부문 아이디"),
            @Parameter(name = "origId", description = "체크리스트 원본아이디"),
            @Parameter(name = "revision", description = "리비전"),
            @Parameter(name = "langCode", description = "언어코드")
    })
    @Operation(summary = "Checklist 목록 조회 (with Chapter)", description = "Checklist 목록 조회 (with Chapter) API")
    @GetMapping(value = "/audit/checklist/1/checklist-chapter")
    public ResponseEntity<?> getAuditChecklist(
            @RequestParam(value="division", required=true) String division,
            @RequestParam(value="origId", required=false, defaultValue = "0") int origId,
            @RequestParam(value="revision", required=false, defaultValue = "0") int revision,
            @RequestParam(value="langCode", required=false, defaultValue = "ALL") String langCode) {

        // 조회조건 parameter
        TBAuditChecklistDto tbAuditChecklistDto = new TBAuditChecklistDto();
        tbAuditChecklistDto.setDivision(division);
        tbAuditChecklistDto.setOrigId(origId);
        tbAuditChecklistDto.setRevision(revision);
        tbAuditChecklistDto.setLangCode(langCode);

        List<TBAuditChecklistChapterDto> resultList = service.selectAuditChecklist(tbAuditChecklistDto);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /**
     * Question 목록 조회
     * @param chapterOrigId the page num
     * @param revision the page size
     * @return the list
     * @throws Exception the exception
     */
    @Parameters({
            @Parameter(name = "chapterOrigId", description = "챕터 원본 아이디"),
            @Parameter(name = "revision", description = "리비전")
    })
    @Operation(summary = "Question 목록 조회", description = "Question 목록 조회 API")
    @GetMapping(value = "/audit/checklist/2/questions")
    public ResponseEntity<?> getAuditQuestionList(
            @RequestParam(value="chapterOrigId", required=true) int chapterOrigId,
            @RequestParam(value="revision", required=true) int revision) {
        // 조회조건 parameter
        TBAuditQuestionDto tbAuditQuestionDto = new TBAuditQuestionDto();
        tbAuditQuestionDto.setChapterOrigId(chapterOrigId);
        tbAuditQuestionDto.setRevision(revision);

        List<TBAuditQuestionDto> resultList = service.selectAuditQuestionList(tbAuditQuestionDto);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    /* Checklist 등록 */
    @Operation(summary = "Checklist 등록", description = "Checklist 등록 API")
    @PostMapping(value = "/audit/checklist/3/checklist-insert")
    public ResponseEntity<?> insertAuditChecklist(@Valid @RequestBody(required=true) TBAuditChecklistDto tbAuditChecklistDto) {

        Integer returnChecklistId = service.insertAuditChecklist(tbAuditChecklistDto);
        return ResponseUtil.createSuccessResponse(returnChecklistId);
    }

    /* Checklist 수정 (chapter 수정, question CUD 포함) */
    @Operation(summary = "Checklist 수정 (chapter,question CUD 포함)", description = "Checklist 수정 (chapter,question CUD 포함) API")
    @PutMapping(value = "/audit/checklist/4/checklist-update")
    public ResponseEntity<?> updateAuditChecklist(@Valid @RequestBody(required=true) TBAuditQuestionPostDto tbAuditQuestionPostDto) {

        TBAuditQuestionPostDto returnDto = new TBAuditQuestionPostDto();
        returnDto = service.updateAuditChecklist(tbAuditQuestionPostDto);
        return ResponseUtil.createSuccessResponse(returnDto);
    }

    /* Checklist 삭제 */
    @Operation(summary = "Checklist 삭제", description = "Checklist 삭제 API")
    @DeleteMapping(value = "/audit/checklist/5/checklist-delete")
    public ResponseEntity<?> deleteAuditChecklist(@Valid @RequestBody(required=true) TBAuditChecklistDto tbAuditChecklistDto) {

        service.deleteAuditChecklist(tbAuditChecklistDto);
        return ResponseUtil.createSuccessResponse();
    }

    /* Chapter 등록 */
    @Operation(summary = "Chapter 등록", description = "Chapter 등록 API")
    @PostMapping(value = "/audit/checklist/6/chapter-insert")
    public ResponseEntity<?> insertAuditChapter(@Valid @RequestBody(required=true) TBAuditChapterDto tbAuditChapterDto) {

        TBAuditChapterDto returnDto = new TBAuditChapterDto();
        returnDto = service.insertAuditChapter(tbAuditChapterDto);
        return ResponseUtil.createSuccessResponse(returnDto);
    }

    /* Chapter 수정 */
    @Operation(summary = "Chapter 수정", description = "Chapter 수정 API")
    @PutMapping(value = "/audit/checklist/7/chapter-update")
    public ResponseEntity<?> updateAuditChapter(@Valid @RequestBody(required=true) TBAuditChapterDto tbAuditChapterDto) {

        TBAuditChapterDto returnDto = new TBAuditChapterDto();
        returnDto = service.updateAuditChapter(tbAuditChapterDto);
        return ResponseUtil.createSuccessResponse(returnDto);
    }

    /* Chapter 삭제 */
    @Operation(summary = "Chapter 삭제", description = "Chapter 삭제 API")
    @DeleteMapping(value = "/audit/checklist/8/chapter-delete")
    public ResponseEntity<?> deleteAuditChapter(@Valid @RequestBody(required=true) TBAuditChapterDto tbAuditChapterDto) {

        TBAuditChapterDto returnDto = new TBAuditChapterDto();
        returnDto = service.deleteAuditChapter(tbAuditChapterDto);
        return ResponseUtil.createSuccessResponse(returnDto);
    }
}
