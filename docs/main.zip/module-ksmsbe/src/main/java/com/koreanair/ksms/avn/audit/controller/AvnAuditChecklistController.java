package com.koreanair.ksms.avn.audit.controller;

import com.koreanair.ksms.avn.audit.service.AvnAuditChecklistService;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * AUDIT - 점검표(Checklist)
 */
@Tag(name = "AvnAuditChecklist", description = "AUDIT - 점검표(Checklist) API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/avn")
public class AvnAuditChecklistController {

    @Autowired
    AvnAuditChecklistService service;

    /**
     * Checklist 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Checklist 목록 조회", description = "Checklist 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/checklists")
    public ResponseEntity<?> getAuditChecklistList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Checklist 상세정보 조회", description = "Checklist 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/checklists/{checklistId}")
    public ResponseEntity<?> getAuditChecklistInfo(@PathVariable(value="checklistId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Checklist 등록", description = "신규 Checklist 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/checklists")
    public ResponseEntity<?> insertAuditChecklist(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Checklist 정보 수정", description = "Checklist 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/checklists/{checklistId}")
    public ResponseEntity<?> updateAuditChecklist(
            @PathVariable(value="checklistId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Checklist 버전 수정", description = "Checklist 버전 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/checklists/version/{checklistId}")
    public ResponseEntity<?> updateAuditCheckVersion(
            @PathVariable(value="checklistId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Checklist 삭제", description = "Checklist 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/checklists/{checklistId}")
    public ResponseEntity<?> deleteAuditChecklist(@PathVariable(value="checklistId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Chapter 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Chapter 목록 조회", description = "Chapter 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/chapters")
    public ResponseEntity<?> getAuditChapterList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Chapter 상세정보 조회", description = "Chapter 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> getAuditChapterInfo(@PathVariable(value="chapterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Chapter 등록", description = "신규 Chapter 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/chapters")
    public ResponseEntity<?> insertAuditChapter(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Chapter 정보 수정", description = "Chapter 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> updateAuditChapter(
            @PathVariable(value="chapterId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Chapter 삭제", description = "Chapter 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/chapters/{chapterId}")
    public ResponseEntity<?> deleteAuditChapter(@PathVariable(value="chapterId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }

    /**
     * Question 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "Question 목록 조회", description = "Question 목록 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/questions")
    public ResponseEntity<?> getAuditQuestionList(@RequestParam(value="searchWord", required=false) String searchWord) {

        return ResponseUtil.createSuccessResponse(List.of());
    }

    @Operation(summary = "Question 상세정보 조회", description = "Question 상세정보 조회 API")
    @GetMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> getAuditQuestionInfo(@PathVariable(value="questionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse(new GenericDto());
    }

    @Operation(summary = "신규 Question 등록", description = "신규 Question 등록 API")
    @PostMapping(value = "/audit/my-audit/creation/questions")
    public ResponseEntity<?> insertAuditQuestion(@Valid @RequestBody(required=true) GenericDto dto) {

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Question 정보 수정", description = "Question 정보 수정 API")
    @PutMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> updateAuditQuestion(
            @PathVariable(value="questionId", required=true) String key,
            @Valid @RequestBody(required=true) GenericDto dto) {

        dto.setKey(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Question 삭제", description = "Question 삭제 API")
    @DeleteMapping(value = "/audit/my-audit/creation/questions/{questionId}")
    public ResponseEntity<?> deleteAuditQuestion(@PathVariable(value="questionId", required=true) String key) {

        return ResponseUtil.createSuccessResponse();
    }
}
