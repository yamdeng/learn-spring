package com.koreanair.ksms.ocu.mgmt.service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.mgmt.dto.OcuTrainingDto;

@Service
public class OcuTrainingServiceImpl extends AbstractBaseService implements OcuTrainingService {

    public OcuTrainingDto selectOcuTraining(int id) {
        return commonSql.selectOne("OcuTraining.selectOcuTraining", id);
    }

    @Override
    public PageInfo<OcuTrainingDto> selectOcuTrainingList(OcuTrainingDto dto) {
        List<OcuTrainingDto> resultList = commonSql.selectList("OcuTraining.selectOcuTrainingList", dto);
        return PageInfo.of(resultList);
    }

    

    @Override
    public void insertOcuTraining(OcuTrainingDto dto) {
        commonSql.insert("OcuTraining.insertOcuTraining", dto);
    }

    @Override
    public void updateOcuTraining(OcuTrainingDto dto) {
        commonSql.update("OcuTraining.updateOcuTraining", dto);
    }

    @Override
    public void deleteOcuTraining(int id) {
        commonSql.delete("OcuTraining.deleteOcuTraining", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuTraining(List<OcuTrainingDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());
        // commonSql.save("OcuTraining", mapList);
    }
}
