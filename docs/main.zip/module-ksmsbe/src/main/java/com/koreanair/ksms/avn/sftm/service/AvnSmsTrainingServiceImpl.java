package com.koreanair.ksms.avn.sftm.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class AvnSmsTrainingServiceImpl extends AbstractBaseService implements AvnSmsTrainingService {
}
