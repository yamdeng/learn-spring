package com.koreanair.ksms.ocu.insp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.insp.dto.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class OcuInspectionServiceImpl extends AbstractBaseService implements OcuInspectionService {

    public OcuChecklistDto selectOcuChecklist(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuChecklist", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuChecklistDto> selectOcuChecklistList(OcuChecklistDto dto) {
        List<OcuChecklistDto> resultList = commonSql.selectList("OcuInspection.selectOcuChecklistList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuChecklist(OcuChecklistDto dto) {
        commonSql.insert("OcuInspection.insertOcuChecklist", dto);
    }

    @Override
    public void updateOcuChecklist(OcuChecklistDto dto) {
        commonSql.update("OcuInspection.updateOcuChecklist", dto);
    }

    @Override
    public void deleteOcuChecklist(int id) {
        commonSql.delete("OcuInspection.deleteOcuChecklist", id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuChecklist(List<OcuChecklistDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuChecklist", mapList);
    }
    

    public OcuChecklistItemDto selectOcuChecklistItem(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuChecklistItem", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuChecklistItemDto> selectOcuChecklistItemList(OcuChecklistItemDto dto) {
        List<OcuChecklistItemDto> resultList = commonSql.selectList("OcuInspection.selectOcuChecklistItemList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuChecklistItem(OcuChecklistItemDto dto) {
        commonSql.insert("OcuInspection.insertOcuChecklistItem", dto);
    }

    @Override
    public void updateOcuChecklistItem(OcuChecklistItemDto dto) {
        commonSql.update("OcuInspection.updateOcuChecklistItem", dto);
    }

    @Override
    public void deleteOcuChecklistItem(int id) {
        commonSql.delete("OcuInspection.deleteOcuChecklistItem", id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuChecklistItem(List<OcuChecklistItemDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuChecklistItem", mapList);
    }
    
    public OcuChecklistPlaceDto selectOcuChecklistPlace(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuChecklistPlace", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuChecklistPlaceDto> selectOcuChecklistPlaceList(OcuChecklistPlaceDto dto) {
        List<OcuChecklistPlaceDto> resultList = commonSql.selectList("OcuInspection.selectOcuChecklistPlaceList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuChecklistPlace(OcuChecklistPlaceDto dto) {
        commonSql.insert("OcuInspection.insertOcuChecklistPlace", dto);
    }

    @Override
    public void updateOcuChecklistPlace(OcuChecklistPlaceDto dto) {
        commonSql.update("OcuInspection.updateOcuChecklistPlace", dto);
    }

    @Override
    public void deleteOcuChecklistPlace(int id) {
        commonSql.delete("OcuInspection.deleteOcuChecklistPlace", id);
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuChecklistPlace(List<OcuChecklistPlaceDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuChecklistPlace", mapList);
    }


    public OcuPeriodicDto selectOcuPeriodic(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuPeriodic", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuPeriodicDto> selectOcuPeriodicList(OcuPeriodicDto dto) {
        List<OcuPeriodicDto> resultList = commonSql.selectList("OcuInspection.selectOcuPeriodicList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuPeriodic(OcuPeriodicDto dto) {
        commonSql.insert("OcuInspection.insertOcuPeriodic", dto);
    }

    @Override
    public void updateOcuPeriodic(OcuPeriodicDto dto) {
        commonSql.update("OcuInspection.updateOcuPeriodic", dto);
    }

    @Override
    public void deleteOcuPeriodic(int id) {
        commonSql.delete("OcuInspection.deleteOcuPeriodic", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuPeriodic(List<OcuPeriodicDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuPeriodic", mapList);
    }

    public OcuPeriodicContDto selectOcuPeriodicCont(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuPeriodicCont", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuPeriodicContDto> selectOcuPeriodicContList(OcuPeriodicContDto dto) {
        List<OcuPeriodicContDto> resultList = commonSql.selectList("OcuInspection.selectOcuPeriodicContList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuPeriodicCont(OcuPeriodicContDto dto) {
        commonSql.insert("OcuInspection.insertOcuPeriodicCont", dto);
    }

    @Override
    public void updateOcuPeriodicCont(OcuPeriodicContDto dto) {
        commonSql.update("OcuInspection.updateOcuPeriodicCont", dto);
    }

    @Override
    public void deleteOcuPeriodicCont(int id) {
        commonSql.delete("OcuInspection.deleteOcuPeriodicCont", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuPeriodicCont(List<OcuPeriodicContDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuPeriodicCont", mapList);
    }


    public OcuWalkaroundDto selectOcuWalkaround(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuWalkaround", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuWalkaroundDto> selectOcuWalkaroundList(OcuWalkaroundDto dto) {
        List<OcuWalkaroundDto> resultList = commonSql.selectList("OcuInspection.selectOcuWalkaroundList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuWalkaround(OcuWalkaroundDto dto) {
        commonSql.insert("OcuInspection.insertOcuWalkaround", dto);
    }

    @Override
    public void updateOcuWalkaround(OcuWalkaroundDto dto) {
        commonSql.update("OcuInspection.updateOcuWalkaround", dto);
    }

    @Override
    public void deleteOcuWalkaround(int id) {
        commonSql.delete("OcuInspection.deleteOcuWalkaround", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuWalkaround(List<OcuWalkaroundDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuWalkaround", mapList);
    }


    public OcuWalkaroundCheckDto selectOcuWalkaroundCheck(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuWalkaroundCheck", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuWalkaroundCheckDto> selectOcuWalkaroundCheckList(OcuWalkaroundCheckDto dto) {
        List<OcuWalkaroundCheckDto> resultList = commonSql.selectList("OcuInspection.selectOcuWalkaroundCheckList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuWalkaroundCheck(OcuWalkaroundCheckDto dto) {
        commonSql.insert("OcuInspection.insertOcuWalkaroundCheck", dto);
    }

    @Override
    public void updateOcuWalkaroundCheck(OcuWalkaroundCheckDto dto) {
        commonSql.update("OcuWalkaround.updateOcuWalkaroundCheck", dto);
    }

    @Override
    public void deleteOcuWalkaroundCheck(int id) {
        commonSql.delete("OcuInspection.deleteOcuWalkaroundCheck", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuWalkaroundCheck(List<OcuWalkaroundCheckDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuWalkaroundCheck", mapList);
    }


    public OcuWalkaroundContDto selectOcuWalkaroundCont(int id) {
        return commonSql.selectOne("OcuInspection.selectOcuWalkaroundCont", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public PageInfo<OcuWalkaroundContDto> selectOcuWalkaroundContList(OcuWalkaroundContDto dto) {
        List<OcuWalkaroundContDto> resultList = commonSql.selectList("OcuInspection.selectOcuWalkaroundContList", dto);
        return PageInfo.of(resultList);
    }

    @Override
    public void insertOcuWalkaroundCont(OcuWalkaroundContDto dto) {
        commonSql.insert("OcuInspection.insertOcuWalkaroundCont", dto);
    }

    @Override
    public void updateOcuWalkaroundCont(OcuWalkaroundContDto dto) {
        commonSql.update("OcuInspection.updateOcuWalkaroundCont", dto);
    }

    @Override
    public void deleteOcuWalkaroundCont(int id) {
        commonSql.delete("OcuInspection.deleteOcuWalkaroundCont", id);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void saveOcuWalkaroundCont(List<OcuWalkaroundContDto> dataList) {
        ObjectMapper objectMapper = new ObjectMapper();

        List<Map<String, Object>> mapList = dataList.stream()
                .map(dto -> (Map<String, Object>) objectMapper.convertValue(dto, Map.class))
                .collect(Collectors.toList());

        // commonSql.save("OcuWalkaroundCont", mapList);
    }

    @Override
    public PageInfo<OcuCorrectionDto> selectOcuCorrectionList(OcuCorrectionDto dto) {
        //통합개선 리스트 조회
        List<OcuCorrectionDto> resultList = commonSql.selectList("OcuInspection.selectOcuCorrectionList", dto);
        return PageInfo.of(resultList);
    }
}
