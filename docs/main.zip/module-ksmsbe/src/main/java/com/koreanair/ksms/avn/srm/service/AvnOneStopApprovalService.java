package com.koreanair.ksms.avn.srm.service;

public interface AvnOneStopApprovalService {
}
