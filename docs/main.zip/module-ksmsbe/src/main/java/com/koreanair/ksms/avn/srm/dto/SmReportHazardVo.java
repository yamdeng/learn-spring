package com.koreanair.ksms.avn.srm.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@ToString
public class SmReportHazardVo extends SmReportHazard {

    private KeHazardVo hazard;

    private KeConsequence consequence;

    private String nameKo;

    private String nameEn;

    private String statusNameKo;

    private String statusNameEn;
}
