package com.koreanair.ksms.ocu.risk.service;

import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

@Service
public class OcuHighRiskServiceImpl extends AbstractBaseService implements OcuHighRiskService {
}
