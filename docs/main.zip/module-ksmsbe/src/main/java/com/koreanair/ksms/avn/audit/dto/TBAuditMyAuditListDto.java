package com.koreanair.ksms.avn.audit.dto;

import com.koreanair.ksms.avn.audit.vo.ChecklistRevisionsVo;
import com.koreanair.ksms.common.dto.CommonDto;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;
import java.util.Map;


@Getter
@Setter
@ToString
@Schema(description = "MyAudit / MyAudit 목록")
public class TBAuditMyAuditListDto extends CommonDto {

    @Schema(description = "auditId")
    @NotNull
    private int auditId;

    @Schema(description = "auditNo")
    private String auditNo;

    @Schema(description = "auditAt")
    private String auditAt;

    @Schema(description = "title")
    private String title;

    private List<Map> auditors;

    private List<Map> cars;
}
