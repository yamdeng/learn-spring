package com.koreanair.ksms.ocu.gen.controller;

import com.koreanair.ksms.common.utils.ResponseUtil;
import com.koreanair.ksms.ocu.gen.service.OcuOrganizationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 안전경영 - 산업안전보건 조직도
 */
@Tag(name = "OcuOrganization", description = "안전경영 - 산업안전보건 조직도 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/ocu")
public class OcuOrganizationController {

    @Autowired
    OcuOrganizationService service;

    /**
     * 산업안전보건 조직도 목록 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "산업안전보건 조직도 목록 조회", description = "산업안전보건 조직도 목록 조회 API")
    @GetMapping(value = "/general/organizations")
    public ResponseEntity<?> getOrganizationList(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }

    /**
     * 조직 및 직무별 명단 조회
     *
     * @param searchWord the search word
     * @return the list
     * @throws Exception the exception
     */
    @Operation(summary = "조직 및 직무별 명단 조회", description = "조직 및 직무별 명단 조회 API")
    @GetMapping(value = "/general/organizations/infos")
    public ResponseEntity<?> getOrganizationInfo(@RequestParam(value="searchWord", required=false) String searchWord) {

        // 전체 조회
        return ResponseUtil.createSuccessResponse(List.of());
    }
}
