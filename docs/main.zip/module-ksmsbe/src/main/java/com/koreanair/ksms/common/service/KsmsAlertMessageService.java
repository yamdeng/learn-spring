package com.koreanair.ksms.common.service;

public interface KsmsAlertMessageService {

    void sendAlertMessageUser(String userId, String alertMsgText, String alertMsgLink);

    void sendAlertMessageDept(String deptCd, String alertMsgText, String alertMsgLink);

    void sendAlertMessageGroup(int groupId, String alertMsgText, String alertMsgLink);
}
