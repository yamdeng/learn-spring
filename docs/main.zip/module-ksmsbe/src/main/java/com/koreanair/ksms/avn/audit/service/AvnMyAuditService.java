package com.koreanair.ksms.avn.audit.service;

import com.koreanair.ksms.avn.audit.dto.*;

import java.util.List;

public interface AvnMyAuditService {

    // My Audit 현황 조회
    TBMyAuditStatisticsDto selectMyAuditStatistics(String searchDto);

    // My Audit 목록 조회
    List<TBMyAuditListDto> selectMyAuditList(String searchDto);
}
