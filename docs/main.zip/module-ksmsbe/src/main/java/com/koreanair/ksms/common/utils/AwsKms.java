package com.koreanair.ksms.common.utils;

import org.springframework.stereotype.Component;

// TODO [sixone] 임시 클래스
@Component
public class AwsKms {

    public String decrypt(String email) {

        return "";
    }
}
