package com.koreanair.ksms.common.dto;

import java.sql.Timestamp;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "레포트비행")
public class TbAvnReportFlightDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "출발일자")
    private String departureDt;
    
    @Schema(description = "비행번호")
    private String flightNo;
    
    @Schema(description = "등록번호")
    private String regNo;
    
    @Schema(description = "항공기유형코드")
    private String aircraftTypeCd;
    
    @Schema(description = "출발공항코드")
    private String departureAirportCd;
    
    @Schema(description = "도착공항코드")
    private String arrivalAirportCd;
    
    @Schema(description = "우회공항코드")
    private String divertAirportCd;
    
    @Schema(description = "출발계획시간")
    private String stdTime;
    
    @Schema(description = "출발실제시간")
    private String staTime;
    
    @Schema(description = "도착계획시간")
    private String atdTime;
    
    @Schema(description = "도착실제시간")
    private String ataTime;
    
    @Schema(description = "지연분수")
    private int delayedMinCo;
    
    @Schema(description = "보급명")
    private String supplyNm;
    
    @Schema(description = "체크인명")
    private String checkinNm;
    
    @Schema(description = "출발현지일시")
    private Timestamp departureLocDttm;
    
    @Schema(description = "출발계획현지시간")
    private String stdLocTime;
    
    @Schema(description = "출발실제현지시간")
    private String staLocTime;
    
    @Schema(description = "도착계획현지시간")
    private String atdLocTime;
    
    @Schema(description = "도착실제현지시간")
    private String ataLocTime;
    
    @Schema(description = "FDM파일번호명")
    private String fdmFileNoNm;
    
    @Schema(description = "이륙활주로명")
    private String takeoffRwyNm;
    
    @Schema(description = "착륙활주로명")
    private String landingRwyNm;
    
    @Schema(description = "PF직무명")
    private String pfDutyNm;
    
    @Schema(description = "PM직무명")
    private String pmDutyNm;
    
    @Schema(description = "PF비행시간수")
    private int pfFlightTimeCo;
    
    @Schema(description = "PM비행시간수")
    private int pmFlightTimeCo;
}
