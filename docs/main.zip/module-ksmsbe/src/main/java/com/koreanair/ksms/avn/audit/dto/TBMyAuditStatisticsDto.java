package com.koreanair.ksms.avn.audit.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;

@Getter
@Setter
@ToString
@Schema(description = "MyAudit / MyAuditStatistics")
public class TBMyAuditStatisticsDto {

    @Schema(description = "divAuditCnt")
    private int divAuditCnt;

    @Schema(description = "divFindingCompletedCnt")
    private int divFindingCompletedCnt;

    @Schema(description = "divFindingCnt")
    private int divFindingCnt;

    @Schema(description = "divFindingCompletedPer")
    private String divFindingCompletedPer;

    @Schema(description = "divObservationCompletedCnt")
    private int divObservationCompletedCnt;

    @Schema(description = "divObservationCnt")
    private int divObservationCnt;

    @Schema(description = "divObservationCompletedPer")
    private String divObservationCompletedPer;

    @Schema(description = "divDueCnt")
    private int divDueCnt;

    @Schema(description = "myAuditCnt")
    private int myAuditCnt;

    @Schema(description = "myFindingCompletedCnt")
    private int myFindingCompletedCnt;

    @Schema(description = "myFindingCnt")
    private int myFindingCnt;

    @Schema(description = "myFindingCompletedPer")
    private String myFindingCompletedPer;

    @Schema(description = "myObservationCompletedCnt")
    private int myObservationCompletedCnt;

    @Schema(description = "myObservationCnt")
    private int myObservationCnt;

    @Schema(description = "myObservationCompletedPer")
    private String myObservationCompletedPer;

    @Schema(description = "myDueCnt")
    private int myDueCnt;

    @Schema(description = "myProcessingAuditCnt")
    private int myProcessingAuditCnt;

    @Schema(description = "myProcessingPlanCnt")
    private int myProcessingPlanCnt;

    @Schema(description = "myProcessingConductCnt")
    private int myProcessingConductCnt;

    @Schema(description = "myProcessingCarCnt")
    private int myProcessingCarCnt;

    @Schema(description = "myProcessingDueCnt")
    private int myProcessingDueCnt;
}
