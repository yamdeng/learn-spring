package com.koreanair.ksms.common.controller;

import com.koreanair.ksms.common.service.KsmsAlertMessageService;
import com.koreanair.ksms.common.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Alert Message 테스트 컨트롤러
 */
@Tag(name = "KsmsAlertMessage", description = "Alert Message 테스트 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/com")
public class KsmsAlertMessageController {

    @Autowired
    KsmsAlertMessageService service;

    @Operation(summary = "메시지 알림(개인) 테스트", description = "메시지 알림(개인) 테스트 API")
    @Parameters({
            @Parameter(name = "userId", description = "수신자 ID(ADMIN 사용자의 아이디는 '1')"),
            @Parameter(name = "alertMsgText", description = "알림 메시지"),
            @Parameter(name = "alertMsgLink", description = "알림 메시지 링크")
    })
    @PostMapping(value = "/alert-messages/user")
    public ResponseEntity<?> sendAlertMessageUser(
            @RequestParam(value="userId", required = true, defaultValue = "1") String userId,
            @RequestParam(value="alertMsgText", required = true) String alertMsgText,
            @RequestParam(value="alertMsgLink", required = false) String alertMsgLink) {

        service.sendAlertMessageUser(userId, alertMsgText, alertMsgLink);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "메시지 알림(부서) 테스트", description = "메시지 알림(부서) 테스트 API")
    @Parameters({
            @Parameter(name = "deptCd", description = "수신자 부서코드"),
            @Parameter(name = "alertMsgText", description = "알림 메시지"),
            @Parameter(name = "alertMsgLink", description = "알림 메시지 링크")
    })
    @PostMapping(value = "/alert-messages/dept")
    public ResponseEntity<?> sendAlertMessageDept(
            @RequestParam(value="deptCd", required = true, defaultValue = "SELONP") String deptCd,
            @RequestParam(value="alertMsgText", required = true) String alertMsgText,
            @RequestParam(value="alertMsgLink", required = false) String alertMsgLink) {

        service.sendAlertMessageDept(deptCd, alertMsgText, alertMsgLink);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "메시지 알림(권한그룹) 테스트", description = "메시지 알림(권한그룹) 테스트 API")
    @Parameters({
            @Parameter(name = "groupId", description = "수신자 권한그룹ID"),
            @Parameter(name = "alertMsgText", description = "알림 메시지"),
            @Parameter(name = "alertMsgLink", description = "알림 메시지 링크")
    })
    @PostMapping(value = "/alert-messages/group")
    public ResponseEntity<?> sendAlertMessageGroup(
            @RequestParam(value="groupId", required = true, defaultValue = "1") int groupId,
            @RequestParam(value="alertMsgText", required = true) String alertMsgText,
            @RequestParam(value="alertMsgLink", required = false) String alertMsgLink) {

        service.sendAlertMessageGroup(groupId, alertMsgText, alertMsgLink);

        return ResponseUtil.createSuccessResponse();
    }
}
