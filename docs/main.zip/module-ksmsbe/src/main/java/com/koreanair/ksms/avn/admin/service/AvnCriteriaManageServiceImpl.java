package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.*;
import com.koreanair.ksms.common.service.AbstractBaseService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AvnCriteriaManageServiceImpl extends AbstractBaseService implements AvnCriteriaManageService {

    // Potential Consequesnce 목록 조회
    @Override
    public PageInfo<TbAvnConsequenceDto> selectConsequenceList(TbAvnConsequenceDto tbAvnConsequenceDto) {
        List<TbAvnConsequenceDto> resultList = commonSql.selectList("AvnCriteriaManage.selectConsequenceList", tbAvnConsequenceDto);
        return PageInfo.of(resultList);
    }

    // Potential Consequence 신규 등록
    @Override
    public void insertPotentialConsequence(TbAvnConsequenceDto tbAvnConsequenceDto) {
        commonSql.insert("AvnCriteriaManage.insertPotentialConsequence", tbAvnConsequenceDto);
    }
    
    // Potential Consequence 상세
    @Override
    public TbAvnConsequenceDto selectConsequenceDetail(String consequenceId) {
        return commonSql.selectOne("AvnCriteriaManage.selectConsequenceDetail", consequenceId);
    }
    
    // Potential Consequence 수정
    @Override
    public void updatePotentialConsequence(TbAvnConsequenceDto tbAvnConsequenceDto) {
        commonSql.update("AvnCriteriaManage.updatePotentialConsequence", tbAvnConsequenceDto);
    }

    // Potential Consequence 삭제
    @Override
    public void deletePotentialConsequence(String consequenceId) {
        commonSql.delete("AvnCriteriaManage.deletePotentialConsequence", consequenceId);
    }

    // Taxonomy 목록 조회
    @Override
    public PageInfo<TbAvnHazardLv3Dto> selectTaxonomyList(TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {
        List<TbAvnHazardLv3Dto> resultList = commonSql.selectList("AvnCriteriaManage.selectTaxonomyList", tbAvnHazardLv3Dto);
        return PageInfo.of(resultList);
    }

    // Taxonomy 신규 등록
    @Override
    public  void insertTaxonomy(TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {
        commonSql.insert("AvnCriteriaManage.insertTaxonomy", tbAvnHazardLv3Dto);
    }

    // Taxonomy 상세
    @Override
    public  TbAvnHazardLv3Dto selectTaxonomyDetail(String hazardLv3Id) {
        return commonSql.selectOne("AvnCriteriaManage.selectTaxonomyDetail", hazardLv3Id);
    }

    // Taxonomy 수정
    @Override
    public void updateTaxonomy(TbAvnHazardLv3Dto tbAvnHazardLv3Dto) {
        commonSql.update("AvnCriteriaManage.updateTaxonomy", tbAvnHazardLv3Dto);
    }

    // Taxonomy 삭제
    @Override
    public void deleteTaxonomy(String hazardLv3Id) {
        commonSql.delete("AvnCriteriaManage.deleteTaxonomy", hazardLv3Id);
    }

    // EventType 목록 조회
    @Override
    public PageInfo<TbAvnEventDto> selectEventTypeList(TbAvnEventDto tbAvnEventDto) {
        List<TbAvnEventDto> resultList = commonSql.selectList("AvnCriteriaManage.selectEventTypeList", tbAvnEventDto);
        return PageInfo.of(resultList);
    }

    // EventType 신규 등록
    @Override
    public  void insertEventType(TbAvnEventDto tbAvnEventDto) {
        commonSql.insert("AvnCriteriaManage.insertEventType", tbAvnEventDto);
    }

    // EventType 상세
    @Override
    public  TbAvnEventDto selectEventTypeDetail(String eventId) {
        return commonSql.selectOne("AvnCriteriaManage.selectEventTypeDetail", eventId);
    }

    // EventType 수정
    @Override
    public void updateEventType(TbAvnEventDto tbAvnEventDto) {
        commonSql.update("AvnCriteriaManage.updateEventType", tbAvnEventDto);
    }

    // EventType 삭제
    @Override
    public void deleteEventType(String eventId) {
        commonSql.delete("AvnCriteriaManage.deleteEventType", eventId);
    }
}
