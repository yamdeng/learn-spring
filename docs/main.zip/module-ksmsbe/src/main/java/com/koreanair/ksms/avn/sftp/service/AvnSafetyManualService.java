package com.koreanair.ksms.avn.sftp.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.dto.TbAvnManualDto;

public interface AvnSafetyManualService {
    //안전정책 > 안전매뉴얼 목록 조회
    PageInfo<TbAvnManualDto> selectSafetyManualList(TbAvnManualDto tbAvnManualDto);

    //안전정책 > 안전매뉴얼 상세 조회
    TbAvnManualDto selectSafetyManualInfo(int manualId);
}
