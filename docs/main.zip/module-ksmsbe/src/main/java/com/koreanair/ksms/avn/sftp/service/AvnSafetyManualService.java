package com.koreanair.ksms.avn.sftp.service;

public interface AvnSafetyManualService {
}
