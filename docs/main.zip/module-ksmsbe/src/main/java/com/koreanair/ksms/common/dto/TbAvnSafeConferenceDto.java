package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "안전회의")
public class TbAvnSafeConferenceDto extends CommonDto {
    
    @Schema(description = "안전회의 ID")
//    @NotBlank
    private int safeConferenceId;

    @Schema(description = "순번")
    private  int num;
    
    @Schema(description = "부문")
    private String division;
    
    @Schema(description = "회의구분")
    private String conferenceType;
    
    @Schema(description = "회의일자")
    private String conferenceDt;
    
    @Schema(description = "회의제목")
    private String conferenceTitle;
    
    @Schema(description = "첨부파일 ID")
    private int fileGroupSeq;

    @Schema(description = "사용여부")
    private String useYn;

    @Schema(description = "회의구분 별 count")
    private int typeCount;
    
    @Schema(description = "등록자명(한국어)")
    private String regUserNameKor;

    @Schema(description = "등록자명(영어)")
    private String regUserNameEng;

    @Schema(description = "수정자명(한국어)")
    private String updUserNameKor;

    @Schema(description = "수정자명(영어)")
    private String updUserNameEng;

}
