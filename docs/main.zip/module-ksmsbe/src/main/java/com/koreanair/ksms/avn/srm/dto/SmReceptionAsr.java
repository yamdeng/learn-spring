package com.koreanair.ksms.avn.srm.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import jakarta.validation.constraints.NotNull;

@Getter
@Setter
@ToString
@Schema(description = "접수 - ASR정보")
public class SmReceptionAsr {
    @NotNull
    private int id;

    @NotNull
    private int receptionId;

    @NotNull
    private int reportId;
}
