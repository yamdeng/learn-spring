package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = "SMS 강사 이력")
public class TbAvnInstructorHistDto extends CommonDto {
    
    @Schema(description = "사번")
    @NotBlank
    private String empNo;
    
    @Schema(description = "임용일자")
    @NotBlank
    private String employmentDt;
    
    @Schema(description = "임용구분")
    @NotBlank
    private String employmentType;
    
    @Schema(description = "임용여부")
    @NotBlank
    private String employmentYn;
    
    @Schema(description = "비고")
    private String notes;
    
    @Schema(description = "링크ID")
    private String linkGroupSeq;
    
    @Schema(description = "첨부파일")
    private String fileGroupSeq;
}
