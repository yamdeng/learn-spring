package com.koreanair.ksms.avn.srm.service;

import com.koreanair.ksms.avn.srm.dto.*;
import com.koreanair.ksms.common.dto.TbSysUserDto;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.common.service.KsmsCommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@Service
public class AvnReportFirstAssessmentServiceImpl extends AbstractBaseService implements AvnReportFirstAssessmentService {

    @Autowired
    KsmsCommonService ksmsCommonService;

    //@Override
/*

    public RiskAssessmentVo selectReportDetail(ReportDetailDto reportDetailDto) {

        String empNo = SecurityContextHolder.getContext().getAuthentication().getName();
        reportDetailDto.setP_isView(true);
        RiskAssessmentVo detail = riskAssessmentService.getRiskAssessmentDetail(reportDetailDto);


        RiskAssessmentVo detail = riskAssessmentService.getRiskAssessmentDetail(parameter, sessionInfo);



        return commonSql.selectOne("AvnReportReceipt.selectReportDetail", groupId);
    }

*/


}
