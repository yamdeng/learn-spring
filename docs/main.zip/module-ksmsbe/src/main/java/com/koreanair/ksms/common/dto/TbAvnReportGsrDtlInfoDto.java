package com.koreanair.ksms.common.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Schema(description = " 레포트_GSR_상세정보")
public class TbAvnReportGsrDtlInfoDto extends CommonDto {
    
    @Schema(description = "레포트ID")
    @NotBlank
    private int reportId;
    
    @Schema(description = "ID")
    @NotBlank
    private int id;
    
    @Schema(description = "레포트상세정보유형코드")
    private String reportDtlInfoTypeCd;
    
    @Schema(description = "항공기손상지역코드")
    private String aircraftDamageAreaCd;
    
    @Schema(description = "항공기손상내용")
    private String aircraftDamageCn;
    
    @Schema(description = "관련장비코드")
    private String relEquipCd;
    
    @Schema(description = "등록번호명")
    private String regNoNm;
    
    @Schema(description = "유지보수이력명")
    private String mntcHistNm;
    
    @Schema(description = "관련GSP코드")
    private String relGspCd;
    
    @Schema(description = "담당부서코드")
    private String chargeDeptCd;
    
    @Schema(description = "GSR내용")
    private String gsrCn;

    
    @Builder
    public TbAvnReportGsrDtlInfoDto(

            Integer reportId,
            Integer id,
            String reportDtlInfoTypeCd,
            String aircraftDamageAreaCd,
            String aircraftDamageCn,
            String relEquipCd,
            String regNoNm,
            String mntcHistNm,
            String relGspCd,
            String chargeDeptCd,
            String gsrCn

            ) {
        this.reportId = reportId == null ? 0 : reportId;
        this.id = id == null ? 0 : id;
        this.reportDtlInfoTypeCd = reportDtlInfoTypeCd;
        this.aircraftDamageAreaCd = aircraftDamageAreaCd;
        this.aircraftDamageCn = aircraftDamageCn;
        this.relEquipCd = relEquipCd;
        this.regNoNm = regNoNm;
        this.mntcHistNm = mntcHistNm;
        this.relGspCd = relGspCd;
        this.chargeDeptCd = chargeDeptCd;
        this.gsrCn = gsrCn;
    }
}
