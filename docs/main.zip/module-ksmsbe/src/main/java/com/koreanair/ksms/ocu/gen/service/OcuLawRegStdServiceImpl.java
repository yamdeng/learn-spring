package com.koreanair.ksms.ocu.gen.service;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestClient;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.common.service.AbstractBaseService;
import com.koreanair.ksms.ocu.gen.dto.OcuLawRegStdDto;
import com.koreanair.ksms.ocu.gen.dto.OcuRegulationDto;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

/**
 * 법규등록대장 기준 정보 serviceImpl
 */
@Slf4j
@Service
public class OcuLawRegStdServiceImpl extends AbstractBaseService implements OcuLawRegStdService {

	/**
	 * 법규등록대장 기준 정보 목록 조회
	 */
	@Override
	public PageInfo<OcuLawRegStdDto> selectOcuLawRegStdList(OcuLawRegStdDto dto) {
		
		List<OcuLawRegStdDto> resultList = commonSql.selectList("OcuLawRegStd.selectOcuLawRegStdList", dto);
		
	    return PageInfo.of(resultList);
	}

	/**
	 * 법규등록대장 기준 정보 상세 조회
	 */
	@Override
	public OcuLawRegStdDto selectOcuLawRegStd(String lawId) {
		return commonSql.selectOne("OcuLawRegStd.selectOcuLawRegStd", lawId);
	}

	/**
	 * 법규등록대장 기준 정보 등록
	 */
	@Override
	@Transactional
	public void insertOcuLawRegStd(@Valid OcuLawRegStdDto dto) {
		// 기준 정보
		commonSql.insert("OcuLawRegStd.insertOcuLawRegStd", dto);
		// 법령 정보
		commonSql.insert("OcuLawRegStd.insertOcuLawRegInfo", dto);
		
		//  부서에 메일 전송(추후) 
		
	}

	/**
	 * 법규등록대장 기준 정보 수정
	 */
	@Override
	@Transactional
	public void updateOcuLawRegStd(@Valid OcuLawRegStdDto dto) {
		// 기준 정보
		commonSql.update("OcuLawRegStd.updateOcuLawRegStd", dto);
		
		// 추후 작업필요 메일 전송 (부서)
		
	}

	/**
	 * 법규등록대장 기준 정보 삭제
	 */
	@Override
	@Transactional
	public void deleteOcuLawRegStd(String lawId) {
		// 법령 정보 삭제
		commonSql.delete("OcuLawRegStd.deleteOcuLawRegInfo", lawId);
		// 기준 정보 삭제
		commonSql.delete("OcuLawRegStd.deleteOcuLawRegStd", lawId);
	}

	/**
	 * 법규등록대장 존재 여부 체크
	 */
	@Override
	public int selectOcuLawRegInfoChk(String lawId) {
		return commonSql.selectOne("OcuLawRegStd.selectOcuLawRegInfoChk", lawId);
	}

	/**
	 * 기준 정보값 법규등록대장 존재 여부 체크
	 */
	@Override
	public List<OcuLawRegStdDto> selectLawBatchChk() {
		
		List<OcuLawRegStdDto> list = commonSql.selectList("OcuLawRegStd.selectLawBatchChk");

		return list;
	}
	

   
}
