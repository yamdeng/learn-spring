package com.koreanair.ksms.avn.admin.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.BoardSearchDto;
import com.koreanair.ksms.common.dto.GenericDto;
import com.koreanair.ksms.common.dto.TbAvnBoardDto;
import com.koreanair.ksms.common.dto.TbAvnManualDto;

public interface AvnBulletinManageService {


    
    // 게시판 관리 > 게시글 모음
    PageInfo<TbAvnBoardDto> selectBoardList(BoardSearchDto boardSearchDto);
    TbAvnBoardDto selectBoardDetail(int boardId);
    void insertBoard(TbAvnBoardDto tbAvnBoardDto);
    void updateBoard(TbAvnBoardDto tbAvnBoardDto);
    void deleteBoard(int boardId);


    List<GenericDto> selectList();

    //관리자 > 게시판 관리 > 안전정책 목록 조회
    PageInfo<TbAvnBoardDto> selectSafetyPolicisList(TbAvnBoardDto tbAvnBoardDto);

    //관리자 > 게시판 관리 > 안전정책 신규 등록
    void insertSafetyPolicy(TbAvnBoardDto tbAvnBoardDto);

    //관리자 > 게시판 관리 > 안전정책 상세
    TbAvnBoardDto selectSafetyPolicy(int boardId);

    //관리자 > 게시판 관리 > 안전정책 수정
    void updateSafetyPolicy(TbAvnBoardDto tbAvnBoardDto);

    //관리자 > 게시판 관리 > 안전정책 삭제
    void deleteSafetyPolicy(int boardId);

    //관리자 > 게시판 관리 > 안전매뉴얼 목록 조회
    PageInfo<TbAvnManualDto> selectManualList(TbAvnManualDto tbAvnManualDto);
    
    //관리자 > 게시판 관리 > 안전매뉴얼 신규 등록
    void insertManual(TbAvnManualDto tbAvnManualDto);

    //관리자 > 게시판 관리 > 안전매뉴얼 상세
    TbAvnManualDto selectManualInfo(int manualId);

    //관리자 > 게시판 관리 > 안전매뉴얼 수정
    void updateManual(TbAvnManualDto tbAvnManualDto);

    //관리자 > 게시판 관리 > 안전매뉴얼 삭제
    void deleteManual(int manualId);

    // 게시판 관리 > 배너관리 목록 조회
    PageInfo<TbAvnBoardDto> selectBannerList(TbAvnBoardDto tbAvnBoardDto);

    // 게시판 관리 > 배너관리 신규 등록
    void insertBanner(TbAvnBoardDto tbAvnBoardDto);

    // 게시판 관리 > 배너관리 상세
    TbAvnBoardDto selectBannerDetail(int boardId);

    // 게시판 관리 > 배너관리 수정
    void updateBanner(TbAvnBoardDto tbAvnBoardDto);

    // 게시판 관리 > 배너관리 삭제
    void deleteBanner(int boardId);
}
