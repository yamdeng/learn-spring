package com.koreanair.ksms.avn.admin.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.avn.admin.dto.TbBoardDto;
import com.koreanair.ksms.common.dto.GenericDto;

import java.util.List;

public interface AvnBulletinManageService {

    List<GenericDto> selectList();

    //관리자 > 게시판 관리 > 안전정책 목록 조회
    PageInfo<TbBoardDto> selectSafetyPolicisList(TbBoardDto tbBoardDto);

    //관리자 > 게시판 관리 > 안전정책 신규 등록
    void insertSafetyPolicy(TbBoardDto tbBoardDto);

    //관리자 > 게시판 관리 > 안전정책 상세
    TbBoardDto selectSafetyPolicy(String boardId);

    //관리자 > 게시판 관리 > 안전정책 수정
    void updateSafetyPolicy(TbBoardDto tbBoardDto);

    //관리자 > 게시판 관리 > 안전정책 삭제
    void deleteSafetyPolicy(String boardId);
}
