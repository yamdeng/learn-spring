package com.koreanair.ksms.avn.admin.service;

import com.koreanair.ksms.common.dto.GenericDto;

import java.util.List;

public interface AvnBulletinManageService {

    List<GenericDto> selectList();
}
