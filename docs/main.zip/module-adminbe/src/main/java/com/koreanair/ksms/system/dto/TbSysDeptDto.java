package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysDeptDto extends CommonDto {

    private int deptId; //부서ID
    private String deptCd; //부서코드
    private String nameKor; //명칭(한국어)
    private String nameEng; //명칭(영어)
    private String nameChn; //명칭(중국어)
    private String nameJpn; //명칭(일본어)
    private String nameEtc; //명칭(기타)
    private String upperDeptCd; //상위 ID
    private String treeType; //폴더구분
    private String fullPath; //전체경로
    private int sortOrder; //정렬순서
    private String rprsnUserId; //대표자ID
    private String compCd; //법인코드
    private String eaiYn; //EAI연동여부
    private String postName; //post_name
    private int level;
}
