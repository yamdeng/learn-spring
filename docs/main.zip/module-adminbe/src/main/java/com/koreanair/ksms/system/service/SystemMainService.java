package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysCodeDto;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;

import java.util.List;
import java.util.Map;

public interface SystemMainService {
    List<Map<String, Object>> selectLeftMenu(String workScope);

    List<TbSysCodeGroupDto> selectCodeGroupList();

    List<TbSysCodeDto> selectCodeList(String codeGrpId);

    List<TbSysCodeDto> selectCodeListAll();

    List<TbSysDeptDto> selectDeptList();

    List<TbSysUserDto> selectUserList(String searchWord, String deptCd);
}
