package com.koreanair.ksms.aspect;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.koreanair.ksms.aspect.annotations.NoRequestAndResposeLoggingAspect;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.text.NumberFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


@Slf4j
@Aspect
@Component
public class RequestAndResposeLoggingAspect extends LoggingAspect {

	// 응답결과가 10KB 가 넘을 경우 로그제외
	private static final int KILOBYTE = 1024;
	private static final int RESPONSE_SIZE_LIMIT = 20 * KILOBYTE;
	
	private static final String NEW_LINE = "\r\n";
	    
	@Around("loggingPointcut()")
	public Object logAndMonitor(ProceedingJoinPoint joinPoint) throws Throwable {
	    MethodSignature signature = (MethodSignature) joinPoint.getSignature();
	    String className = signature.getDeclaringTypeName();
	    String methodName = signature.getName();

	    // 메소드 파라미터 타입
	    StringBuilder builder = new StringBuilder();
	    builder.append("(");
	    for (Class<?> param : signature.getParameterTypes()) {
	    	builder.append(param.getSimpleName()).append(", ");
	    }
	    if (builder.length() > 1) {
	        builder.setLength(builder.length() - 2); // 마지막 쉼표와 공백 제거
	    }
	    builder.append(")");


	    ObjectMapper mapper = new ObjectMapper();
	    ObjectMapper mapperNotNull = new ObjectMapper();
	    mapperNotNull.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	    mapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
	    Object result = null;

	    boolean skipRequestLogging = false;
	    boolean skipResponseLogging = false;

	    // 메서드에 @NoRequestAndResposeLoggingAspect 애노테이션이 있는지 확인
	    Method method = signature.getMethod();
	    NoRequestAndResposeLoggingAspect annotation = method.getAnnotation(NoRequestAndResposeLoggingAspect.class);
	    if (annotation != null) {
	    	skipRequestLogging = annotation.skipRequestLogging();
	        skipResponseLogging = annotation.skipResponseLogging();
	    }

	    
        HttpServletRequest httpServletRequest = getHttpServletRequest();
        
	    // 요청 정보 수집
	    String requestUrlInfo = StringUtils.defaultString(getRequestUrl(httpServletRequest));
	    Map<String, Object> params = getParams(httpServletRequest, joinPoint);
	    String requestParam = mapperNotNull.writeValueAsString(params);
	    
	    final StopWatch stopWatch = new StopWatch();
	    stopWatch.start();
	    	    
	    try {
	        // 프로세스 실행
	        result = joinPoint.proceed(joinPoint.getArgs());
	        return result;
	    } catch (Exception e) {
	        throw e;
	    } finally {
	        stopWatch.stop();
	        
	        if (result == null) result = Collections.emptyMap();
	        
	        StringBuilder logMessage = new StringBuilder();
	        logMessage.append(NEW_LINE);
	        logMessage.append("[*] API   : ").append(requestUrlInfo).append(NEW_LINE);
	        logMessage.append("[*] Class : ").append(className).append(".").append(methodName).append(builder.toString()).append(NEW_LINE);
	        logMessage.append("[*] 실행시간 : ").append(stopWatch.getTotalTimeSeconds()).append(" s").append(NEW_LINE);
	        
	        if(skipRequestLogging) {
	        	logMessage.append("[*] 요청정보 : 로그출력 제외대상 (@NoRequestAndResposeLoggingAspect 옵션)").append(NEW_LINE);
	        }else {
	        	logMessage.append("[*] 요청정보 : ").append(NEW_LINE).append(requestParam).append(NEW_LINE).append(NEW_LINE);
	        }

	        if (skipResponseLogging) {
	        	logMessage.append("[*] 응답정보 : 로그출력 제외대상 (@NoRequestAndResposeLoggingAspect 옵션)");
	        }else {
	        	try {
	        		NumberFormat numberFormat = NumberFormat.getNumberInstance(Locale.US);
	            	
	        		String responseStr = mapper.writeValueAsString(result);
	                int responseSize = responseStr.getBytes(StandardCharsets.UTF_8).length;

	                if (responseSize > RESPONSE_SIZE_LIMIT) {
	                    logMessage.append("[*] 응답정보 : 데이터 양이 많아 로그출력 제외 (제한: ")
	                              .append(numberFormat.format(RESPONSE_SIZE_LIMIT / KILOBYTE)).append(" KB, 실제: ")
	                              .append(numberFormat.format(responseSize / KILOBYTE)).append(" KB)");
	                } else {
	                    logMessage.append("[*] 응답정보 : ").append(NEW_LINE).append(responseStr);
	                }
	            } catch (JsonProcessingException e) {
	                logMessage.append("[*] 응답정보 : ").append(result);
	            }
	        } 
	        
	        logMessage.append(NEW_LINE);
	        log.info(logMessage.toString());
	    }
	    
	}

	private HttpServletRequest getHttpServletRequest() {
		 return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
	}

	private Map<String, Object> getParams(HttpServletRequest request, JoinPoint joinPoint) {
	    Map<String, Object> params = new HashMap<>();

	    String method = request.getMethod();
	    
	    if("GET".equals(method)) {
		    if (request != null) {
		        Map<String, String[]> parameterMap = request.getParameterMap();
		        for (Map.Entry<String, String[]> entry : parameterMap.entrySet()) {
		            String key = entry.getKey();
		            String[] values = entry.getValue();
		            params.put(key, values.length > 1 ? String.join(",", values) : values[0]);
		        }
		    }
	    }else {
	    	// @RequestBody 
	    	Object[] args = joinPoint.getArgs();
	    	if (args.length > 0) {
	    		for(Object requestBody : args ) {	
	    			params.put(requestBody.getClass().getSimpleName(), requestBody);
	    		}
	    	}
	    }
	    
	    return params;
	}

	private String getRequestUrl(HttpServletRequest request) {
	    if (request != null) {
	        String method = request.getMethod();
	        
	        String requestUri = request.getRequestURI();
	        String queryString = request.getQueryString();
	        String fullUrl = queryString != null ? requestUri + "?" + queryString : requestUri;
	        
	        return String.format("%s %s", method, fullUrl);
	    }
	    return "";
	}
	
}




