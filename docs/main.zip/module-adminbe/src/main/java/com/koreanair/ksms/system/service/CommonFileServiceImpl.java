package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysFileDto;
import com.koreanair.ksms.utils.ResponseUtil;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
@Profile("!local")
public class CommonFileServiceImpl extends AbstractBaseService implements CommonFileService {

    @Override
    public List<TbSysFileDto> selectFileGroupList() {

        return commonSql.selectList("SystemFile.selectFileGroupList");
    }

    @Override
    public List<TbSysFileDto> selectFileList(int fileGroupSeq) {

        return commonSql.selectList("SystemFile.selectFileList", fileGroupSeq);
    }

    @Override
    public TbSysFileDto selectFileInfo(int fileSeq) {

        return commonSql.selectOne("SystemFile.selectFileInfo", fileSeq);
    }

    @Override
    public ResponseEntity<?> downloadFile(TbSysFileDto fileInfo) {

        return ResponseUtil.createSuccessResponse("TODO: 서버 환경에서 다운로드");
    }

    @Override
    public String uploadFile(String workScope, String fileGroupSeq, List<MultipartFile> files) {

        return "TODO: 서버 환경에서 업로드";
    }

    @Override
    public void deleteFile(int fileSeq) {

    }
}
