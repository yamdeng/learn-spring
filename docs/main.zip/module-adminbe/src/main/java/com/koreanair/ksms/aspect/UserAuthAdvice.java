package com.koreanair.ksms.aspect;

import com.koreanair.ksms.aspect.annotations.EnableAuth;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Aspect
@Component
public class UserAuthAdvice {

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private HttpServletRequest request;

	@SuppressWarnings("unchecked")
	@Around("@annotation(com.koreanair.ksms.aspect.annotations.EnableAuth) || @within(com.koreanair.ksms.aspect.annotations.EnableAuth)")
	public Object UserAuthentication(ProceedingJoinPoint point) throws Throwable {

		// @EnableAuth(role = { "ABC", "DEF" })
		MethodSignature signature = (MethodSignature) point.getSignature();

		// 권한 확인
		EnableAuth auth = Optional.ofNullable(signature.getMethod().getAnnotation(EnableAuth.class))
				.orElseGet(() -> (EnableAuth) signature.getDeclaringType().getAnnotation(EnableAuth.class));

		Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
		logger.debug("[ROLE CD] @EnableAuth: {} - Authorities: {}", Arrays.toString(auth.role()), authorities);

		List<String> roleList = authorities.stream()
				.map(GrantedAuthority::getAuthority)
				.collect(Collectors.toList());

		if (!Arrays.stream(auth.role()).anyMatch(roleList::contains)) {
			logger.warn("UserAuthentication FORBIDDEN(403) / You do not have permission to access");
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body("You do not have permission to access");
		}

		return point.proceed(point.getArgs());
	}
}
