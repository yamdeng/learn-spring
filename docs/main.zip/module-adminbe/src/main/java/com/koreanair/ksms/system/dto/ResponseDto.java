package com.koreanair.ksms.system.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.koreanair.ksms.constants.ResponseHeaderCode;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseDto<T> {
    private String successOrNot;
    private String statusCode;

    @JsonProperty("HeaderCd")
    private String headerCd;

    @JsonProperty("HeaderMsg")
    private String headerMsg;

    @JsonProperty("ItemCount")
    private int itemCount;

    private T data;
    private String errorCode;
    private String errorMessage;
    private String errorActor;

    @Builder
    public ResponseDto(
            String successOrNot,
            String statusCode,
            ResponseHeaderCode headerCd,
            String headerMsg,
            int itemCount,
            T data,
            String errorCode,
            String errorMessage,
            String errorActor) {
        this.successOrNot = successOrNot;
        this.statusCode = statusCode;
        this.headerCd = headerCd.getHeaderCode();
        this.headerMsg = headerMsg;
        this.itemCount = itemCount;
        this.data = data instanceof Integer ? null : data;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorActor = errorActor;
    }
}