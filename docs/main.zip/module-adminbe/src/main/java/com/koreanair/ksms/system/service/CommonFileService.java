package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysFileDto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface CommonFileService {

    List<TbSysFileDto> selectFileList(int fileGroupSeq);

    TbSysFileDto selectFileInfo(int fileSeq);

    List<TbSysFileDto> selectFileGroupList();

    ResponseEntity<?> downloadFile(TbSysFileDto fileInfo);

    Map<String, Object> uploadFile(String workScope, String fileGroupSeq, List<MultipartFile> files);

    void deleteFile(int fileSeq);
}
