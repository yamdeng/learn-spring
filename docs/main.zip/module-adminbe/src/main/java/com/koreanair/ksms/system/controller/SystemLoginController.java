package com.koreanair.ksms.system.controller;

import com.koreanair.ksms.system.dto.LoginRequestDto;
import com.koreanair.ksms.system.service.SystemLoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@Tag(name = "SystemLogin", description = "시스템 로그인 API")
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/auth")
public class SystemLoginController {

    private final SystemLoginService authService;

    @Operation(summary = "사번으로 로그인", description = "사번으로 로그인하는 API")
    @PostMapping("login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginRequestDto request) {

        Map<String, Object> tokens = this.authService.login(request);
        return ResponseEntity.status(HttpStatus.OK).body(tokens);
    }
}
