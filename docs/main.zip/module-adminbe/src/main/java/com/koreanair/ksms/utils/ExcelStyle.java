package com.koreanair.ksms.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFFont;

public class ExcelStyle {
    
    public static CellStyle getColumnHeaderStyle(SXSSFWorkbook excel) {
        XSSFFont font = (XSSFFont) excel.createFont();
        font.setBold(true);
        font.setColor(IndexedColors.WHITE.index);

        CellStyle style = excel.createCellStyle();
        style.setAlignment(HorizontalAlignment.CENTER);
        style.setFont(font);
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        style.setFillForegroundColor(IndexedColors.BLACK.getIndex());
        return style;
    }

    public static CellStyle getDefaultStyle(SXSSFWorkbook excel) {
        CellStyle style = excel.createCellStyle();
        return style;
    }

    public static CellStyle getDefaultNumberStyle(SXSSFWorkbook excel) {
        CellStyle style = excel.createCellStyle();
        return style;
    }

    public static CellStyle getDefaultDecimalStyle(SXSSFWorkbook excel) {
        CellStyle style = excel.createCellStyle();
        return style;
    }
}
