package com.koreanair.ksms.system.controller;

import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysMenuDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.dto.TbSysVirtualGroupDto;
import com.koreanair.ksms.system.service.SystemGroupService;
import com.koreanair.ksms.utils.JsonUtil;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 관리자 사이트 - 가상그룹관리
 */
@Tag(name = "SystemGroup", description = "시스템 가상그룹관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemGroupController {

    @Autowired
    SystemGroupService service;

    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "groupUsage", description = "그룹용도 검색. MENU: 메뉴 설정용, ROLE:산업안전 권한설정용"),
            @Parameter(name = "searchWord", description = "그룹코드 및 명칭검색")
    })
    @Operation(summary = "전체 가상그룹 목록 조회", description = "전체 가상그룹 목록 조회 API")
    @GetMapping(value = "/virtual-groups")
    public ResponseEntity<?> getVirtualGroupList(
            @RequestParam(value="workScope", required=false) String workScope,
            @RequestParam(value="groupUsage", required=false) String groupUsage,
            @RequestParam(value="searchWord", required=false) String searchWord){

        List<TbSysVirtualGroupDto> resultList = service.selectVirtualGroupList(workScope, groupUsage, searchWord);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "특정 가상그룹 하나의 상세정보 조회", description = "특정 가상그룹 하나의 상세정보 조회 API")
    @GetMapping(value = "/virtual-groups/{virtualGroupId}")
    public ResponseEntity<?> getVirtualGroupInfo(@PathVariable(value="virtualGroupId", required=true) int virtualGroupId){

        TbSysVirtualGroupDto result = service.selectVirtualGroup(virtualGroupId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 가상그룹 등록", description = "신규 가상그룹 insert API")
    @PostMapping(value = "/virtual-groups")
    public ResponseEntity<?> saveVirtualGroupInfo(@Valid @RequestBody(required=true) TbSysVirtualGroupDto dto){

        service.insertVirtualGroup(dto);
        return ResponseUtil.createSuccessResponse(dto);
    }

    @Operation(summary = "등록된 가상그룹 정보를 수정", description = "등록된 가상그룹 정보 update API")
    @PutMapping(value = "/virtual-groups/{virtualGroupId}")
    public ResponseEntity<?> updateVirtualGroupInfo(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @Valid @RequestBody(required=true) TbSysVirtualGroupDto dto){

        //dto.setGroupCd(virtualGroupId);
        dto.setGroupId(virtualGroupId);

        service.updateVirtualGroup(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "등록된 가상그룹 정보 삭제", description = "등록된 가상그룹 delete API")
    @DeleteMapping(value = "/virtual-groups/{virtualGroupId}")
    public ResponseEntity<?> deleteVirtualGroupInfo(@PathVariable(value="virtualGroupId", required=true) int virtualGroupId){

        service.deleteVirtualGroup(virtualGroupId);
        return ResponseUtil.createSuccessResponse();
    }

    /*****************************************************************************************************************/

    @Operation(summary = "가상그룹에 속해 있는 메뉴 목록 조회", description = "가상그룹에 속해 있는 메뉴 목록 조회 API")
    @GetMapping(value = "/virtual-groups/{virtualGroupId}/menus")
    public ResponseEntity<?> getVirtualGroupMenuList(@PathVariable(value="virtualGroupId", required=true) int virtualGroupId){

        List<Map<String, Object>> resultList = service.selectVirtualGroupMenuList(virtualGroupId);

        // 트리형태 JSON 으로 변경하여 리턴
        //return ResponseUtil.createSuccessResponse(JsonUtil.convertorTreeMap(resultList, "S000000", "menuId", "upperMenuId", "nameKor", "sort"));

        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "가상그룹에 메뉴 목록 추가", description = "가상그룹에 메뉴 목록 추가 API")
    @PutMapping(value = "/virtual-groups/{virtualGroupId}/menus")
    public ResponseEntity<?> addVirtualGroupMenuList(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @RequestBody(required=true) List<TbSysMenuDto> dtoList){

        service.addVirtualGroupMenuList(virtualGroupId, dtoList);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "가상그룹에서 사용가능 메뉴 제거", description = "가상그룹에서 사용가능 메뉴 제거 API")
    @DeleteMapping(value = "/virtual-groups/{virtualGroupId}/menus/{menuId}")
    public ResponseEntity<?> delVirtualGroupMenu(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @PathVariable(value="menuId", required=true) String menuId){

        service.delVirtualGroupMenu(virtualGroupId, menuId);

        return ResponseUtil.createSuccessResponse();
    }

    /*****************************************************************************************************************/

    @Operation(summary = "가상그룹에 속해 있는 사용자 목록 조회", description = "가상그룹에 속해 있는 사용자 목록 조회 API")
    @GetMapping(value = "/virtual-groups/{virtualGroupId}/users")
    public ResponseEntity<?> getVirtualGroupUserList(@PathVariable(value="virtualGroupId", required=true) int virtualGroupId){

        List<TbSysUserDto> resultList = service.selectVirtualGroupUserList(virtualGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "가상그룹에 사용자 목록 추가", description = "가상그룹에 사용자 목록 추가 API")
    @PutMapping(value = "/virtual-groups/{virtualGroupId}/users")
    public ResponseEntity<?> addVirtualGroupUserList(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @RequestBody(required=true) List<TbSysUserDto> dtoList){

        if(!dtoList.isEmpty()) {
            service.addVirtualGroupUserList(virtualGroupId, dtoList);
        }

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "가상그룹에서 사용자 제거", description = "가상그룹에서 사용자 제거 API")
    @DeleteMapping(value = "/virtual-groups/{virtualGroupId}/users/{userId}")
    public ResponseEntity<?> delVirtualGroupUser(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @PathVariable(value="userId", required=true) String userId){

        service.delVirtualGroupUser(virtualGroupId, userId);

        return ResponseUtil.createSuccessResponse();
    }

    /*****************************************************************************************************************/

    @Operation(summary = "가상그룹에 속해 있는 부서 목록 조회", description = "가상그룹에 속해 있는 부서 목록 조회 API")
    @GetMapping(value = "/virtual-groups/{virtualGroupId}/depts")
    public ResponseEntity<?> getVirtualGroupDeptList(@PathVariable(value="virtualGroupId", required=true) int virtualGroupId){

        List<TbSysDeptDto> resultList = service.selectVirtualGroupDeptList(virtualGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "가상그룹에 부서 목록 추가", description = "가상그룹에 부서 목록 추가 API")
    @PutMapping(value = "/virtual-groups/{virtualGroupId}/depts")
    public ResponseEntity<?> addVirtualGroupDeptList(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @RequestBody(required=true) List<TbSysDeptDto> dtoList){

        if(!dtoList.isEmpty()) {
            service.addVirtualGroupDeptList(virtualGroupId, dtoList);
        }

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "가상그룹에서 부서 제거", description = "가상그룹에서 부서 제거 API")
    @DeleteMapping(value = "/virtual-groups/{virtualGroupId}/depts/{deptId}")
    public ResponseEntity<?> delVirtualGroupDept(
            @PathVariable(value="virtualGroupId", required=true) int virtualGroupId,
            @PathVariable(value="deptId", required=true) int deptId){

        service.delVirtualGroupDept(virtualGroupId, deptId);

        return ResponseUtil.createSuccessResponse();
    }
}
