package com.koreanair.ksms.system.service;

import com.koreanair.ksms.constants.StatusCodeConstants;
import com.koreanair.ksms.exception.CustomBusinessException;
import com.koreanair.ksms.system.dto.CustomUserInfoDto;
import com.koreanair.ksms.system.dto.LoginRequestDto;
import com.koreanair.ksms.utils.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class SystemLoginServiceImpl extends AbstractBaseService implements SystemLoginService {

    private final JwtUtil jwtUtil;

    @Override
    public Map<String, Object> login(LoginRequestDto dto) {

        String empNo = dto.getEmpNo();
        CustomUserInfoDto userInfo = commonSql.selectOne("SystemLogin.selectUserInfo", empNo);

        if(userInfo == null) {
            throw new CustomBusinessException("사번이 존재하지 않습니다.", StatusCodeConstants.UNAUTHORIZED_ACCESS);
        }

        String accessToken = jwtUtil.createAccessToken(userInfo);
        String refreshToken = jwtUtil.createRefreshToken(userInfo);

        Map<String, Object> tokens = new HashMap<String, Object>();
        tokens.put("accessToken", accessToken);
        tokens.put("refreshToken", refreshToken);

        return tokens;
    }

    @Override
    public CustomUserInfoDto loadUserByUserId(String userId) {

        return commonSql.selectOne("SystemLogin.loadUserByUserId", userId);
    }
}
