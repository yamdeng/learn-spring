package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysMenuDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.dto.TbSysVirtualGroupDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class SystemGroupServiceImpl extends AbstractBaseService implements SystemGroupService {
    
    @Override
    public List<TbSysVirtualGroupDto> selectVirtualGroupList(String workScope, String groupUsage, String searchWord) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("workScope", workScope);
        param.put("groupUsage", groupUsage);
        param.put("searchWord", searchWord);

        return commonSql.selectList("SystemGroup.selectVirtualGroupList", param);
    }

    @Override
    public TbSysVirtualGroupDto selectVirtualGroup(int groupId) {

        return commonSql.selectOne("SystemGroup.selectVirtualGroup", groupId);
    }

    @Override
    public void insertVirtualGroup(TbSysVirtualGroupDto dto) {

        commonSql.insert("SystemGroup.insertVirtualGroup", dto);
    }

    @Override
    public void updateVirtualGroup(TbSysVirtualGroupDto dto) {

        commonSql.update("SystemGroup.updateVirtualGroup", dto);
    }

    @Override
    @Transactional
    public void deleteVirtualGroup(int groupId) {

        commonSql.delete("SystemGroup.deleteVirtualGroup", groupId);
    }

    /*****************************************************************************************************************/

    @Override
    public List<Map<String, Object>> selectVirtualGroupMenuList(int groupId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);

        return commonSql.selectList("SystemGroup.selectVirtualGroupMenuList", param);
    }

    @Override
    @Transactional
    public void addVirtualGroupMenuList(int groupId, List<TbSysMenuDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupMenuList", groupId);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupMenuList", param);
        }
    }

    @Override
    public void delVirtualGroupMenu(int groupId, String menuId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("menuId", menuId);

        commonSql.delete("SystemGroup.delVirtualGroupMenu", param);
    }

    /*****************************************************************************************************************/

    @Override
    public List<TbSysUserDto> selectVirtualGroupUserList(int groupId) {

        return commonSql.selectList("SystemGroup.selectVirtualGroupUserList", groupId);
    }

    @Override
    @Transactional
    public void addVirtualGroupUserList(int groupId, List<TbSysUserDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupUserList", groupId);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupUserList", param);
        }
    }

    @Override
    public void delVirtualGroupUser(int groupId, String userId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("userId", userId);

        commonSql.delete("SystemGroup.delVirtualGroupUser", param);
    }

    /*****************************************************************************************************************/

    @Override
    public List<TbSysDeptDto> selectVirtualGroupDeptList(int groupId) {

        return commonSql.selectList("SystemGroup.selectVirtualGroupDeptList", groupId);
    }

    @Override
    @Transactional
    public void addVirtualGroupDeptList(int groupId, List<TbSysDeptDto> dtoList) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("list", dtoList);

        commonSql.delete("SystemGroup.delVirtualGroupDeptList", groupId);

        if(!dtoList.isEmpty()) {
            commonSql.insert("SystemGroup.addVirtualGroupDeptList", param);
        }
    }

    @Override
    public void delVirtualGroupDept(int groupId, int deptId) {

        Map<String, Object> param = new HashMap<String, Object>();
        param.put("groupId", groupId);
        param.put("deptId", deptId);

        commonSql.delete("SystemGroup.delVirtualGroupDept", param);
    }
}
