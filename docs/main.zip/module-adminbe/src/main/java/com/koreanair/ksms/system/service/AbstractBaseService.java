package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dao.CommonSqlDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * <pre>
 * Restful service가 상속하는 최상위 추상 class
 * 
 * </pre>
 */
public abstract class AbstractBaseService {

	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	@Qualifier("commonSql")
	protected CommonSqlDao commonSql;

}
