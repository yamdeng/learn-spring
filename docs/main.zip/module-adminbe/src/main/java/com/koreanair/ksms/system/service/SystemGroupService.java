package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysMenuDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.dto.TbSysVirtualGroupDto;

import java.util.List;
import java.util.Map;

public interface SystemGroupService {

    List<TbSysVirtualGroupDto> selectVirtualGroupList(String workScope, String groupUsage, String searchWord);
    TbSysVirtualGroupDto selectVirtualGroup(String groupCd);
    void insertVirtualGroup(TbSysVirtualGroupDto dto);
    void updateVirtualGroup(TbSysVirtualGroupDto dto);
    void deleteVirtualGroup(String groupCd);

    List<Map<String, Object>> selectVirtualGroupMenuList(String groupCd);
    void addVirtualGroupMenuList(String groupCd, List<TbSysMenuDto> dtoList);
    void delVirtualGroupMenu(String groupCd, String menuId);

    List<TbSysUserDto> selectVirtualGroupUserList(String groupCd);
    void addVirtualGroupUserList(String groupCd, List<TbSysUserDto> dtoList);
    void delVirtualGroupUser(String groupCd, String userId);

    List<TbSysDeptDto> selectVirtualGroupDeptList(String groupCd);
    void addVirtualGroupDeptList(String groupCd, List<TbSysDeptDto> dtoList);
    void delVirtualGroupDept(String groupCd, String deptCd);
}
