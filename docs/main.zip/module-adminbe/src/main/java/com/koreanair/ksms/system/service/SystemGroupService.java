package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysMenuDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.dto.TbSysVirtualGroupDto;

import java.util.List;
import java.util.Map;

public interface SystemGroupService {

    List<TbSysVirtualGroupDto> selectVirtualGroupList(String workScope, String groupUsage, String searchWord);
    TbSysVirtualGroupDto selectVirtualGroup(int groupId);
    void insertVirtualGroup(TbSysVirtualGroupDto dto);
    void updateVirtualGroup(TbSysVirtualGroupDto dto);
    void deleteVirtualGroup(int groupId);

    List<Map<String, Object>> selectVirtualGroupMenuList(int groupId);
    void addVirtualGroupMenuList(int groupId, List<TbSysMenuDto> dtoList);
    void delVirtualGroupMenu(int groupId, String menuId);

    List<TbSysUserDto> selectVirtualGroupUserList(int groupId);
    void addVirtualGroupUserList(int groupId, List<TbSysUserDto> dtoList);
    void delVirtualGroupUser(int groupId, String userId);

    List<TbSysDeptDto> selectVirtualGroupDeptList(int groupId);
    void addVirtualGroupDeptList(int groupId, List<TbSysDeptDto> dtoList);
    void delVirtualGroupDept(int groupId, int deptId);
}
