package com.koreanair.ksms.config;

import com.koreanair.ksms.model.AccessApiModel;
import lombok.Getter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Getter
@Configuration
@ConfigurationProperties(prefix = "access-control")
public class AccessApiConfig {
    private final Map<String, AccessApiModel> menu = new HashMap<>();

}