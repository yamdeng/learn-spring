package com.koreanair.ksms.system.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.service.SystemDeptService;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * 관리자 사이트 - 부서관리
 */
@Tag(name = "SystemDept", description = "시스템 부서관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemDeptController {

    @Autowired
    SystemDeptService service;

    @Operation(summary = "전체 부서 목록 조회", description = "전체 부서 목록 조회 API")
    @GetMapping(value = "/depts")
    public ResponseEntity<?> getDeptList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum
            ,@RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize
            ,@RequestParam(value="searchWord", required=false) String searchWord){

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysDeptDto> pageList = service.selectDeptListPage(searchWord);
        return ResponseUtil.createSuccessResponse(pageList);
    }

    @Operation(summary = "특정 부서 하나의 상세정보 조회", description = "특정 부서 하나의 상세정보 조회 API")
    @GetMapping(value = "/depts/{deptId}")
    public ResponseEntity<?> getDeptInfo(@PathVariable(value="deptId", required=true) int deptId){

        TbSysDeptDto result = service.selectDept(deptId);
        return ResponseUtil.createSuccessResponse(result);
    }
}
