package com.koreanair.ksms.system.service;

import com.koreanair.ksms.exception.CustomBusinessException;
import com.koreanair.ksms.system.dto.TbSysFileDto;
import com.koreanair.ksms.utils.CommonUtil;
import com.koreanair.ksms.utils.DateUtil;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@Profile("local")
public class CommonFileServiceImplLocal extends AbstractBaseService implements CommonFileService {

    @Value("${aws.s3.rootPath}")
    private String rootPath;

    @Override
    public List<TbSysFileDto> selectFileGroupList() {

        return commonSql.selectList("CommonFile.selectFileGroupList");
    }

    @Override
    public List<TbSysFileDto> selectFileList(int fileGroupSeq) {

        return commonSql.selectList("CommonFile.selectFileList", fileGroupSeq);
    }

    @Override
    public TbSysFileDto selectFileInfo(int fileSeq) {

        return commonSql.selectOne("CommonFile.selectFileInfo", fileSeq);
    }
    
    @Override
    public ResponseEntity<?> downloadFile(TbSysFileDto fileInfo) {

        String filePath = rootPath + fileInfo.getS3Path() + fileInfo.getFileOid();
        byte[] bytes = null;

        try {
            bytes = Files.readAllBytes(new File(filePath).toPath());
        } catch(IOException e) {
            throw new CustomBusinessException("파일 다운로드 중 오류가 발생했습니다.");
        }

        ByteArrayResource resource = new ByteArrayResource(bytes);

        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + URLEncoder.encode(fileInfo.getOrigFilename()));
        header.add("Content-Transfer-Encoding", "binary");

        return ResponseEntity.ok()
                .headers(header)
                .contentLength(bytes.length)
                .contentType(MediaType.parseMediaType(CommonUtil.getMimeType(fileInfo.getFileExt())))
                .body(resource);
    }

    @Override
    public Map<String, Object> uploadFile(String workScope, String fileGroupSeq, List<MultipartFile> files) {

        /*
        1. fileGroupSeq가 없을 경우, 신규 그룹 생성
        2. fileGroupSeq가 있을 경우, 올바른 번호인지 검사
        3. 저장소에 파일 저장
        4. tb_sys_file 테이블에 데이터 생성
        5. 생성된 fileGroupSeq 리턴

        ** 파일 저장 디렉토리: rootPath + /시스템구분/yyyyMMdd
           시스템: SYSTEM
           항공안전: AVIATION
           산업안전: OCCUPATIONAL
        */

        Map<String, Object> result = new HashMap<>();
        List<TbSysFileDto> fileList = new ArrayList<>();

        Map<String, String> param = new HashMap<String, String>();
        param.put("workScope", workScope);
        param.put("regUserId", "regUserId");

        // 파일 그룹을 생성
        if(fileGroupSeq == null || "".equals(fileGroupSeq)) {
            int cnt = commonSql.insert("CommonFile.makeFileGroup", param);
            fileGroupSeq = String.valueOf(param.get("fileGroupSeq"));
        } else {
            int cnt = commonSql.selectOne("CommonFile.checkFileGroupSeq", Integer.parseInt(fileGroupSeq));
            if(cnt != 1) throw new CustomBusinessException("올바른 fileGroupSeq가 아닙니다.");
        }

        // 파일 정보
        String today = DateUtil.now("yyyyMMdd");

        for(MultipartFile file : files) {
            String fileName = file.getOriginalFilename();
            String fileExt = fileName.substring(fileName.lastIndexOf(".") + 1);
            String fileOid = CommonUtil.generateUniqueKey();
            String fileS3Path = "S".equals(workScope) ? "/SYSTEM/" :
                                "A".equals(workScope) ? "/AVIATION/" :
                                "O".equals(workScope) ? "/OCCUPATIONAL/" :
                                "DEFAULT";
            fileS3Path = fileS3Path + today + "/";

            // 파일 저장
            try {
                FileUtils.forceMkdir(new File(rootPath + fileS3Path));
                FileUtils.copyToFile(file.getInputStream(), new File(rootPath + fileS3Path + fileOid));
            } catch(IOException e) {
                throw new CustomBusinessException("파일 생성시 문제가 발생했습니다.");
            }

            // 파일 정보 DB Insert
            TbSysFileDto fileInfo = new TbSysFileDto();
            fileInfo.setFileGroupSeq(Integer.parseInt(fileGroupSeq));
            fileInfo.setOrigFilename(fileName);
            fileInfo.setFileExt(fileExt);
            fileInfo.setFileSize(file.getSize());
            fileInfo.setFileOid(fileOid);
            fileInfo.setS3Path(fileS3Path);

            commonSql.insert("CommonFile.insertFileInfo", fileInfo);

            fileList.add(fileInfo);
        }

        result.put("fileGroupSeq", fileGroupSeq);
        result.put("fileList", fileList);

        return result;
    }

    @Override
    public void deleteFile(int fileSeq) {

        // 파일 정보 update
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("fileSeq", fileSeq);
        param.put("updUserId", "updUserId");

        commonSql.update("CommonFile.deleteFileInfo", param);

        // 실제 파일 삭제: 삭제하지 않음.
    }
}