package com.koreanair.ksms.system.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysCodeDto extends CommonDto {

    @NotBlank
    @Size(max=30)
    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
    private String codeGrpId;

    @NotBlank
    @Size(max=255)
    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
    private String codeId;

    @NotBlank
    @Size(max=250)
    private String codeNameKor;

    @NotBlank
    @Size(max=250)
    private String codeNameEng;

    private String codeField1;
    private String codeField2;
    private String codeField3;
    private String codeField4;
    private String codeField5;
    private int sortOrder;
    private String useYn;
    private String remark;
}
