package com.koreanair.ksms.system.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class TbSysVirtualGroupDto extends CommonDto {

    private int groupId;

    @NotBlank
    @Size(max=30)
    //@Pattern(regexp="^[A-Z0-9_]+$") // 영문 대문자, 숫자, "_" 문자만 허용
    private String groupCd;

    @Size(max=1)
    @Pattern(regexp="^[AOS]$") // A, O, S 중의 한 문자만 입력
    private String workScope;

    @Pattern(regexp="^(MENU|ROLE)$") // MENU(메뉴설정용), ROLE(산업안전 권한용)
    private String groupUsage;

    private String nameKor;
    private String nameEng;
    private String nameChn;
    private String nameJpn;
    private String nameEtc;
    private String remark;
    private String useYn;
    private String auditAdminYn;
    private String reportType;
    private String groupAdminYn;
}
