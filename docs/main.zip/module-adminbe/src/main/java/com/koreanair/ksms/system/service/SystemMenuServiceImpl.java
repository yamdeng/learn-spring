package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysMenuDto;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class SystemMenuServiceImpl extends AbstractBaseService implements SystemMenuService {
    @Override
    public List<Map<String, Object>> selectMenuList(String workScope) {

        return commonSql.selectList("SystemMenu.selectMenuList", workScope);
    }

    @Override
    public TbSysMenuDto selectMenu(String menuId) {

        return commonSql.selectOne("SystemMenu.selectMenu", menuId);
    }

    @Override
    public void insertMenu(TbSysMenuDto dto) {

        commonSql.insert("SystemMenu.insertMenu", dto);
    }

    @Override
    public void updateMenu(TbSysMenuDto dto) {

        commonSql.update("SystemMenu.updateMenu", dto);
    }

    @Override
    public void deleteMenu(String menuId) {

        commonSql.delete("SystemMenu.deleteMenu", menuId);
    }
}
