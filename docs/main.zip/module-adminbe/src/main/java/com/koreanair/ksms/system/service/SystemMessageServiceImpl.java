package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysMessageDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SystemMessageServiceImpl extends AbstractBaseService implements SystemMessageService {

    @Override
    public List<TbSysMessageDto> selectMessageList(String searchWord) {

        return commonSql.selectList("SystemMessage.selectMessageList", searchWord);
    }

    @Override
    public PageInfo<TbSysMessageDto> selectMessageListPage(String searchWord) {

        List<TbSysMessageDto> resultList = commonSql.selectList("SystemMessage.selectMessageList", searchWord);
        return PageInfo.of(resultList);
    }

    @Override
    public TbSysMessageDto selectMessage(String messageId) {

        return commonSql.selectOne("SystemMessage.selectMessage", messageId);
    }

    @Override
    public void insertMessage(TbSysMessageDto dto) {

        commonSql.insert("SystemMessage.insertMessage", dto);
    }

    @Override
    public void updateMessage(TbSysMessageDto dto) {

        commonSql.update("SystemMessage.updateMessage", dto);
    }

    @Override
    public void deleteMessage(String messageId) {

        commonSql.delete("SystemMessage.deleteMessage", messageId);
    }
}
