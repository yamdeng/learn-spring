package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
public class ErrorResponseDto {

    private int value;
    private String message;
    private LocalDateTime now;

    public ErrorResponseDto(int value, String message, LocalDateTime now) {
        this.value = value;
        this.message = message;
        this.now = now;
    }
}
