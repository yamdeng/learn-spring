package com.koreanair.ksms.system.controller;

import com.koreanair.ksms.system.dto.TbSysCodeDto;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.system.service.SystemCodeService;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 관리자 사이트 - 공통코드관리
 */
@Tag(name = "SystemCode", description = "시스템 공통코드관리 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemCodeController {

    @Autowired
    SystemCodeService service;

    @Operation(summary = "전체 코드그룹 목록 조회", description = "전체 코드그룹 목록 조회 API")
    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "searchWord", description = "코드그룹/코드그룹명 검색")

    })
    @GetMapping(value = "/code-groups")
    public ResponseEntity<?> getCodeGroupList(
            @RequestParam(value="workScope", required=false) String workScope,
            @RequestParam(value="searchWord", required=false) String searchWord) {

        List<TbSysCodeGroupDto> resultList = service.selectCodeGroupList(workScope, searchWord);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "특정 코드그룹 하나의 상세정보 조회", description = "특정 코드그룹 하나의 상세정보 조회 API")
    @GetMapping(value = "/code-groups/{codeGroupId}")
    public ResponseEntity<?> getCodeGroupInfo(@PathVariable(value="codeGroupId", required=true) String codeGroupId){

        TbSysCodeGroupDto result = service.selectCodeGroup(codeGroupId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 코드그룹 등록", description = "신규 코드그룹 insert API")
    @PostMapping(value = "/code-groups")
    public ResponseEntity<?> saveCodeGroupInfo(@Valid @RequestBody(required=true) TbSysCodeGroupDto dto){

        service.insertCodeGroup(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "등록된 코드그룹 정보를 수정", description = "등록된 코드그룹 정보 update API")
    @PutMapping(value = "/code-groups/{codeGroupId}")
    public ResponseEntity<?> updateCodeGroupInfo(
            @PathVariable(value="codeGroupId", required=true) String codeGroupId,
            @Valid @RequestBody(required=true) TbSysCodeGroupDto dto){

        dto.setCodeGrpId(codeGroupId);

        service.updateCodeGroup(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "등록된 코드그룹 정보 삭제", description = "등록된 코드그룹 delete API")
    @DeleteMapping(value = "/code-groups/{codeGroupId}")
    public ResponseEntity<?> deleteCodeGroupInfo(@PathVariable(value="codeGroupId", required=true) String codeGroupId){

        service.deleteCodeGroup(codeGroupId);
        return ResponseUtil.createSuccessResponse();
    }

    /*****************************************************************************************************************/

    @Operation(summary = "전체 코드 목록 조회", description = "전체 코드 목록 조회 API")
    @GetMapping(value = "/code-groups/{codeGroupId}/codes")
    public ResponseEntity<?> getCodeList(@PathVariable(value="codeGroupId", required=true) String codeGroupId){

        List<TbSysCodeDto> resultList = service.selectCodeList(codeGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "특정 코드 하나의 상세정보 조회", description = "특정 코드 하나의 상세정보 조회 API")
    @GetMapping(value = "/code-groups/{codeGroupId}/codes/{codeId}")
    public ResponseEntity<?> getCodeInfo(
            @PathVariable(value="codeGroupId", required=true) String codeGroupId,
            @PathVariable(value="codeId", required=true) String codeId){

        TbSysCodeDto result = service.selectCode(codeGroupId, codeId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "신규 코드 등록", description = "신규 코드 insert API")
    @PostMapping(value = "/code-groups/{codeGroupId}/codes")
    public ResponseEntity<?> saveCodeInfo(
            @PathVariable(value="codeGroupId", required=true) String codeGroupId,
            @Valid @RequestBody(required=true) List<TbSysCodeDto> dtoList){

        // 코드 건별 저장
        //service.insertCode(dto);

        // 코드 일괄 저장
        service.saveCode(codeGroupId, dtoList);

        return ResponseUtil.createSuccessResponse();
    }

    /*
    @Operation(summary = "등록된 코드 정보를 수정", description = "등록된 코드 정보 update API")
    @PutMapping(value = "/code-groups/{codeGroupId}/codes/{codeId}")
    public ResponseEntity<?> updateCodeInfo(
            @PathVariable(value="codeGroupId", required=true) String codeGroupId,
            @PathVariable(value="codeId", required=true) String codeId,
            @Valid @RequestBody(required=true) TbSysCodeDto dto){

        dto.setCodeGrpId(codeGroupId);
        dto.setCodeId(codeId);

        service.updateCode(dto);
        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "등록된 코드를 삭제", description = "등록된 코드 delete API")
    @DeleteMapping(value = "/code-groups/{codeGroupId}/codes/{codeId}")
    public ResponseEntity<?> deleteCodeInfo(@PathVariable(value="codeGroupId", required=true) String codeGroupId,
                                            @PathVariable(value="codeId", required=true) String codeId){

        service.deleteCode(codeGroupId, codeId);
        return ResponseUtil.createSuccessResponse();
    }
    */
}
