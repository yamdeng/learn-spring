package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysDeptDto;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SystemDeptServiceImpl extends AbstractBaseService implements SystemDeptService {

    @Override
    public PageInfo<TbSysDeptDto> selectDeptListPage(String searchWord) {

        List<TbSysDeptDto> resultList = commonSql.selectList("SystemDept.selectDeptList", searchWord);
        return PageInfo.of(resultList);
    }

    @Override
    public List<TbSysDeptDto> selectDeptListTree() {

        return commonSql.selectList("SystemDept.selectDeptTree");
    }

    @Override
    public TbSysDeptDto selectDept(String deptCd) {

        return commonSql.selectOne("SystemDept.selectDept", deptCd);
    }
}
