package com.koreanair.ksms.system.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserInfoDto {

    private String userId;
    private String empNo;
    private String email;
    private String role;
}
