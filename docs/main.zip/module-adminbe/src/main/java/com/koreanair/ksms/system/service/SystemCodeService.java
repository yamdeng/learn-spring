package com.koreanair.ksms.system.service;

import com.koreanair.ksms.system.dto.TbSysCodeDto;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;

import java.util.List;

public interface SystemCodeService {

    List<TbSysCodeGroupDto> selectCodeGroupList(String workScope, String searchWord);
    TbSysCodeGroupDto selectCodeGroup(String codeGrpId);
    void insertCodeGroup(TbSysCodeGroupDto dto);
    void updateCodeGroup(TbSysCodeGroupDto dto);
    void deleteCodeGroup(String codeGroupId);

    List<TbSysCodeDto> selectCodeList(String codeGrpId);
    TbSysCodeDto selectCode(String codeGrpId, String codeId);
    void insertCode(TbSysCodeDto dto);
    void updateCode(TbSysCodeDto dto);
    void deleteCode(String codeGroupId, String codeId);
    void saveCode(String codeGrpId, List<TbSysCodeDto> dtoList);

}
