package com.koreanair.ksms.system.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.aspect.annotations.EnableAuth;
import com.koreanair.ksms.system.dto.*;
import com.koreanair.ksms.system.service.SystemMainService;
import com.koreanair.ksms.utils.DateUtil;
import com.koreanair.ksms.utils.JsonUtil;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.vertx.core.json.JsonObject;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 관리자 사이트 - 메인화면 Controller
 */
@Tag(name = "SystemMain", description = "시스템 메인화면 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemMainController {

    @Autowired
    SystemMainService service;

    @Operation(summary = "좌측 메뉴 조회", description = "시스템 좌측 메뉴를 조회하는 API")
    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "isTree", description = "빈값이거나 Y 일경우 Tree형태로 조회, 아니면 List로 조회")

    })
    @GetMapping(value = "/left-menus")
    public ResponseEntity<?> getAdminLeftMenus(
            @RequestParam(value="workScope", required=true, defaultValue="S") String workScope,
            @RequestParam(value="isTree", required=false, defaultValue="Y") String isTree) {

        List<Map<String, Object>> resultList = service.selectLeftMenu(workScope);

        // 관리자 사이트의 경우, 사용 가능한 메뉴가 없으면 HTTP 403으로 리턴한다.
        if(resultList.isEmpty()) {
            return ResponseUtil.createFailResponse(HttpStatus.FORBIDDEN);
        }

        if("Y".equals(isTree)) {
            // 트리형태 JSON 으로 변경하여 리턴
            return ResponseUtil.createSuccessResponse(JsonUtil.convertorTreeMap(resultList, "S000000", "menuId", "upperMenuId", "nameKor", "sort"));
        }

        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드그룹 목록 조회", description = "전체 코드그룹 목록 조회 API")
    @GetMapping(value = "/common/code-groups")
    public ResponseEntity<?> getCodeGroupList() {

        List<TbSysCodeGroupDto> resultList = service.selectCodeGroupList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "코드 그룹의 코드목록 조회", description = "코드 그룹의 코드목록 조회 API")
    @GetMapping(value = "/common/code-groups/{codeGroupId}/codes")
    public ResponseEntity<?> getCodeList(@PathVariable(value="codeGroupId", required=true) String codeGroupId) {

        List<TbSysCodeDto> resultList = service.selectCodeList(codeGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드목록 조회", description = "그룹정보를 포함한 전체 코드목록 조회 API")
    @GetMapping(value = "/common/code-groups/codes/all")
    public ResponseEntity<?> getCodeListAll() {

        List<TbSysCodeDto> resultList = service.selectCodeListAll();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 부서 목록 조회", description = "전체 부서 목록 조회 API")
    @GetMapping(value = "/common/depts")
    public ResponseEntity<?> getDeptList() {

        List<TbSysDeptDto> resultList = service.selectDeptList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "특정 부서 하나의 상세정보 조회(부서ID)", description = "특정 부서 하나의 상세정보 조회(부서ID) API")
    @GetMapping(value = "/common/depts/id/{deptId}")
    public ResponseEntity<?> getDeptIdInfo(@PathVariable(value="deptId", required=true) int deptId){

        TbSysDeptDto result = service.selectDeptId(deptId);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "특정 부서 하나의 상세정보 조회(부서코드)", description = "특정 부서 하나의 상세정보 조회(부서코드) API")
    @GetMapping(value = "/common/depts/code/{deptCd}")
    public ResponseEntity<?> getDeptCdInfo(@PathVariable(value="deptCd", required=true) String deptCd){

        TbSysDeptDto result = service.selectDeptCd(deptCd);
        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "사용자 검색", description = "사용자 검색 API")
    @Parameters({
            @Parameter(name = "pageNum", description = "페이지 번호"),
            @Parameter(name = "pageSize", description = "페이장 게시물 수"),
            @Parameter(name = "searchWord", description = "사용자명 검색"),
            @Parameter(name = "deptCd", description = "부서코드 검색")

    })
    @GetMapping(value = "/common/users")
    public ResponseEntity<?> searchUserList(
            @RequestParam(value="pageNum", required=false, defaultValue="1") int pageNum,
            @RequestParam(value="pageSize", required=false, defaultValue="10") int pageSize,
            @RequestParam(value="searchWord", required=false) String searchWord,
            @RequestParam(value="deptCd", required=false) String deptCd
    ) {

        // Page 조회
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<TbSysUserDto> resultList = service.selectUserList(searchWord, deptCd);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "법령정보 OPEN API TEST", description = "법령정보 OPEN API TEST")
    @GetMapping(value = "/common/law-openapi")
    @EnableAuth(role={"SYSTEM_ADMIN"})
    public ResponseEntity<?> searchLawOpenapi() {

        RestClient restClient = RestClient.create();
        String result = restClient.get()
                .uri("https://www.law.go.kr/DRF/lawSearch.do?target=lsJoHstInf&OC=test&regDt=20150211")
                .retrieve()
                .body(String.class);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "로그인 시 전체 다국어 메시지 조회", description = "로그인 시 전체 다국어 메시지 조회 API")
    @GetMapping(value = "/locales/translation")
    public ResponseEntity<?> selectKoTranslation() {

        JsonObject messages = service.selectMessagesAll();
        return ResponseUtil.createSuccessResponse(messages.encode());
    }

    @Operation(summary = "로그인한 사용자 profile 가져오기", description = "로그인한 사용자 profile 가져오기 API")
    @GetMapping("/profile")
    public ResponseEntity<?> getProfile() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        String userId = auth.getName();
        TbSysUserDto userInfo = service.selectUserProfile(userId);
        List<TbSysVirtualGroupDto> groupInfo = service.selectUserGroups(userId);
        String serverTime = DateUtil.now("yyyy-MM-dd HH:mm:ss");

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("userInfo", userInfo);
        result.put("groupInfo", groupInfo);
        result.put("serverTime", serverTime);

        return ResponseUtil.createSuccessResponse(result);
    }

    @Operation(summary = "Redis Value 생성(테스트)", description = "Redis Value 생성(테스트) API")
    @PostMapping(value = "/redis/test")
    public ResponseEntity<?> createRedis(
            @RequestParam(value="key", required=true, defaultValue="rediskey001") String key,
            @RequestParam(value="value", required=true, defaultValue="redisvalue001") String value
    ) {
        service.createRedis(key, value);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Redis Value 읽기(테스트)", description = "Redis Value 읽기(테스트) API")
    @GetMapping(value = "/redis/test")
    public ResponseEntity<?> readRedis(
            @RequestParam(value="key", required=true, defaultValue="rediskey001") String key
    ) {
        String value = service.readRedis(key);

        return ResponseUtil.createSuccessResponse(value);
    }

    @Operation(summary = "Redis Value 삭제(테스트)", description = "Redis Value 삭제(테스트) API")
    @DeleteMapping(value = "/redis/test")
    public ResponseEntity<?> deleteRedis(
            @RequestParam(value="key", required=true, defaultValue="rediskey001") String key
    ) {
        service.deleteRedis(key);

        return ResponseUtil.createSuccessResponse();
    }

    @Operation(summary = "Frontend 발생 오류 수신", description = "Frontend 발생 오류 수신 API")
    @PostMapping(value = "/receive-fe-error")
    public ResponseEntity<?> receiveFrontError(@Valid @RequestBody() FrontErrorDto dto) {

        log.info("Front Error ======================");
        log.info("token: {}", dto.getToken());
        log.info("message: {}", dto.getMessage());
        log.info("created: {}", dto.getCreated());
        log.info("currentRouteUrl: {}", dto.getCurrentRouteUrl());
        log.info("beforeRouteUrl: {}", dto.getBeforeRouteUrl());
        log.info("userAgent: {}", dto.getUserAgent());
        log.info("version: {}", dto.getVersion());

        return ResponseUtil.createSuccessResponse();
    }
}
