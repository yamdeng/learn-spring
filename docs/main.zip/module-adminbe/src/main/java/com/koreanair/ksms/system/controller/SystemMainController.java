package com.koreanair.ksms.system.controller;

import com.koreanair.ksms.system.dto.TbSysCodeDto;
import com.koreanair.ksms.system.dto.TbSysCodeGroupDto;
import com.koreanair.ksms.system.dto.TbSysDeptDto;
import com.koreanair.ksms.system.dto.TbSysUserDto;
import com.koreanair.ksms.system.service.SystemMainService;
import com.koreanair.ksms.utils.JsonUtil;
import com.koreanair.ksms.utils.ResponseUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

/**
 * 관리자 사이트 - 메인화면 Controller
 */
@Tag(name = "SystemMain", description = "시스템 메인화면 API")
@Slf4j
@RestController
@RequestMapping(value = "/api/v1/sys")
public class SystemMainController {

    @Autowired
    SystemMainService service;

    @Operation(summary = "좌측 메뉴 조회", description = "시스템 좌측 메뉴를 조회하는 API")
    @Parameters({
            @Parameter(name = "workScope", description = "업무구분(A:항공안전, O:산업안전, S:시스템)"),
            @Parameter(name = "isTree", description = "빈값이거나 Y 일경우 Tree형태로 조회, 아니면 List로 조회")

    })
    @GetMapping(value = "/left-menus")
    public ResponseEntity<?> getAdminLeftMenus(
            @RequestParam(value="workScope", required=true, defaultValue="S") String workScope,
            @RequestParam(value="isTree", required=false, defaultValue="Y") String isTree) {

        List<Map<String, Object>> resultList = service.selectLeftMenu(workScope);

        if("Y".equals(isTree)) {
            // 트리형태 JSON 으로 변경하여 리턴
            return ResponseUtil.createSuccessResponse(JsonUtil.convertorTreeMap(resultList, "S000000", "menuId", "upperMenuId", "nameKor", "sort"));
        }

        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드그룹 목록 조회", description = "전체 코드그룹 목록 조회 API")
    @GetMapping(value = "/common/code-groups")
    public ResponseEntity<?> getCodeGroupList() {

        List<TbSysCodeGroupDto> resultList = service.selectCodeGroupList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "코드 그룹의 코드목록 조회", description = "코드 그룹의 코드목록 조회 API")
    @GetMapping(value = "/common/code-groups/{codeGroupId}/codes")
    public ResponseEntity<?> getCodeList(@PathVariable(value="codeGroupId", required=true) String codeGroupId) {

        List<TbSysCodeDto> resultList = service.selectCodeList(codeGroupId);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 코드목록 조회", description = "그룹정보를 포함한 전체 코드목록 조회 API")
    @GetMapping(value = "/common/code-groups/codes/all")
    public ResponseEntity<?> getCodeListAll() {

        List<TbSysCodeDto> resultList = service.selectCodeListAll();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "전체 부서 목록 조회", description = "전체 부서 목록 조회 API")
    @GetMapping(value = "/common/depts")
    public ResponseEntity<?> getDeptList() {

        List<TbSysDeptDto> resultList = service.selectDeptList();
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "사용자 검색", description = "사용자 검색 API")
    @Parameters({
            @Parameter(name = "searchWord", description = "사용자명 검색"),
            @Parameter(name = "deptCd", description = "부서코드 검색")

    })
    @GetMapping(value = "/common/users")
    public ResponseEntity<?> searchUserList(
            @RequestParam(value="searchWord", required=false) String searchWord,
            @RequestParam(value="deptCd", required=false) String deptCd
    ) {

        List<TbSysUserDto> resultList = service.selectUserList(searchWord, deptCd);
        return ResponseUtil.createSuccessResponse(resultList);
    }

    @Operation(summary = "법령정보 OPEN API TEST", description = "법령정보 OPEN API TEST")
    @GetMapping(value = "/common/law-openapi")
    public ResponseEntity<?> searchLawOpenapi() {

        RestClient restClient = RestClient.create();
        String result = restClient.get()
                .uri("https://www.law.go.kr/DRF/lawSearch.do?target=lsJoHstInf&OC=test&regDt=20150211")
                .retrieve()
                .body(String.class);

        return ResponseUtil.createSuccessResponse(result);
    }
}
