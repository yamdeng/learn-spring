package com.koreanair.ksms.system.service;

import com.github.pagehelper.PageInfo;
import com.koreanair.ksms.system.dto.TbSysMessageDto;

import java.util.List;

public interface SystemMessageService {

    List<TbSysMessageDto> selectMessageList(String searchWord);
    PageInfo<TbSysMessageDto> selectMessageListPage(String searchWord);
    TbSysMessageDto selectMessage(String messageId);
    void insertMessage(TbSysMessageDto dto);
    void updateMessage(TbSysMessageDto dto);
    void deleteMessage(String messageId);

}
