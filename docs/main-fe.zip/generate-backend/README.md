# 대한항공 BACKEND 생성

# 설치

1. npm install

# 실행

1. main.js 에서 rows 를 수정후
2. cd src
3. node main.js
4. output 폴더 확인

- 생성 경로 변경시 convter.js 에서 outputDir 값 수정
- templates 폴더에서 템플릿 수정후 개별적용 가능
