/// <reference types="vite/client" />

declare const __PROJECT_FOLDER_PATH: string;
