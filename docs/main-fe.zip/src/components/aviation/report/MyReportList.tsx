import MyReportListScreen from './MyReportListScreen';

export default function MyReportList() {
  return <MyReportListScreen />;
}
