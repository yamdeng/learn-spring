import { useEffect, useRef } from 'react';
import { useStore } from 'zustand';
import { AttachmentViewGroup } from './components/common/AttachmentViewGroup';
import { DescriptionViewGroup } from './components/common/DescriptionViewGroup';
import { EventViewGroup } from './components/common/EventViewGroup';
import { FlightViewGroup } from './components/common/FlightViewGroup';
import { CSRPersonInvolvedDetailViewGroup } from './components/csr/CSRPersonInvolvedDetailViewGroup';
import { BottomSheetLayoutWhenWrite } from './custom/BottomSheet';
import { ReportButtonType1 } from './custom/CustomForms';
import { MyReportWriteScreenViewModel } from './viewModels/MyReportWriteScreenViewModel';
import { MYREPORT_DICT_SETUP, MYREPORT_LANG } from './configs/WriteScreenConfig';
import { FinishViewGroup } from './components/common/FinishViewGroup';

export default function MyReportWriteScreen(params) {
  const { init, currentFragment, cardFragmentClipEvent, onCancel, onNext, sheetList, onClose, updateDestroyCallback } =
    useStore(MyReportWriteScreenViewModel, (state) => state) as any;

  const { categoryData, onCloseModal } = params;

  // 보고서 초기화
  useEffect(() => {
    init(categoryData);
    //cardFragmentClipEvent({ fragment: categoryData.step.find((element) => element.tab === 'Person Involved Detail') });
  }, [params]);

  useEffect(() => {
    updateDestroyCallback({ onCloseModal: onCloseModal });
  }, []);

  const containerRef = useRef(null);

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        console.log(`containerHeight: ${containerRef.current.offsetHeight}`);
      }
    };

    const resizeObserver = new ResizeObserver(handleResize);
    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    // 컴포넌트 언마운트 시 observer 해제
    return () => {
      if (containerRef.current) {
        resizeObserver.unobserve(containerRef.current);
      }
    };
  }, []);

  console.log(`categoryData.type: ${categoryData.type}`);
  console.log(`categoryData.category: ${categoryData.category}`);

  const baseTabStyleOn = `tw-px-3 tw-bg-slate-200 tw-py-3 tw-mx-2 tw-rounded-t-xl tw-text-nowrap`;
  const baseTabStyleOff = `${baseTabStyleOn} tw-text-white tw-bg-slate-500`;

  return (
    <div className="tw-bg-slate-400 tw-rounded-2xl tw-p-10 tw-flex tw-flex-col tw-w-full">
      {(() => {
        if (currentFragment.tab === 'Finish') {
          return <FinishViewGroup />;
        } else {
          return (
            <>
              <div className="tw-flex tw-mx-10 tw-overflow-x-scroll scrollbar-hidden">
                <div className="tw-font-bold tw-text-[1.7rem] tw-py-3 tw-mx-2 tw-mr-6">{categoryData.category}</div>

                {(() => {
                  return categoryData.step.map((element) => {
                    return (
                      <div
                        key={element.tab}
                        className={element.tab === currentFragment.tab ? baseTabStyleOn : baseTabStyleOff}
                        onClick={() => cardFragmentClipEvent({ fragment: element })}
                      >
                        {element.tab}
                      </div>
                    );
                  });
                })()}
              </div>

              {/* height를 알아야 하는 최상단 contents box */}
              <div ref={containerRef} className="tw-flex tw-flex-col tw-h-full tw-justify-end">
                {/* height 0으로 잡아야 내부에서 스크롤 영역을 정확히 잡는데, 원인을 모르겠음 */}
                <div className="tw-grow tw-items-stretch tw-w-full tw-h-0 tw-relative tw-overflow-hidden">
                  {(() => {
                    switch (currentFragment.tab) {
                      case 'Flight': {
                        /*switch (currentFragment.sub) {
                  case 'Search':
                    return <FlightSearchViewGroup />;
                  case 'Detail':
                    return <FlightDetailViewGroup />;
                }*/
                        return <FlightViewGroup />;
                      }
                      case 'Event': {
                        return <EventViewGroup type={categoryData.type} category={categoryData.category} />;
                      }
                      case 'Person Involved Detail': {
                        return <CSRPersonInvolvedDetailViewGroup />;
                      }
                      case 'Description': {
                        return <DescriptionViewGroup />;
                      }
                      case 'Attachment': {
                        return <AttachmentViewGroup />;
                      }
                      case 'Finish': {
                        return <FinishViewGroup type={categoryData.type} category={categoryData.category} />;
                      }
                    }
                  })()}

                  {(() => {
                    return sheetList.map((element) => {
                      return (
                        <BottomSheetLayoutWhenWrite
                          key={element.jsx}
                          isShow={element.isShow}
                          jsx={element.jsx}
                          onClose={onClose}
                        />
                      );
                    });
                  })()}
                </div>

                {/* 버튼 */}
                <div className="tw-grow-0">
                  <div className="tw-flex tw-gap-4 tw-w-full">
                    <ReportButtonType1
                      className="tw-w-full tw-grow"
                      text={MYREPORT_DICT_SETUP.Common.Back[MYREPORT_LANG]}
                      onClick={onCancel}
                    />
                    <ReportButtonType1
                      className="tw-w-full tw-grow"
                      text={MYREPORT_DICT_SETUP.Common.Next[MYREPORT_LANG]}
                      onClick={onNext}
                    />
                  </div>
                </div>
              </div>
            </>
          );
        }
      })()}
    </div>
  );
}
