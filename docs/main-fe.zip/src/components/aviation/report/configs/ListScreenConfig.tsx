export const reportStatus = [
  { key: 'key01', text: { ko: '반려', en: 'Reject' } },
  { key: 'key02', text: { ko: '이관', en: 'Moved' } },
  { key: 'key03', text: { ko: '작성중', en: 'Editing' } },
  { key: 'key04', text: { ko: '제출완료', en: 'Submitted' } },
  { key: 'key05', text: { ko: '접수중', en: 'Accepted' } },
  { key: 'key06', text: { ko: '처리중', en: 'Progress' } },
  { key: 'key07', text: { ko: '종결', en: 'Finished' } },
];

export const reportCategory = {
  CSR: [
    { key: 'inspection', text: { ko: '수검', en: 'Inspection' } },
    { key: 'pax-deplane', text: { ko: '승객하기', en: 'Pax Deplane' } },
    { key: 'pax-patient', text: { ko: '승객환자', en: 'Pax Patient' } },
    { key: 'pax-injury', text: { ko: '승객부상', en: 'Pax Injury' } },
    { key: 'crew-patient', text: { ko: '승무원환자', en: 'Crew Patient' } },
    { key: 'crew-injury', text: { ko: '승무원부상', en: 'Crew Injury' } },
    { key: 'act-of-unlawful-interference', text: { ko: '불법방해행위', en: 'Acts of Unlawful Interference' } },
    { key: 'smoking', text: { ko: '흡연', en: 'Smoking' } },
    { key: 'maintenance', text: { ko: '설비/정비', en: 'Maintenance' } },
    { key: 'others', text: { ko: '기타', en: 'Others' } },
  ],
};
