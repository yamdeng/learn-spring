import MyReportWriteScreen from './MyReportWriteScreen';

export default function MyReportEdit() {
  return <MyReportWriteScreen />;
}
