import { produce } from 'immer';
import { create } from 'zustand';
import MyReportWriteScreen from '../MyReportWriteScreen';
import { reportCategory } from '../configs/ListScreenConfig';
import { MYREPORT_LANG, ReportConfig } from '../configs/WriteScreenConfig';
import { SheetAddReport } from '../custom/BottomSheet';
import { pickupOptionsLanguage } from '../utils/Function';
import { MyReportWriteScreenViewModel } from './MyReportWriteScreenViewModel';

const initailState = {
  sheetList: [],
  finalFilter: {},
  modalPage: {
    isShow: false,
    jsx: () => {},
  },
};

export const MyReportListScreenViewModel = create<any>((set, get) => ({
  ...initailState,
  addSheet: (element) => {
    const { sheetList } = get();
    set({ sheetList: [...sheetList, element] });
    setTimeout(() => {
      set(
        produce((state: any) => {
          state.sheetList.forEach((item) => {
            item.isShow = true;
          });
        })
      );
    }, 200);
  },
  /**
   * BottomSheet 닫기 이벤트
   *
   * sheetList에서 마지막으로 열었던 Sheet를 찾아서 리스트에서 제거한 후 sheetList에 다시 update!
   */
  onClose: () => {
    console.log('CLOSE');
    const { sheetList } = get();
    set(
      produce((state: any) => {
        const lastIndex = state.sheetList.length - 1;
        if (lastIndex < 0) return;
        state.sheetList[lastIndex].isShow = false;
      })
    );
    setTimeout(() => {
      set({ sheetList: [...sheetList.slice(0, -1)] });
    }, 400);
  },
  // 보고서 추가 BottomSheet
  addReport: (params) => {
    const { addSheet, onClose, goWriteReport } = get();
    const { init } = MyReportWriteScreenViewModel.getState();

    const { category } = params;
    // 클릭 이벤트 추가
    const list = pickupOptionsLanguage(reportCategory[category], MYREPORT_LANG).map((item) => ({
      ...item,
      onClick: () => {
        // 현재 팝업 닫기
        onClose();
        // 해당 보고서 작성 화면으로 이동
        goWriteReport(item);
        // 작성화면 초기화
        init();
      },
    }));
    addSheet({
      isShow: false,
      jsx: () => {
        return <SheetAddReport category={list} />;
      },
      onClose: onClose,
    });
  },
  // 보고서 추가 버튼 클릭시 액션
  goWriteReport: () => {
    const { showModal, closeModal } = get();

    const typeData = ReportConfig.filter((element) => {
      return element.type === 'CSR';
    })[0];

    const categoryData = typeData.data.filter((element) => {
      return element.category === 'Inspection';
    })[0];

    showModal({
      jsx: () => {
        return <MyReportWriteScreen categoryData={categoryData} onCloseModal={closeModal} />;
      },
    });
  },
  // 보고서 목록에 사용하는 기본 Sheet
  onDefaultBottomSheet: (params) => {
    const { contents: Contents } = params;
    const { addSheet, onClose } = get();

    addSheet({
      name: 'DefaultBottomSheet',
      isShow: false,
      jsx: () => {
        return <Contents />;
      },
      onClose: onClose,
    });
  },
  // 조회조건 결정
  updateFilterCondition: (params) => {
    const { condition } = params;
    set({ finalFilter: condition });
  },
  // 검색조건 제거
  removeFilter: (key) => {
    set(
      produce((state: any) => {
        if (key === 'date') {
          state.finalFilter.dateFrom = '';
          state.finalFilter.dateTo = '';
        } else {
          state.finalFilter[key] = '';
        }
      })
    );
  },
  // Modal Screen 생성
  showModal: (params) => {
    const { jsx } = params;

    set(
      produce((state: any) => {
        state.modalPage.isShow = true;
        state.modalPage.jsx = jsx;
      })
    );
  },
  // Modal Close
  closeModal: () => {
    set(
      produce((state: any) => {
        state.modalPage.isShow = false;
        state.modalPage.jsx = null;
      })
    );
  },
}));
