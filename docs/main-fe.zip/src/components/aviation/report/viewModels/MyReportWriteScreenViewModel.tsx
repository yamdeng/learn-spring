import { produce } from 'immer';
import { create } from 'zustand';
import { SheetDefaultSelect } from '../custom/BottomSheet';
import { FlightUseCase } from '../usecase/FlightUseCase';
import { v4 as uuidv4 } from 'uuid';
import {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  DB_SQLJS_NAME,
  INSERT_ATTACHMENT,
  INSERT_REPORT,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  SELECT_ATTACHMENT_FULL,
  SELECT_LASTEST_REPORT_ID,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  SELECT_REPORT_JOIN_ATTACHMENT,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  TABLE_ATTACHMENT,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  TABLE_REPORT,
} from '../configs/AttachmentConfig';
import { DefaultShiftHelper } from '../utils/BitShiftHelper';
import { SharedLocalDatabase } from '../shared/SharedLocalDatabase';

const initialState = {
  // report 전체 정보
  data: {},

  sheetList: [],
  init: () => {},
  currentFragment: {
    tab: null,
    sub: null,
  },
  modalPage: {
    isShow: false,
    jsx: () => {},
  },
  flightUseCase: FlightUseCase.getState(),

  // Attachment
  reports: [],
  attachments: [],
  formData: new FormData(),
};

export const MyReportWriteScreenViewModel = create<any>((set, get) => ({
  ...initialState,
  cardFragmentClipEvent: (params) => {
    const { data } = get();

    const { fragment } = params;

    console.log(fragment);

    const jumpStep = data.step.filter((element) => {
      return element.tab == fragment.tab;
    })[0];

    if (jumpStep) {
      set({
        currentFragment: {
          tab: jumpStep.tab,
          sub: jumpStep.sub[0],
        },
      });
    }
  },
  // '다음' 버튼
  onNext: () => {
    const { setNextFragment } = get();
    setNextFragment();
  },
  // '이전' 버튼
  onCancel: () => {
    const { setPreviousFragment } = get();
    setPreviousFragment();
  },
  init: (data) => {
    const { currentFragment, setNextFragment } = get();
    set({
      data: data,
    });
    if (!currentFragment.tab) {
      setNextFragment();
    }
  },
  setNextFragment: () => {
    const { currentFragment, data } = get();

    let index = 0;
    for (const step of data.step) {
      // 처음인 경우
      if (!currentFragment.tab) {
        set({
          currentFragment: {
            tab: step.tab,
            sub: step.sub[0],
          },
        });
        return;
      }

      // 다음 sub화면으로 가야 하는 경우
      if (step.tab === currentFragment.tab) {
        // 다음 sub화면이 있는지 확인
        let subIndex = 0;
        for (const sub of step.sub) {
          if (currentFragment.sub === sub) {
            if (step.sub[subIndex + 1]) {
              set({
                currentFragment: {
                  tab: data.step[index].tab,
                  sub: data.step[index].sub[subIndex + 1],
                },
              });
              return;
            }
          }
          subIndex++;
        }

        // 다음 sub화면이 없는 경우, 다음 tab으로 이동
        if (data.step[index + 1]) {
          set({
            currentFragment: {
              tab: data.step[index + 1].tab,
              sub: data.step[index + 1].sub[0],
            },
          });
          return;
        }

        console.log(`더이상 앞으로 갈수 없습니다.: ${currentFragment.tab}`);
      }

      index++;
    }
  },
  setPreviousFragment: () => {
    const { currentFragment, data, onDestory } = get();

    let index = 0;
    for (const step of data.step) {
      // 처음인 경우
      if (!currentFragment.tab) {
        return;
      }

      // 이전 sub화면으로 가야 하는 경우
      if (step.tab === currentFragment.tab) {
        // 다음 sub화면이 있는지 확인
        let subIndex = 0;
        for (const sub of step.sub) {
          if (currentFragment.sub === sub) {
            if (step.sub[subIndex - 1]) {
              set({
                currentFragment: {
                  tab: data.step[index].tab,
                  sub: data.step[index].sub[subIndex - 1],
                },
              });
              return;
            }
          }
          subIndex++;
        }

        // 이전 sub화면이 없는 경우, 이전 tab으로 이동
        if (data.step[index - 1]) {
          set({
            currentFragment: {
              tab: data.step[index - 1].tab,
              sub: data.step[index - 1].sub[0],
            },
          });
          return;
        }

        console.log('더이상 뒤로 갈수 없습니다.');

        onDestory();
      }

      index++;
    }
  },
  updateDestroyCallback: (params) => {
    const { onCloseModal } = params;
    set({ destroyCallback: onCloseModal });
  },
  onDestory: () => {
    const { destroyCallback } = get();
    destroyCallback();
    set({
      currentFragment: {
        tab: null,
        sub: null,
      },
    });
  },
  // ------------------------------------------------------------------------------
  // Model
  // ------------------------------------------------------------------------------
  updateData: (params) => {
    const { specification, attribute, value } = params;
    set(
      produce((state: any) => {
        const specItem = state.data.data.find((item) => item.specification === specification);
        if (specItem) {
          // attribute를 점(.)으로 분리하여 경로를 찾음
          const keys = attribute.split('.');

          // 객체를 가리키는 변수
          let current = specItem.data;

          // 마지막 키를 찾기 위해 반복
          for (let i = 0; i < keys.length - 1; i++) {
            const key = keys[i];
            if (current[key] === undefined) {
              // 현재 경로에 속성이 없으면 새로 생성
              current[key] = {};
            }
            current = current[key];
          }

          // 마지막 키에 값을 할당
          const lastKey = keys[keys.length - 1];
          current[lastKey] = value;
        }
      })
    );
    const { data } = get();
    console.log(`[PRINT] data model`);
    console.log(data);
    console.log(`[PRINT] data model`);
  },
  // ------------------------------------------------------------------------------
  // Api
  // ------------------------------------------------------------------------------
  apiToSearchFlight: async (request) => {
    const { flightUseCase, updateData } = get();
    console.log(`apiToSearchFlight: BEGIN`);
    const response = await flightUseCase.searchFlight(request);
    console.log(response);
    updateData({ specification: 'Flight', attribute: 'responseSearchFlight', value: response });
    console.log(`apiToSearchFlight: END`);
  },
  // ------------------------------------------------------------------------------
  // BOTTOM SHEET
  // ------------------------------------------------------------------------------
  addSheet: (element) => {
    const { sheetList } = get();
    set({ sheetList: [...sheetList, element] });
    setTimeout(() => {
      set(
        produce((state: any) => {
          state.sheetList.forEach((item) => {
            item.isShow = true;
          });
        })
      );
    }, 200);
  },
  onClose: () => {
    console.log('CLOSE');
    const { sheetList } = get();
    set(
      produce((state: any) => {
        const lastIndex = state.sheetList.length - 1;
        if (lastIndex < 0) return;
        state.sheetList[lastIndex].isShow = false;
      })
    );
    setTimeout(() => {
      set({ sheetList: [...sheetList.slice(0, -1)] });
    }, 400);
  },

  // Select 선택용 BottomSheet
  pushSheetOnSelect: (params) => {
    const { title, listOnSelect, alreadyPicked, onSelect } = params;
    const { addSheet, onClose } = get();

    addSheet({
      name: 'SelectOnSheet',
      isShow: false,
      jsx: () => {
        return (
          <SheetDefaultSelect title={title} list={listOnSelect} onSelect={onSelect} alreadyPicked={alreadyPicked} />
        );
      },
      onClose: onClose,
    });
  },

  // 보고서 작성에 사용하는 기본 Sheet
  onDefaultBottomSheet: (params) => {
    const { contents: Contents } = params;
    const { addSheet, onClose } = get();

    addSheet({
      name: 'DefaultBottomSheet',
      isShow: false,
      jsx: () => {
        return <Contents />;
      },
      onClose: onClose,
    });
  },
  // ------------------------------------------------------------------------------
  // FileHandle
  // ------------------------------------------------------------------------------
  handleFileChange: (event) => {
    const { getFormArray } = get();
    if (!event.target.files[0]) return;
    const formData = new FormData();
    let index = 0;
    getFormArray().forEach(([key, file], i) => {
      console.log(key);
      formData.append(`file${i}`, file);
      index++;
    });
    formData.append(`file${index}`, event.target.files[0]);
    set({ formData: formData });
  },
  getFormArray: () => {
    const { formData } = get();
    return Array.from(formData.entries());
  },
  insertReportToDB: () => {
    const { db } = SharedLocalDatabase.getState();
    const { data } = get();
    // 보고서 저장
    db.run(`${INSERT_REPORT}`, ['CSR', JSON.stringify(data)]);

    const stmt = db.prepare(SELECT_LASTEST_REPORT_ID);

    const result = [];
    while (stmt.step()) {
      result.push(stmt.getAsObject());
    }

    if (result.length > 0) {
      const report_id = result[0].id;
      console.log(`Save Report 'id': ${report_id}`);
      return report_id;
    } else {
      alert('레포트 작성 저장 중 오류가 발생했습니다.');
      return null;
    }
  },
  insertAttachmentToDB: (report_id, fileMaps) => {
    const { db } = SharedLocalDatabase.getState();
    // 첨부파일 DB 업데이트
    console.log(fileMaps);
    fileMaps.map((element, index) => {
      console.log(`index: ${index}`);
    });
    fileMaps.forEach((element, index) => {
      console.log(`file: ${element}`);
      console.log(`index: ${index}`);
      db.run(`${INSERT_ATTACHMENT}`, [report_id, element.filename, element.size, element.key]);
    });
  },
  saveReport: async (params) => {
    const { getFormArray, insertReportToDB, insertAttachmentToDB } = get();
    const { getLocalForage, pushItem, commit, fetchReport } = SharedLocalDatabase.getState();
    const { completion } = params;

    // 파일 목록
    const fileMaps = [];

    DefaultShiftHelper.setupCompletion(getFormArray().length);

    // 첨부파일 로컬 저장 후 최종 실행
    DefaultShiftHelper.callback = () => {
      // 1초후 보고서 DB 저장
      setTimeout(() => {
        // 보고서 저장
        const report_id = insertReportToDB();
        report_id && insertAttachmentToDB(report_id, fileMaps);
        commit();
        fetchReport();
        set({ formData: new FormData() });

        completion();
      }, 1000);
    };

    // 첨부파일 local 저장
    if (getFormArray().length === 0) {
      DefaultShiftHelper.fetchCurrent(0x1 << 0);
      return;
    }
    let i = 0;
    getFormArray().forEach(async ([key, file]) => {
      console.log(key);
      if (file instanceof File) {
        const reader = new FileReader();
        reader.onloadend = async () => {
          const arrayBuffer = reader.result;

          try {
            // 파일 키를 생성하거나 수정합니다.
            const fileKey = uuidv4(); // 이 함수는 파일 키를 생성하거나 가져오는 로직입니다.
            await pushItem({ key: fileKey, value: arrayBuffer });
            console.log('File successfully saved to IndexedDB.');

            // 현재 파일 키들을 로그로 출력
            const fileKeys = await getLocalForage().keys();
            console.log(`current file keys: ${fileKeys.join(',')}`);

            // 저장된 파일 키들을 확인
            fileKeys.forEach((key) => {
              console.log(`Stored file key: ${key}`);
            });
            fileMaps.push({ key: fileKey, filename: file.name, size: file.size });
            DefaultShiftHelper.fetchCurrent(0x1 << i);
            i++;
          } catch (storageError) {
            console.error('Error saving file to IndexedDB:', storageError);
            alert('파일 업로드 중 오류가 발생했습니다.');
          }
        };
        reader.readAsArrayBuffer(file);
      }
    });
  },
  removeFormFile: (fileToRemove) => {
    const { getFormArray } = get();
    const formData = new FormData();
    let index = 0;
    getFormArray().forEach(([key, file]) => {
      if (key !== fileToRemove) {
        formData.append(`file${index}`, file);
        index++;
      }
    });
    set({ formData: formData });
  },
}));
