import CommonUtil from '@/utils/CommonUtil';
import classNames from 'classnames';
import CommonInputError from './CommonInputError';

/*

   #.공통 속성
    -id(string) : 에러발생시 포커스 이동시키기 위한 id
    -name(string) : yup에 등록되는 키값과 동일시키는 것을 추천
    -label(string)  : 라벨(input 상단에 표시되는 라벨)
    -value : 각 컴포넌트 타입에 따라 value 타입이 달라질 수 있음 
    -onChange : 각 컴포넌트 타입에 따라 함수 spec이 달라질 수 있음
    -placeholder : label 속성외의 placeholder를 보여주고 싶을때 사용
    -required : 필수 여부(라벨에 '*' 표시)
    -errorMessage(string) : 에러메시지가 존재시 border가 red로 바뀌고 input 하단에 에러메시지가 표기됨. 메시지 키값을 전달시 해당 키값이 반영됨
    -disabled(boolean)
    -style({}) : react의 style object({}) 형식으로 전달

   #.<AppCheckbox /> 전용 속성
    -value(boolean)
    -onChange : (boolean, event)
    -checkboxTitle(string) : 체크박스 좌측에 text(전달하지 않을 경우 label 값을 사용함)

*/

function AppCheckbox(props) {
  const {
    id = CommonUtil.getUUID(),
    name = '',
    label,
    value = false,
    onChange,
    required = false,
    errorMessage,
    disabled = false,
    checkboxTitle = '',
    noBorder = false,
  } = props;
  const applyClassName = classNames('radio-wrap', { error: errorMessage, 'border-no': noBorder });

  return (
    <>
      <span className="txt" style={{ display: !noBorder && label ? '' : 'none' }}>
        {label} {required ? <span className="required">*</span> : null}
      </span>
      <div id={id} className={applyClassName}>
        <label key={label}>
          <input
            type="checkbox"
            name={name}
            disabled={disabled}
            checked={value}
            onChange={(event) => {
              onChange(event.target.checked, event);
            }}
          />
          <span>{checkboxTitle ? checkboxTitle : label}</span>
        </label>
      </div>
      <CommonInputError errorMessage={errorMessage} label={label} />
    </>
  );
}

export default AppCheckbox;
