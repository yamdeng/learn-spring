export default function OfflineMain() {
  return <>오프라인 메인입니다</>;
}
