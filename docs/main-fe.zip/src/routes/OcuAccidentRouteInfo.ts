const RouteInfo: any = {};

RouteInfo.list = [
  {
    Component: null,
    path: 'null',
  },
];

export default RouteInfo;
