/*

  모달 타입

*/

const ModalType: any = {};

// 공통 alert 모달 : AlertModal
ModalType.ALERT_MODAL = 'alert-modal';

// 공통 confirm 모달 : ConfirmModal
ModalType.CONFRIM_MODAL = 'confirm-modal';

export default ModalType;
